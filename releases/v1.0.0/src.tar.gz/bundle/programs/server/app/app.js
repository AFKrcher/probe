var require = meteorInstall({"imports":{"api":{"errors.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/errors.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  ErrorsCollection: () => ErrorsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ErrorsCollection = new Mongo.Collection("errors");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"satellites.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/satellites.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  SatelliteCollection: () => SatelliteCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const SatelliteCollection = new Mongo.Collection("satellites");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schemas.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/schemas.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  SchemaCollection: () => SchemaCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const SchemaCollection = new Mongo.Collection("schemas");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/users.js                                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  UsersCollection: () => UsersCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const UsersCollection = new Mongo.Collection("userList");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"validators":{"satelliteDataFuncs.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/validators/satelliteDataFuncs.js                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  satelliteValidatorShaper: () => satelliteValidatorShaper
});
let Yup;
module.link("yup", {
  "*"(v) {
    Yup = v;
  }

}, 0);
let SchemaCollection;
module.link("/imports/api/schemas", {
  SchemaCollection(v) {
    SchemaCollection = v;
  }

}, 1);
let SatelliteCollection;
module.link("/imports/api/satellites", {
  SatelliteCollection(v) {
    SatelliteCollection = v;
  }

}, 2);

const isUniqueList = (initValues, sats, path, field) => {
  let list = [];

  if (!path) {
    for (let sat in sats) {
      sats[sat][field] === initValues[field] ? null : list.push(sats[sat][field]);
    }
  } else if (initValues[path]) {
    for (let sat in sats) {
      let satEntries = sats[sat][path];

      for (let entry in satEntries) {
        satEntries[entry][field] === (initValues[path].length > 0 ? initValues[path][entry][field] : false) ? null : list.push(satEntries[entry][field]);
      }
    }
  }

  return list;
};

const schemaCleaner = (schemas, values) => {
  let schemaObj = {}; // object: {schema.name: {field.name: {field.type: string/number/date, field.allowedValues: [], required: field.required, min: field.min, max: field.max}}}

  let cleanSchemas = []; // stores only the schemas applicable to the current satellite values

  for (let value in values) {
    for (let schema in schemas) {
      if (schemas[schema].name === value) cleanSchemas.push(schemas[schema]);
    }
  }

  cleanSchemas === null || cleanSchemas === void 0 ? void 0 : cleanSchemas.forEach(schema => {
    // step 1: map over schemas and assign each schema name as a key in the object
    schemaObj[schema.name] = {}; // step 2: map over each schema and assign an object containing all field names as keys in that object

    return schema.fields.forEach(field => {
      schemaObj[schema.name][field.name] = {}; // step 3: map over each field and assign an object containing all of the field's attributes (type, allowedValues, min, max, required)

      for (let attribute in field) {
        if (attribute !== "name" && attribute !== "description") {
          // step 4: Take each attribute's value and assign it to the attribute in the object
          schemaObj[schema.name][field.name][attribute] = field[attribute];
        }
      }
    });
  });
  return schemaObj;
};

const initialYupShapeGenerator = (initValues, sats, isUniqueList) => {
  return {
    // NORAD ID and _id are always a part of the yup shape
    _id: Yup.string().notOneOf(isUniqueList(initValues, sats, null, "_id"), "Something went wrong while assigning _id"),
    noradID: Yup.string().required("Required").matches(/^[0-9]+$/g, "Must be a positive number").notOneOf(isUniqueList(initValues, sats, null, "noradID"), obj => "A satellite with noradID of ".concat(obj.value, " already exists in our records.")),
    adminCheck: Yup.boolean().required(),
    modifiedOn: Yup.date().required(),
    modifiedBy: Yup.string().required(),
    createdOn: Yup.date().required(),
    createdBy: Yup.string().required()
  };
};

const satelliteValidatorShaper = (values, initValues) => {
  const sats = SatelliteCollection.find().fetch();
  const schemas = SchemaCollection.find().fetch();
  let yupShape = initialYupShapeGenerator(initValues, sats, isUniqueList); // instantiation of base yupShape

  const cleanSchema = schemaCleaner(schemas, values); // generates a clean schema object for easier manipulation

  Yup.addMethod(Yup.mixed, "checkEachEntry", function (message) {
    let errObj = {}; // workaround object to push errors into Formik
    // test each entry in the array: Yup.object().shape({field.name: Yup.(field.type)[0].toUpperCase() + (field.type).substr(1).required(field.required).min(field.min).max(field.max).oneOf((field.allowedValues))})

    return this.test("checkEachEntry", message, function (value) {
      const {
        path,
        createError
      } = this; // path is the schema's name, and createError generates errors to be handled by Formik

      let entryCount = 0; // "entryCount" and "fieldCount" are used to provide the location of the error to the SatelliteModal for rendering underneath the correct entry in SatelliteSchemaEntry

      value === null || value === void 0 ? void 0 : value.forEach(entry => {
        // "entry" is composed of multiple "fields", and is part of the submitted array, aka "value"
        let fieldObj = {};
        let fieldCount = 0;
        const schema = cleanSchema[path];

        for (let schemaField in schema) {
          var _field$allowedValues;

          // "schema" are the schemas seen on the SchemasTable, and "schemaField" are the fields to be filled-in in each schema
          const field = schema[schemaField]; // the following must be modified whenever we decide to create:
          // a new "type" (e.g. number, string, date) or
          // a new "type constraint" (e.g. max number, min number, max string length)

          let tempFieldSchema = field.type !== "url" ? Yup[field.type]() : Yup["string"]();
          const baseFieldType = tempFieldSchema; // stores the yup fragments needed for each constraint

          const fieldSchemaMatrix = {
            required: field.required ? baseFieldType.required("".concat(path, "-").concat(entryCount, "-").concat(fieldCount, "_").concat(field.type === "url" ? "URL" : field.type[0].toUpperCase() + field.type.substr(1) + " Input", " Required")) : false,
            url: field.type === "url" ? baseFieldType.url("".concat(path, "-").concat(entryCount, "-").concat(fieldCount, "_Must be a valid URL (e.g. https://en.wikipedia.org/wiki/Main_Page).")) : false,
            allowedValues: ((_field$allowedValues = field.allowedValues) === null || _field$allowedValues === void 0 ? void 0 : _field$allowedValues.length) > 0 ? baseFieldType.oneOf([...field.allowedValues], "".concat(path, "-").concat(entryCount, "-").concat(fieldCount, "_Must be one of the following: ").concat(field.allowedValues.join(", "))) : false,
            isUnique: field.isUnique ? baseFieldType.notOneOf(isUniqueList(initValues, sats, path, schemaField), "".concat(path, "-").concat(entryCount, "-").concat(fieldCount, "_A satellite with ").concat(schemaField, " of ").concat(value[entryCount][schemaField], " already exists.")) : false,
            min: field.type === "number" && field.max ? baseFieldType.min(field.min, "".concat(path, "-").concat(entryCount, "-").concat(fieldCount, "_Must be no less than ").concat(field.min)) : false,
            max: field.type === "number" && field.max ? baseFieldType.max(field.max, "".concat(path, "-").concat(entryCount, "-").concat(fieldCount, "_Must be no greater than ").concat(field.max)) : false,
            stringMax: field.type === "string" && field.stringMax ? baseFieldType.max(field.stringMax, "".concat(path, "-").concat(entryCount, "-").concat(fieldCount, "_Must not exceed ").concat(field.stringMax, " characters.")) : false
          }; // loop over the schema and concatenate all valid constraints to field's yup object

          for (let check in fieldSchemaMatrix) {
            if (fieldSchemaMatrix[check]) tempFieldSchema = tempFieldSchema.concat(fieldSchemaMatrix[check]);
          }

          fieldObj[schemaField] = tempFieldSchema;
          fieldCount++;
        }

        let fieldValidator = Yup.object().shape(fieldObj); // Yup.addMethod's test must return a boolean, and/or generate errors as necessary, in order to complete the validation

        fieldValidator.validate(entry, {
          abortEarly: true
        }).then(() => {
          errObj = {}; // clear all errors on successful validation
        }).catch(err => {
          errObj = {}; // clear old errors and repopulate error object upon failed validation

          err.path === undefined ? err.message = "err is not defined" : null;
          return err.message !== "err is not defined" ? errObj[err["path"]] = err.message : null;
        });
        entryCount++;
      }); // check error object to determine the success of the validation and the amount of errors that need to be generated for Formik to handle

      if (JSON.stringify(errObj) === "{}") {
        return true;
      } else {
        for (let errPath in errObj) {
          let errMessage = errObj[errPath];
          let cleanMessage = errMessage.substr(errMessage.indexOf("_") + 1);
          let cleanPath = errMessage.substr(0, errMessage.indexOf("_"));
          return createError({
            path: "".concat(cleanPath),
            message: "".concat(cleanMessage)
          });
        }
      }
    });
  }); // building the final yup schema object, calling checkEachEntry for each entry in the satellite

  if (JSON.stringify(cleanSchema) !== "{}") {
    for (let schema in cleanSchema) {
      yupShape[schema] = Yup.array().checkEachEntry();
    }
  }

  return Yup.object().shape(yupShape);
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schemaDataFuncs.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/validators/schemaDataFuncs.js                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  schemaValidatorShaper: () => schemaValidatorShaper
});
let Yup;
module.link("yup", {
  "*"(v) {
    Yup = v;
  }

}, 0);

const uniqueNames = (initValues, schemas) => {
  return schemas.map(schema => {
    if (initValues.name !== schema.name) {
      return schema.name;
    }
  });
};

const schemaValidatorShaper = (initValues, schemas) => {
  return Yup.object().shape({
    _id: Yup.string(),
    name: Yup.string().notOneOf(uniqueNames(initValues, schemas), obj => "The schema name, ".concat(obj.value, ", already exists ")).matches(/^[a-zA-Z0-9]*$/g, "Schema name must be spaceless, camelCase, and only contain letters and numbers").required("Required").max(50, "Must not exceed 50 characters"),
    description: Yup.string().required("Required").max(500, "Must not exceed 500 characters"),
    fields: Yup.array().of(Yup.object().shape({
      name: Yup.string().required("Required").max(50, "Must not exceed 50 characters"),
      type: Yup.mixed().oneOf(["string", "number", "date", "url", "changelog"], "Invalid input provided").required("Required"),
      allowedValues: Yup.array().ensure().max(100, "Must not exceed 100 elements"),
      min: Yup.number().nullable().notRequired(),
      max: Yup.number().nullable().when(["min"], (min, schema) => {
        return schema.min(min);
      }),
      required: Yup.boolean(),
      isUnique: Yup.boolean(),
      stringMax: Yup.number().max(20000, "Must not exceed 20,000 characters")
    }).notRequired()),
    adminCheck: Yup.boolean().required(),
    modifiedOn: Yup.date().required(),
    modifiedBy: Yup.string().required(),
    createdOn: Yup.date().required(),
    createdBy: Yup.string().required()
  });
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"helmet.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/helmet.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  helmetOptions: () => helmetOptions
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let WebApp;
module.link("meteor/webapp", {
  WebApp(v) {
    WebApp = v;
  }

}, 1);
let Autoupdate;
module.link("meteor/autoupdate", {
  Autoupdate(v) {
    Autoupdate = v;
  }

}, 2);
let crypto;
module.link("crypto", {
  default(v) {
    crypto = v;
  }

}, 3);
let helmet;
module.link("helmet", {
  default(v) {
    helmet = v;
  }

}, 4);

const helmetOptions = () => {
  const self = "'self'";
  const data = "data:";
  const unsafeEval = "'unsafe-eval'";
  const unsafeInline = "'unsafe-inline'";
  const allowedOrigins = Meteor.settings.allowedOrigins;
  const url = Meteor.absoluteUrl();
  const domain = url.replace(/http(s)*:\/\//, "").replace(/\/$/, "");
  const s = url.match(/(?!=http)s(?=:\/\/)/) ? "s" : "";
  const usesHttps = s.length > 0;
  const connectSrc = [self, "http".concat(s, "://").concat(domain), "ws".concat(s, "://").concat(domain)];
  const options = {
    contentSecurityPolicy: {
      blockAllMixedContent: true,
      directives: {
        defaultSrc: [self, unsafeInline],
        scriptSrc: [unsafeInline],
        childSrc: [self, unsafeInline],
        connectSrc: connectSrc.concat(allowedOrigins),
        fontSrc: [self, data, unsafeInline],
        formAction: [self],
        frameAncestors: [self],
        frameSrc: ["*"],
        imgSrc: ["*"],
        manifestSrc: [self, unsafeInline],
        mediaSrc: [self, unsafeInline],
        objectSrc: [self, unsafeInline],
        sandbox: ["allow-forms", "allow-modals", "allow-same-origin", "allow-scripts", "allow-popups"],
        styleSrc: [self, unsafeInline],
        workerSrc: [self, "blob:"]
      }
    },
    strictTransportSecurity: {
      maxAge: 15552000,
      includeSubDomains: true,
      preload: false
    },
    referrerPolicy: {
      policy: "no-referrer"
    },
    expectCt: {
      enforce: true,
      maxAge: 604800
    },
    frameguard: {
      action: "sameorigin"
    },
    dnsPrefetchControl: {
      allow: false
    },
    permittedCrossDomainPolicies: {
      permittedPolicies: "none"
    }
  };

  if (!usesHttps && Meteor.isDevelopment) {
    delete options.contentSecurityPolicy.directives.blockAllMixedContent;
    options.contentSecurityPolicy.directives.scriptSrc = [self, unsafeEval, unsafeInline];
  }

  return options;
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/routes.js                                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SatelliteCollection;
module.link("/imports/api/satellites", {
  SatelliteCollection(v) {
    SatelliteCollection = v;
  }

}, 1);
let SchemaCollection;
module.link("/imports/api/schemas", {
  SchemaCollection(v) {
    SchemaCollection = v;
  }

}, 2);
WebApp.connectHandlers.use("/api/satellites", (req, res, next) => Promise.asyncApply(() => {
  function getSats() {
    return Promise.asyncApply(() => {
      res.setHeader("Content-Type", "application/json");
      const sats = Promise.await(SatelliteCollection.find({}));

      if (req.query.limit) {
        const limiter = parseInt(req.query.limit);
        const page = parseInt(req.query.page);
        const skipper = limiter * page;

        try {
          const result = Promise.await(SatelliteCollection.find({}, {
            limit: limiter,
            skip: skipper
          }).fetch());

          if (result.length > 0) {
            res.writeHead(200);
            res.end(JSON.stringify(result));
          } else {
            error = {
              error: "Could not fetch sat based on noradID - non-existent noradID"
            };
            res.writeHead(500);
            res.end(JSON.stringify(error));
          }
        } catch (err) {
          error = {
            error: "Could not fetch limit"
          };
          res.writeHead(500);
          res.end(JSON.stringify(error));
        }
      } else if (req.query.noradID || req.query.id || req.query.noradid) {
        try {
          const noradID = req.query.noradID || req.query.id || req.query.noradid;
          const result = Promise.await(SatelliteCollection.find({
            noradID: {
              $regex: noradID
            }
          }).fetch());

          if (result.length > 0) {
            res.writeHead(200);
            res.end(JSON.stringify(result));
          } else {
            error = {
              error: "Could not fetch sat based on noradID - non-existent noradID."
            };
            res.writeHead(500);
            res.end(JSON.stringify(error));
          }
        } catch (err) {
          error = {
            error: "Could not fetch list of sats"
          };
          res.writeHead(500);
          res.end(JSON.stringify(error));
        }
      } else if (req.query.name) {
        let result = null;

        try {
          const target = req.query.name;
          const result = SatelliteCollection.find({
            "names.name": {
              $regex: "".concat(target),
              $options: "i"
            }
          }).fetch();

          if (result.length > 0 && result[0] !== undefined) {
            console.log('result ', result[0]);
            res.writeHead(200);
            res.end(JSON.stringify(result));
          } // sats.fetch().forEach((sat) => {
          //   let bool = sat.names.find((name) => {
          //     return name.names || name.name === target ? true : false;
          //   });
          //   if (bool) {
          //     result = sat;
          //   }
          // });
          // if (result) {
          //   res.writeHead(200);
          //   res.end(JSON.stringify(result));
          // } 
          else {
            error = {
              error: "Could not fetch sat based on name - non-existent name. And I should know. I invented satellites."
            };
            res.writeHead(500);
            res.end(JSON.stringify(error));
          }
        } catch (err) {
          error = {
            error: "Could not fetch list of sats"
          };
          res.writeHead(500);
          res.end(JSON.stringify(error));
        }
      } else if (req.query.type) {
        let result = null;

        try {
          const target = req.query.type;
          sats.fetch().forEach(sat => {
            let bool = sat.type.find(type => {
              return type.type || type.type === target ? true : false;
            });

            if (bool) {
              result = sat;
            }
          });

          if (result) {
            res.writeHead(200);
            res.end(JSON.stringify(result));
          } else {
            error = {
              error: "Could not fetch sat based on type - non-existent type"
            };
            res.writeHead(500);
            res.end(JSON.stringify(error));
          }
        } catch (err) {
          error = {
            error: "Could not fetch list of sats"
          };
          res.writeHead(500);
          res.end(JSON.stringify(error));
        }
      } else if (req.query.orbit) {
        let result = null;

        try {
          const target = req.query.orbit;
          sats.fetch().forEach(sat => {
            let bool = sat.orbit.find(orbit => {
              return orbit.orbit || orbit.orbit === target ? true : false;
            });

            if (bool) {
              result = sat;
            }
          });

          if (result) {
            res.writeHead(200);
            res.end(JSON.stringify(result));
          } else {
            error = {
              error: "Could not fetch sat based on orbit - non-existent orbit"
            };
            res.writeHead(500);
            res.end(JSON.stringify(error));
          }
        } catch (err) {
          error = {
            error: "Could not fetch list of sats"
          };
          res.writeHead(500);
          res.end(JSON.stringify(error));
        }
      } else {
        try {
          res.writeHead(200);
          res.end(JSON.stringify(sats.fetch()));
        } catch (err) {
          error = {
            error: "Could not fetch list of sats"
          };
          res.writeHead(500);
          res.end(JSON.stringify(error));
        }
      }
    });
  }

  getSats();
}));
WebApp.connectHandlers.use("/api/schemas", (req, res, next) => {
  function getSchema() {
    res.setHeader("Content-Type", "application/json");

    try {
      schemaName = req.query.name;

      if (schemaName && schemaName !== "") {
        res.writeHead(200);
        res.end(JSON.stringify(SchemaCollection.find({
          name: "".concat(req.query.name)
        }).fetch()));
      } else {
        res.writeHead(200);
        res.end(JSON.stringify(SchemaCollection.find().fetch()));
      }
    } catch (err) {
      error = {
        error: "Could not fetch schemas"
      };
      res.writeHead(500);
      res.end(JSON.stringify(error));
    }
  }

  getSchema();
});
WebApp.connectHandlers.use("/api/", (req, res, next) => {
  res.setHeader("Content-Type", "application/json");
  res.writeHead(200);
  res.end(JSON.stringify("Welcome to the PROBE API! For documentation, please visit the README at https://github.com/justinthelaw/PROBE."));
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Yup;
module.link("yup", {
  "*"(v) {
    Yup = v;
  }

}, 0);
let helmet;
module.link("helmet", {
  default(v) {
    helmet = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 3);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 4);
let SchemaCollection;
module.link("/imports/api/schemas", {
  SchemaCollection(v) {
    SchemaCollection = v;
  }

}, 5);
let SatelliteCollection;
module.link("/imports/api/satellites", {
  SatelliteCollection(v) {
    SatelliteCollection = v;
  }

}, 6);
let UsersCollection;
module.link("/imports/api/users", {
  UsersCollection(v) {
    UsersCollection = v;
  }

}, 7);
let ErrorsCollection;
module.link("/imports/api/errors", {
  ErrorsCollection(v) {
    ErrorsCollection = v;
  }

}, 8);
let helmetOptions;
module.link("./helmet", {
  helmetOptions(v) {
    helmetOptions = v;
  }

}, 9);
let schemaValidatorShaper;
module.link("./validators/schemaDataFuncs", {
  schemaValidatorShaper(v) {
    schemaValidatorShaper = v;
  }

}, 10);
let satelliteValidatorShaper;
module.link("./validators/satelliteDataFuncs", {
  satelliteValidatorShaper(v) {
    satelliteValidatorShaper = v;
  }

}, 11);
module.link("./routes");

const fs = Npm.require("fs");

const isValidEmail = (oldEmail, newEmail) => {
  const oldCheck = oldEmail ? oldEmail !== newEmail : true;
  const schema = Yup.string().email();
  return schema.isValidSync(newEmail) && oldCheck && newEmail.length < 128;
};

const isValidUsername = (oldUsername, newUsername) => {
  const oldCheck = oldUsername ? oldUsername !== newUsername : true;
  const regex = /^[a-zA-Z0-9]{4,}$/g;
  return regex.test(newUsername) && oldCheck && newUsername.length < 32;
};

isValidPassword = (oldPassword, newPassword) => {
  const oldCheck = oldPassword ? oldPassword !== newPassword : true;
  const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/g;
  return regex.test(newPassword) && oldCheck && newPassword.length < 128;
};

Meteor.startup(() => {
  console.log("============PROBE server is running============"); // See helmet.js for Content Security Policy (CSP) options

  WebApp.connectHandlers.use(helmet(helmetOptions())); // Account publications, methods, and seeds

  Roles.createRole("admin", {
    unlessExists: true
  });
  Roles.createRole("moderator", {
    unlessExists: true
  });
  Roles.createRole("dummies", {
    unlessExists: true
  }); // Email verificationa dn password reset emails

  Accounts.config({
    sendVerificationEmail: false
  });

  Accounts.urls.resetPassword = token => {
    return Meteor.absoluteUrl("/reset?token=".concat(token));
  };

  Accounts.urls.verifyEmail = token => {
    return Meteor.absoluteUrl("/verify?token=".concat(token));
  }; // Publish user list and user roles


  Meteor.publish("roles", () => {
    if (Meteor.user()) {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        return [Meteor.users.find(), Meteor.roles.find(), Meteor.roleAssignment.find()];
      } else {
        return [Meteor.users.find({
          _id: Meteor.user()._id
        }), Meteor.roles.find({
          _id: Meteor.user()._id
        }), Meteor.roleAssignment.find({
          _id: Meteor.user()._id
        })];
      }
    } else {
      return [];
    }
  }); // Account creation and managment methods

  Meteor.methods({
    userExists: username => {
      if (Accounts.findUserByUsername(username)) {
        return "Username already exists.";
      }
    },
    emailExists: email => {
      if (Accounts.findUserByEmail(email)) {
        return "That email is already in use";
      } else {
        return;
      }
    },
    addUserToRole: (user, role) => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        Roles.addUsersToRoles(Accounts.findUserByUsername(user.username), role);

        if (role === "dummies") {
          Meteor.users.update(user._id, {
            $set: {
              "services.resume.loginTokens": []
            }
          }, {
            multi: true
          });
        }

        UsersCollection.update({
          _id: user._id
        }, Accounts.findUserByUsername(user.username));
        return "".concat(user._id, " added to ").concat(role);
      } else {
        return "Unauthorized [401]";
      }
    },
    deleteAccount: id => {
      if (Meteor.userId() === id || Roles.userIsInRole(Meteor.userId(), "admin")) {
        Meteor.users.remove({
          _id: id
        });
        UsersCollection.remove(id);
        return "User ".concat(id, " has successfully been deleted");
      } else {
        return "Unauthorized [401]";
      }
    },
    updateUsername: (id, user, newUsername) => {
      if (Meteor.userId() === id) {
        if (isValidUsername(user, newUsername)) {
          Accounts.setUsername(id, newUsername);
          UsersCollection.update({
            _id: id
          }, Meteor.user());
          return "Account changes successfully made";
        } else {
          return "The provided username, ".concat(newUsername, ", is invalid");
        }
      } else {
        return "Unauthorized [401]";
      }
    },
    updateEmail: (id, email, newEmail) => {
      if (Meteor.userId() === id) {
        if (isValidEmail(email, newEmail)) {
          Accounts.removeEmail(id, email);
          Accounts.addEmail(id, newEmail);
          Accounts.sendVerificationEmail(id, newEmail);
          UsersCollection.update({
            _id: id
          }, Meteor.user());
          return "Account changes successfully made";
        } else {
          return "The provided email, ".concat(newEmail, ", is invalid");
        }
      } else {
        return "Unauthorized [401]";
      }
    },
    addToFavorites: (user, noradID) => {
      if (Meteor.userId) {
        let favorites = Meteor.user().favorites;

        if (favorites.indexOf(noradID) === -1) {
          favorites.push(noradID);
        } else {
          favorites.splice(favorites.indexOf(noradID), 1);
        }

        Meteor.users.update(user, {
          $set: {
            favorites: favorites
          }
        });
        return Meteor.user().favorites;
      } else {
        return ["Unauthorized [401]"];
      }
    },
    removeRole: (user, role) => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        try {
          Roles.removeUsersFromRoles(user._id, role);
          UsersCollection.update({
            _id: user._id
          }, Accounts.findUserByUsername(user.username));
          return "User ".concat(user._id, " added to role ").concat(role);
        } catch (err) {
          return err;
        }
      } else {
        return "Unauthorized [401]";
      }
    },
    checkIfBanned: user => {
      let userFinder = Accounts.findUserByUsername(user) || Accounts.findUserByEmail(user);
      return Roles.userIsInRole(userFinder === null || userFinder === void 0 ? void 0 : userFinder._id, "dummies");
    },
    sendEmail: (id, email) => {
      if (Meteor.userId() === id) {
        Accounts.sendVerificationEmail(id, email);
      } else {
        return "Unauthorized [401]";
      }
    },
    registerUser: (email, username, password) => {
      if (isValidEmail(null, email) && isValidUsername(null, username) && isValidPassword(null, password)) {
        try {
          Accounts.createUser({
            email: email,
            username: username,
            password: password
          });
          return "Welcome to PROBE, ".concat(username, "!");
        } catch (err) {
          return err.message;
        }
      } else {
        return "An error occured while creating your account. Please try again later!";
      }
    }
  });
  Accounts.onCreateUser((_, user) => {
    user["favorites"] = [];
    user["roles"] = [];
    UsersCollection.insert(user);
    return user;
  }); // Seed admin account for testing

  Meteor.call("userExists", "admin", (_, res) => {
    if (res) {
      return;
    } else {
      Accounts.createUser({
        email: "admin@gmail.com",
        username: "admin",
        password: "12345678aA!"
      });
      Roles.addUsersToRoles(Accounts.findUserByUsername("admin"), "admin");
    }
  }); // Error methods

  Meteor.methods({
    addError: obj => {
      ErrorsCollection.insert(obj);
    }
  }); // Errors publication and seed data

  if (ErrorsCollection.find().count() === 0) {
    console.log("ErrorsCollection Seeded");
    const errors = {
      user: 00000000000000000,
      time: new Date(),
      msg: "Database Reset",
      source: "Test Error",
      error: {}
    };
    ErrorsCollection.insert(errors); // ErrorsCollection.remove({});
  }

  Meteor.publish("errors", () => {
    return ErrorsCollection.find({});
  }); // Accounts publication and seed data

  if (UsersCollection.find().count() === 0) {
    console.log("UsersCollection Seeded");
    const users = Meteor.users.find({}, {
      fields: {
        _id: 1,
        username: 1,
        emails: 1,
        roles: 1
      }
    }).fetch(); // UsersCollection.remove({}); // change the "=== 0" to "> 0" to wipe the userList

    users.forEach(user => UsersCollection.insert(user));
  }

  Meteor.publish("userList", () => {
    return UsersCollection.find({});
  }); // Satellite and schema publications and seed data
  // Seed schema data

  if (SchemaCollection.find().count() === 0) {
    console.log("SchemaCollection Seeded");
    var jsonObj = [];
    files = fs.readdirSync("./assets/app/schema");
    files.forEach(function (file) {
      data = fs.readFileSync("./assets/app/schema/" + file, "ascii");
      jsonObj.push(JSON.parse(data));
    });
    jsonObj.forEach(function (data) {
      SchemaCollection.insert(data);
    });
  } // Seed satellite data


  if (SatelliteCollection.find().count() === 0) {
    console.log("SatelliteCollection Seeded");
    var jsonObj = [];
    files = fs.readdirSync("./assets/app/satellite");
    files.forEach(function (file) {
      data = fs.readFileSync("./assets/app/satellite/" + file, "ascii");
      jsonObj.push(JSON.parse(data));
    });
    jsonObj.forEach(function (data) {
      SatelliteCollection.insert(data);
    });
  } // Publish satellites collection


  Meteor.publish("satellites", () => {
    return SatelliteCollection.find({});
  }); // Publish schemas collection

  Meteor.publish("schemas", () => {
    return SchemaCollection.find({});
  }); // Satellite methods

  Meteor.methods({
    addNewSatellite: (values, initValues) => {
      if (Meteor.userId()) {
        let error = null;
        values["isDeleted"] = false;
        values["createdOn"] = new Date();
        values["createdBy"] = Meteor.user().username;
        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        values["adminCheck"] = false;
        satelliteValidatorShaper(values, initValues).validate(values).then(() => {
          if (Roles.userIsInRole(Meteor.userId(), "admin")) {
            values["adminCheck"] = true;
          }

          SatelliteCollection.insert(values);
        }).catch(err => error = err);
        return error;
      } else {
        return "Unauthorized [401]";
      }
    },
    updateSatellite: (values, initValues) => {
      if (Meteor.userId()) {
        let error = null;

        if (!values["createdOn"] || !values["createdBy"]) {
          values["createdOn"] = new Date();
          values["createdBy"] = Meteor.user().username;
        }

        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        values["adminCheck"] = false;
        satelliteValidatorShaper(values, initValues).validate(values).then(() => {
          if (Roles.userIsInRole(Meteor.userId(), "admin")) {
            values["adminCheck"] = true;
          }

          SatelliteCollection.update({
            _id: values._id
          }, values);
        }).catch(err => error = err);
        return error;
      } else {
        return "Unauthorized [401]";
      }
    },
    deleteSatellite: values => {
      if (Meteor.userId()) {
        values["isDeleted"] = true;
        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        SatelliteCollection.update({
          _id: values._id
        }, values);
      } else {
        return "Unauthorized [401]";
      }
    },
    actuallyDeleteSatellite: values => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        SatelliteCollection.remove(values._id);
      } else {
        return "Unauthorized [401]";
      }
    },
    restoreSatellite: values => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        values["isDeleted"] = false;
        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        SatelliteCollection.update({
          _id: values._id
        }, values);
      } else {
        return "Unauthorized [401]";
      }
    },
    adminCheckSatellite: values => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        values["adminCheck"] = true;
        SatelliteCollection.update({
          _id: values._id
        }, values);
      } else {
        return "Unauthorized [401]";
      }
    }
  }); // Schema methods

  Meteor.methods({
    addNewSchema: (initValues, values) => {
      if (Meteor.userId()) {
        let error = null;
        const schemas = SchemaCollection.find().fetch();
        values["isDeleted"] = false;
        values["createdOn"] = new Date();
        values["createdBy"] = Meteor.user().username;
        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        values["adminCheck"] = false;
        schemaValidatorShaper(initValues, schemas).validate(values).then(() => {
          if (Roles.userIsInRole(Meteor.userId(), "admin")) {
            values["adminCheck"] = true;
          }

          return SchemaCollection.insert(values);
        }).catch(error => {
          err = error;
        });
        return error;
      } else {
        return "Unauthorized [401]";
      }
    },
    updateSchema: (initValues, values) => {
      if (Meteor.userId()) {
        let error = null;
        const schemas = SchemaCollection.find().fetch();

        if (!values["createdOn"] || !values["createdBy"]) {
          values["createdOn"] = new Date();
          values["createdBy"] = Meteor.user().username;
        }

        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        values["adminCheck"] = false;
        schemaValidatorShaper(initValues, schemas).validate(values).then(() => {
          if (Roles.userIsInRole(Meteor.userId(), "admin")) {
            values["adminCheck"] = true;
          }

          return SchemaCollection.update({
            _id: values._id
          }, values);
        }).catch(err => console.err(err));
        return error;
      } else {
        return "Unauthorized [401]";
      }
    },
    deleteSchema: values => {
      if (Meteor.userId()) {
        values["isDeleted"] = true;
        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        SchemaCollection.update({
          _id: values._id
        }, values);
      } else {
        return "Unauthorized [401]";
      }
    },
    actuallyDeleteSchema: values => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        SchemaCollection.remove(values._id);
      } else {
        return "Unauthorized [401]";
      }
    },
    restoreSchema: values => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        values["isDeleted"] = false;
        values["modifiedOn"] = new Date();
        values["modifiedBy"] = Meteor.user().username;
        SchemaCollection.update({
          _id: values._id
        }, values);
      } else {
        return "Unauthorized [401]";
      }
    },
    adminCheckSchema: values => {
      if (Roles.userIsInRole(Meteor.userId(), "admin")) {
        values["adminCheck"] = true;
        SchemaCollection.update({
          _id: values._id
        }, values);
      } else {
        return "Unauthorized [401]";
      }
    }
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZXJyb3JzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zYXRlbGxpdGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zY2hlbWFzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS91c2Vycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3ZhbGlkYXRvcnMvc2F0ZWxsaXRlRGF0YUZ1bmNzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdmFsaWRhdG9ycy9zY2hlbWFEYXRhRnVuY3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9oZWxtZXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb3V0ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkVycm9yc0NvbGxlY3Rpb24iLCJNb25nbyIsImxpbmsiLCJ2IiwiQ29sbGVjdGlvbiIsIlNhdGVsbGl0ZUNvbGxlY3Rpb24iLCJTY2hlbWFDb2xsZWN0aW9uIiwiVXNlcnNDb2xsZWN0aW9uIiwic2F0ZWxsaXRlVmFsaWRhdG9yU2hhcGVyIiwiWXVwIiwiaXNVbmlxdWVMaXN0IiwiaW5pdFZhbHVlcyIsInNhdHMiLCJwYXRoIiwiZmllbGQiLCJsaXN0Iiwic2F0IiwicHVzaCIsInNhdEVudHJpZXMiLCJlbnRyeSIsImxlbmd0aCIsInNjaGVtYUNsZWFuZXIiLCJzY2hlbWFzIiwidmFsdWVzIiwic2NoZW1hT2JqIiwiY2xlYW5TY2hlbWFzIiwidmFsdWUiLCJzY2hlbWEiLCJuYW1lIiwiZm9yRWFjaCIsImZpZWxkcyIsImF0dHJpYnV0ZSIsImluaXRpYWxZdXBTaGFwZUdlbmVyYXRvciIsIl9pZCIsInN0cmluZyIsIm5vdE9uZU9mIiwibm9yYWRJRCIsInJlcXVpcmVkIiwibWF0Y2hlcyIsIm9iaiIsImFkbWluQ2hlY2siLCJib29sZWFuIiwibW9kaWZpZWRPbiIsImRhdGUiLCJtb2RpZmllZEJ5IiwiY3JlYXRlZE9uIiwiY3JlYXRlZEJ5IiwiZmluZCIsImZldGNoIiwieXVwU2hhcGUiLCJjbGVhblNjaGVtYSIsImFkZE1ldGhvZCIsIm1peGVkIiwibWVzc2FnZSIsImVyck9iaiIsInRlc3QiLCJjcmVhdGVFcnJvciIsImVudHJ5Q291bnQiLCJmaWVsZE9iaiIsImZpZWxkQ291bnQiLCJzY2hlbWFGaWVsZCIsInRlbXBGaWVsZFNjaGVtYSIsInR5cGUiLCJiYXNlRmllbGRUeXBlIiwiZmllbGRTY2hlbWFNYXRyaXgiLCJ0b1VwcGVyQ2FzZSIsInN1YnN0ciIsInVybCIsImFsbG93ZWRWYWx1ZXMiLCJvbmVPZiIsImpvaW4iLCJpc1VuaXF1ZSIsIm1pbiIsIm1heCIsInN0cmluZ01heCIsImNoZWNrIiwiY29uY2F0IiwiZmllbGRWYWxpZGF0b3IiLCJvYmplY3QiLCJzaGFwZSIsInZhbGlkYXRlIiwiYWJvcnRFYXJseSIsInRoZW4iLCJjYXRjaCIsImVyciIsInVuZGVmaW5lZCIsIkpTT04iLCJzdHJpbmdpZnkiLCJlcnJQYXRoIiwiZXJyTWVzc2FnZSIsImNsZWFuTWVzc2FnZSIsImluZGV4T2YiLCJjbGVhblBhdGgiLCJhcnJheSIsImNoZWNrRWFjaEVudHJ5Iiwic2NoZW1hVmFsaWRhdG9yU2hhcGVyIiwidW5pcXVlTmFtZXMiLCJtYXAiLCJkZXNjcmlwdGlvbiIsIm9mIiwiZW5zdXJlIiwibnVtYmVyIiwibnVsbGFibGUiLCJub3RSZXF1aXJlZCIsIndoZW4iLCJoZWxtZXRPcHRpb25zIiwiTWV0ZW9yIiwiV2ViQXBwIiwiQXV0b3VwZGF0ZSIsImNyeXB0byIsImRlZmF1bHQiLCJoZWxtZXQiLCJzZWxmIiwiZGF0YSIsInVuc2FmZUV2YWwiLCJ1bnNhZmVJbmxpbmUiLCJhbGxvd2VkT3JpZ2lucyIsInNldHRpbmdzIiwiYWJzb2x1dGVVcmwiLCJkb21haW4iLCJyZXBsYWNlIiwicyIsIm1hdGNoIiwidXNlc0h0dHBzIiwiY29ubmVjdFNyYyIsIm9wdGlvbnMiLCJjb250ZW50U2VjdXJpdHlQb2xpY3kiLCJibG9ja0FsbE1peGVkQ29udGVudCIsImRpcmVjdGl2ZXMiLCJkZWZhdWx0U3JjIiwic2NyaXB0U3JjIiwiY2hpbGRTcmMiLCJmb250U3JjIiwiZm9ybUFjdGlvbiIsImZyYW1lQW5jZXN0b3JzIiwiZnJhbWVTcmMiLCJpbWdTcmMiLCJtYW5pZmVzdFNyYyIsIm1lZGlhU3JjIiwib2JqZWN0U3JjIiwic2FuZGJveCIsInN0eWxlU3JjIiwid29ya2VyU3JjIiwic3RyaWN0VHJhbnNwb3J0U2VjdXJpdHkiLCJtYXhBZ2UiLCJpbmNsdWRlU3ViRG9tYWlucyIsInByZWxvYWQiLCJyZWZlcnJlclBvbGljeSIsInBvbGljeSIsImV4cGVjdEN0IiwiZW5mb3JjZSIsImZyYW1lZ3VhcmQiLCJhY3Rpb24iLCJkbnNQcmVmZXRjaENvbnRyb2wiLCJhbGxvdyIsInBlcm1pdHRlZENyb3NzRG9tYWluUG9saWNpZXMiLCJwZXJtaXR0ZWRQb2xpY2llcyIsImlzRGV2ZWxvcG1lbnQiLCJjb25uZWN0SGFuZGxlcnMiLCJ1c2UiLCJyZXEiLCJyZXMiLCJuZXh0IiwiZ2V0U2F0cyIsInNldEhlYWRlciIsInF1ZXJ5IiwibGltaXQiLCJsaW1pdGVyIiwicGFyc2VJbnQiLCJwYWdlIiwic2tpcHBlciIsInJlc3VsdCIsInNraXAiLCJ3cml0ZUhlYWQiLCJlbmQiLCJlcnJvciIsImlkIiwibm9yYWRpZCIsIiRyZWdleCIsInRhcmdldCIsIiRvcHRpb25zIiwiY29uc29sZSIsImxvZyIsImJvb2wiLCJvcmJpdCIsImdldFNjaGVtYSIsInNjaGVtYU5hbWUiLCJSb2xlcyIsIkFjY291bnRzIiwiZnMiLCJOcG0iLCJyZXF1aXJlIiwiaXNWYWxpZEVtYWlsIiwib2xkRW1haWwiLCJuZXdFbWFpbCIsIm9sZENoZWNrIiwiZW1haWwiLCJpc1ZhbGlkU3luYyIsImlzVmFsaWRVc2VybmFtZSIsIm9sZFVzZXJuYW1lIiwibmV3VXNlcm5hbWUiLCJyZWdleCIsImlzVmFsaWRQYXNzd29yZCIsIm9sZFBhc3N3b3JkIiwibmV3UGFzc3dvcmQiLCJzdGFydHVwIiwiY3JlYXRlUm9sZSIsInVubGVzc0V4aXN0cyIsImNvbmZpZyIsInNlbmRWZXJpZmljYXRpb25FbWFpbCIsInVybHMiLCJyZXNldFBhc3N3b3JkIiwidG9rZW4iLCJ2ZXJpZnlFbWFpbCIsInB1Ymxpc2giLCJ1c2VyIiwidXNlcklzSW5Sb2xlIiwidXNlcklkIiwidXNlcnMiLCJyb2xlcyIsInJvbGVBc3NpZ25tZW50IiwibWV0aG9kcyIsInVzZXJFeGlzdHMiLCJ1c2VybmFtZSIsImZpbmRVc2VyQnlVc2VybmFtZSIsImVtYWlsRXhpc3RzIiwiZmluZFVzZXJCeUVtYWlsIiwiYWRkVXNlclRvUm9sZSIsInJvbGUiLCJhZGRVc2Vyc1RvUm9sZXMiLCJ1cGRhdGUiLCIkc2V0IiwibXVsdGkiLCJkZWxldGVBY2NvdW50IiwicmVtb3ZlIiwidXBkYXRlVXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInVwZGF0ZUVtYWlsIiwicmVtb3ZlRW1haWwiLCJhZGRFbWFpbCIsImFkZFRvRmF2b3JpdGVzIiwiZmF2b3JpdGVzIiwic3BsaWNlIiwicmVtb3ZlUm9sZSIsInJlbW92ZVVzZXJzRnJvbVJvbGVzIiwiY2hlY2tJZkJhbm5lZCIsInVzZXJGaW5kZXIiLCJzZW5kRW1haWwiLCJyZWdpc3RlclVzZXIiLCJwYXNzd29yZCIsImNyZWF0ZVVzZXIiLCJvbkNyZWF0ZVVzZXIiLCJfIiwiaW5zZXJ0IiwiY2FsbCIsImFkZEVycm9yIiwiY291bnQiLCJlcnJvcnMiLCJ0aW1lIiwiRGF0ZSIsIm1zZyIsInNvdXJjZSIsImVtYWlscyIsImpzb25PYmoiLCJmaWxlcyIsInJlYWRkaXJTeW5jIiwiZmlsZSIsInJlYWRGaWxlU3luYyIsInBhcnNlIiwiYWRkTmV3U2F0ZWxsaXRlIiwidXBkYXRlU2F0ZWxsaXRlIiwiZGVsZXRlU2F0ZWxsaXRlIiwiYWN0dWFsbHlEZWxldGVTYXRlbGxpdGUiLCJyZXN0b3JlU2F0ZWxsaXRlIiwiYWRtaW5DaGVja1NhdGVsbGl0ZSIsImFkZE5ld1NjaGVtYSIsInVwZGF0ZVNjaGVtYSIsImRlbGV0ZVNjaGVtYSIsImFjdHVhbGx5RGVsZXRlU2NoZW1hIiwicmVzdG9yZVNjaGVtYSIsImFkbWluQ2hlY2tTY2hlbWEiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLGtCQUFnQixFQUFDLE1BQUlBO0FBQXRCLENBQWQ7QUFBdUQsSUFBSUMsS0FBSjtBQUFVSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNELE9BQUssQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFNBQUssR0FBQ0UsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUUxRCxNQUFNSCxnQkFBZ0IsR0FBRyxJQUFJQyxLQUFLLENBQUNHLFVBQVYsQ0FBcUIsUUFBckIsQ0FBekIsQzs7Ozs7Ozs7Ozs7QUNGUE4sTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ00scUJBQW1CLEVBQUMsTUFBSUE7QUFBekIsQ0FBZDtBQUE2RCxJQUFJSixLQUFKO0FBQVVILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0QsT0FBSyxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsU0FBSyxHQUFDRSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRWhFLE1BQU1FLG1CQUFtQixHQUFHLElBQUlKLEtBQUssQ0FBQ0csVUFBVixDQUFxQixZQUFyQixDQUE1QixDOzs7Ozs7Ozs7OztBQ0ZQTixNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDTyxrQkFBZ0IsRUFBQyxNQUFJQTtBQUF0QixDQUFkO0FBQXVELElBQUlMLEtBQUo7QUFBVUgsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRCxPQUFLLENBQUNFLENBQUQsRUFBRztBQUFDRixTQUFLLEdBQUNFLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFMUQsTUFBTUcsZ0JBQWdCLEdBQUcsSUFBSUwsS0FBSyxDQUFDRyxVQUFWLENBQXFCLFNBQXJCLENBQXpCLEM7Ozs7Ozs7Ozs7O0FDRlBOLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNRLGlCQUFlLEVBQUMsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJTixLQUFKO0FBQVVILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0QsT0FBSyxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsU0FBSyxHQUFDRSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXhELE1BQU1JLGVBQWUsR0FBRyxJQUFJTixLQUFLLENBQUNHLFVBQVYsQ0FBcUIsVUFBckIsQ0FBeEIsQzs7Ozs7Ozs7Ozs7QUNGUE4sTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ1MsMEJBQXdCLEVBQUMsTUFBSUE7QUFBOUIsQ0FBZDtBQUF1RSxJQUFJQyxHQUFKO0FBQVFYLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLEtBQVosRUFBa0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQ00sT0FBRyxHQUFDTixDQUFKO0FBQU07O0FBQWQsQ0FBbEIsRUFBa0MsQ0FBbEM7QUFBcUMsSUFBSUcsZ0JBQUo7QUFBcUJSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNJLGtCQUFnQixDQUFDSCxDQUFELEVBQUc7QUFBQ0csb0JBQWdCLEdBQUNILENBQWpCO0FBQW1COztBQUF4QyxDQUFuQyxFQUE2RSxDQUE3RTtBQUFnRixJQUFJRSxtQkFBSjtBQUF3QlAsTUFBTSxDQUFDSSxJQUFQLENBQVkseUJBQVosRUFBc0M7QUFBQ0cscUJBQW1CLENBQUNGLENBQUQsRUFBRztBQUFDRSx1QkFBbUIsR0FBQ0YsQ0FBcEI7QUFBc0I7O0FBQTlDLENBQXRDLEVBQXNGLENBQXRGOztBQVFqUCxNQUFNTyxZQUFZLEdBQUcsQ0FBQ0MsVUFBRCxFQUFhQyxJQUFiLEVBQW1CQyxJQUFuQixFQUF5QkMsS0FBekIsS0FBbUM7QUFDdEQsTUFBSUMsSUFBSSxHQUFHLEVBQVg7O0FBQ0EsTUFBSSxDQUFDRixJQUFMLEVBQVc7QUFDVCxTQUFLLElBQUlHLEdBQVQsSUFBZ0JKLElBQWhCLEVBQXNCO0FBQ3BCQSxVQUFJLENBQUNJLEdBQUQsQ0FBSixDQUFVRixLQUFWLE1BQXFCSCxVQUFVLENBQUNHLEtBQUQsQ0FBL0IsR0FDSSxJQURKLEdBRUlDLElBQUksQ0FBQ0UsSUFBTCxDQUFVTCxJQUFJLENBQUNJLEdBQUQsQ0FBSixDQUFVRixLQUFWLENBQVYsQ0FGSjtBQUdEO0FBQ0YsR0FORCxNQU1PLElBQUlILFVBQVUsQ0FBQ0UsSUFBRCxDQUFkLEVBQXNCO0FBQzNCLFNBQUssSUFBSUcsR0FBVCxJQUFnQkosSUFBaEIsRUFBc0I7QUFDcEIsVUFBSU0sVUFBVSxHQUFHTixJQUFJLENBQUNJLEdBQUQsQ0FBSixDQUFVSCxJQUFWLENBQWpCOztBQUNBLFdBQUssSUFBSU0sS0FBVCxJQUFrQkQsVUFBbEIsRUFBOEI7QUFDNUJBLGtCQUFVLENBQUNDLEtBQUQsQ0FBVixDQUFrQkwsS0FBbEIsT0FDQ0gsVUFBVSxDQUFDRSxJQUFELENBQVYsQ0FBaUJPLE1BQWpCLEdBQTBCLENBQTFCLEdBQThCVCxVQUFVLENBQUNFLElBQUQsQ0FBVixDQUFpQk0sS0FBakIsRUFBd0JMLEtBQXhCLENBQTlCLEdBQStELEtBRGhFLElBRUksSUFGSixHQUdJQyxJQUFJLENBQUNFLElBQUwsQ0FBVUMsVUFBVSxDQUFDQyxLQUFELENBQVYsQ0FBa0JMLEtBQWxCLENBQVYsQ0FISjtBQUlEO0FBQ0Y7QUFDRjs7QUFDRCxTQUFPQyxJQUFQO0FBQ0QsQ0FwQkQ7O0FBc0JBLE1BQU1NLGFBQWEsR0FBRyxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDekMsTUFBSUMsU0FBUyxHQUFHLEVBQWhCLENBRHlDLENBQ3JCOztBQUVwQixNQUFJQyxZQUFZLEdBQUcsRUFBbkIsQ0FIeUMsQ0FHbEI7O0FBQ3ZCLE9BQUssSUFBSUMsS0FBVCxJQUFrQkgsTUFBbEIsRUFBMEI7QUFDeEIsU0FBSyxJQUFJSSxNQUFULElBQW1CTCxPQUFuQixFQUE0QjtBQUMxQixVQUFJQSxPQUFPLENBQUNLLE1BQUQsQ0FBUCxDQUFnQkMsSUFBaEIsS0FBeUJGLEtBQTdCLEVBQW9DRCxZQUFZLENBQUNSLElBQWIsQ0FBa0JLLE9BQU8sQ0FBQ0ssTUFBRCxDQUF6QjtBQUNyQztBQUNGOztBQUVERixjQUFZLFNBQVosSUFBQUEsWUFBWSxXQUFaLFlBQUFBLFlBQVksQ0FBRUksT0FBZCxDQUF1QkYsTUFBRCxJQUFZO0FBQ2hDO0FBQ0FILGFBQVMsQ0FBQ0csTUFBTSxDQUFDQyxJQUFSLENBQVQsR0FBeUIsRUFBekIsQ0FGZ0MsQ0FHaEM7O0FBQ0EsV0FBT0QsTUFBTSxDQUFDRyxNQUFQLENBQWNELE9BQWQsQ0FBdUJmLEtBQUQsSUFBVztBQUN0Q1UsZUFBUyxDQUFDRyxNQUFNLENBQUNDLElBQVIsQ0FBVCxDQUF1QmQsS0FBSyxDQUFDYyxJQUE3QixJQUFxQyxFQUFyQyxDQURzQyxDQUV0Qzs7QUFDQSxXQUFLLElBQUlHLFNBQVQsSUFBc0JqQixLQUF0QixFQUE2QjtBQUMzQixZQUFJaUIsU0FBUyxLQUFLLE1BQWQsSUFBd0JBLFNBQVMsS0FBSyxhQUExQyxFQUF5RDtBQUN2RDtBQUNBUCxtQkFBUyxDQUFDRyxNQUFNLENBQUNDLElBQVIsQ0FBVCxDQUF1QmQsS0FBSyxDQUFDYyxJQUE3QixFQUFtQ0csU0FBbkMsSUFBZ0RqQixLQUFLLENBQUNpQixTQUFELENBQXJEO0FBQ0Q7QUFDRjtBQUNGLEtBVE0sQ0FBUDtBQVVELEdBZEQ7QUFlQSxTQUFPUCxTQUFQO0FBQ0QsQ0ExQkQ7O0FBNEJBLE1BQU1RLHdCQUF3QixHQUFHLENBQUNyQixVQUFELEVBQWFDLElBQWIsRUFBbUJGLFlBQW5CLEtBQW9DO0FBQ25FLFNBQU87QUFDTDtBQUNBdUIsT0FBRyxFQUFFeEIsR0FBRyxDQUFDeUIsTUFBSixHQUFhQyxRQUFiLENBQ0h6QixZQUFZLENBQUNDLFVBQUQsRUFBYUMsSUFBYixFQUFtQixJQUFuQixFQUF5QixLQUF6QixDQURULEVBRUgsMENBRkcsQ0FGQTtBQU1Md0IsV0FBTyxFQUFFM0IsR0FBRyxDQUFDeUIsTUFBSixHQUNORyxRQURNLGFBRU5DLE9BRk0sQ0FFRSxXQUZGLEVBRWUsMkJBRmYsRUFHTkgsUUFITSxDQUlMekIsWUFBWSxDQUFDQyxVQUFELEVBQWFDLElBQWIsRUFBbUIsSUFBbkIsRUFBeUIsU0FBekIsQ0FKUCxFQUtKMkIsR0FBRCwwQ0FDaUNBLEdBQUcsQ0FBQ2IsS0FEckMsb0NBTEssQ0FOSjtBQWNMYyxjQUFVLEVBQUUvQixHQUFHLENBQUNnQyxPQUFKLEdBQWNKLFFBQWQsRUFkUDtBQWVMSyxjQUFVLEVBQUVqQyxHQUFHLENBQUNrQyxJQUFKLEdBQVdOLFFBQVgsRUFmUDtBQWdCTE8sY0FBVSxFQUFFbkMsR0FBRyxDQUFDeUIsTUFBSixHQUFhRyxRQUFiLEVBaEJQO0FBaUJMUSxhQUFTLEVBQUVwQyxHQUFHLENBQUNrQyxJQUFKLEdBQVdOLFFBQVgsRUFqQk47QUFrQkxTLGFBQVMsRUFBRXJDLEdBQUcsQ0FBQ3lCLE1BQUosR0FBYUcsUUFBYjtBQWxCTixHQUFQO0FBb0JELENBckJEOztBQXVCTyxNQUFNN0Isd0JBQXdCLEdBQUcsQ0FBQ2UsTUFBRCxFQUFTWixVQUFULEtBQXdCO0FBQzlELFFBQU1DLElBQUksR0FBR1AsbUJBQW1CLENBQUMwQyxJQUFwQixHQUEyQkMsS0FBM0IsRUFBYjtBQUNBLFFBQU0xQixPQUFPLEdBQUdoQixnQkFBZ0IsQ0FBQ3lDLElBQWpCLEdBQXdCQyxLQUF4QixFQUFoQjtBQUNBLE1BQUlDLFFBQVEsR0FBR2pCLHdCQUF3QixDQUFDckIsVUFBRCxFQUFhQyxJQUFiLEVBQW1CRixZQUFuQixDQUF2QyxDQUg4RCxDQUdXOztBQUN6RSxRQUFNd0MsV0FBVyxHQUFHN0IsYUFBYSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsQ0FBakMsQ0FKOEQsQ0FJVjs7QUFFcERkLEtBQUcsQ0FBQzBDLFNBQUosQ0FBYzFDLEdBQUcsQ0FBQzJDLEtBQWxCLEVBQXlCLGdCQUF6QixFQUEyQyxVQUFVQyxPQUFWLEVBQW1CO0FBQzVELFFBQUlDLE1BQU0sR0FBRyxFQUFiLENBRDRELENBQzNDO0FBQ2pCOztBQUNBLFdBQU8sS0FBS0MsSUFBTCxDQUFVLGdCQUFWLEVBQTRCRixPQUE1QixFQUFxQyxVQUFVM0IsS0FBVixFQUFpQjtBQUMzRCxZQUFNO0FBQUViLFlBQUY7QUFBUTJDO0FBQVIsVUFBd0IsSUFBOUIsQ0FEMkQsQ0FDdkI7O0FBQ3BDLFVBQUlDLFVBQVUsR0FBRyxDQUFqQixDQUYyRCxDQUV2Qzs7QUFDcEIvQixXQUFLLFNBQUwsSUFBQUEsS0FBSyxXQUFMLFlBQUFBLEtBQUssQ0FBRUcsT0FBUCxDQUFnQlYsS0FBRCxJQUFXO0FBQ3hCO0FBQ0EsWUFBSXVDLFFBQVEsR0FBRyxFQUFmO0FBQ0EsWUFBSUMsVUFBVSxHQUFHLENBQWpCO0FBQ0EsY0FBTWhDLE1BQU0sR0FBR3VCLFdBQVcsQ0FBQ3JDLElBQUQsQ0FBMUI7O0FBQ0EsYUFBSyxJQUFJK0MsV0FBVCxJQUF3QmpDLE1BQXhCLEVBQWdDO0FBQUE7O0FBQzlCO0FBQ0EsZ0JBQU1iLEtBQUssR0FBR2EsTUFBTSxDQUFDaUMsV0FBRCxDQUFwQixDQUY4QixDQUc5QjtBQUNBO0FBQ0E7O0FBQ0EsY0FBSUMsZUFBZSxHQUNqQi9DLEtBQUssQ0FBQ2dELElBQU4sS0FBZSxLQUFmLEdBQXVCckQsR0FBRyxDQUFDSyxLQUFLLENBQUNnRCxJQUFQLENBQUgsRUFBdkIsR0FBMkNyRCxHQUFHLENBQUMsUUFBRCxDQUFILEVBRDdDO0FBRUEsZ0JBQU1zRCxhQUFhLEdBQUdGLGVBQXRCLENBUjhCLENBUzlCOztBQUNBLGdCQUFNRyxpQkFBaUIsR0FBRztBQUN4QjNCLG9CQUFRLEVBQUV2QixLQUFLLENBQUN1QixRQUFOLEdBQ04wQixhQUFhLENBQUMxQixRQUFkLFdBQ0t4QixJQURMLGNBQ2E0QyxVQURiLGNBQzJCRSxVQUQzQixjQUVJN0MsS0FBSyxDQUFDZ0QsSUFBTixLQUFlLEtBQWYsR0FDSSxLQURKLEdBRUloRCxLQUFLLENBQUNnRCxJQUFOLENBQVcsQ0FBWCxFQUFjRyxXQUFkLEtBQ0FuRCxLQUFLLENBQUNnRCxJQUFOLENBQVdJLE1BQVgsQ0FBa0IsQ0FBbEIsQ0FEQSxHQUVBLFFBTlIsZUFETSxHQVVOLEtBWG9CO0FBWXhCQyxlQUFHLEVBQ0RyRCxLQUFLLENBQUNnRCxJQUFOLEtBQWUsS0FBZixHQUNJQyxhQUFhLENBQUNJLEdBQWQsV0FDS3RELElBREwsY0FDYTRDLFVBRGIsY0FDMkJFLFVBRDNCLDBFQURKLEdBSUksS0FqQmtCO0FBa0J4QlMseUJBQWEsRUFDWCx5QkFBQXRELEtBQUssQ0FBQ3NELGFBQU4sOEVBQXFCaEQsTUFBckIsSUFBOEIsQ0FBOUIsR0FDSTJDLGFBQWEsQ0FBQ00sS0FBZCxDQUNFLENBQUMsR0FBR3ZELEtBQUssQ0FBQ3NELGFBQVYsQ0FERixZQUVLdkQsSUFGTCxjQUVhNEMsVUFGYixjQUUyQkUsVUFGM0IsNENBRXVFN0MsS0FBSyxDQUFDc0QsYUFBTixDQUFvQkUsSUFBcEIsQ0FDbkUsSUFEbUUsQ0FGdkUsRUFESixHQU9JLEtBMUJrQjtBQTJCeEJDLG9CQUFRLEVBQUV6RCxLQUFLLENBQUN5RCxRQUFOLEdBQ05SLGFBQWEsQ0FBQzVCLFFBQWQsQ0FDRXpCLFlBQVksQ0FBQ0MsVUFBRCxFQUFhQyxJQUFiLEVBQW1CQyxJQUFuQixFQUF5QitDLFdBQXpCLENBRGQsWUFFSy9DLElBRkwsY0FFYTRDLFVBRmIsY0FFMkJFLFVBRjNCLCtCQUUwREMsV0FGMUQsaUJBRTRFbEMsS0FBSyxDQUFDK0IsVUFBRCxDQUFMLENBQWtCRyxXQUFsQixDQUY1RSxzQkFETSxHQUtOLEtBaENvQjtBQWlDeEJZLGVBQUcsRUFDRDFELEtBQUssQ0FBQ2dELElBQU4sS0FBZSxRQUFmLElBQTJCaEQsS0FBSyxDQUFDMkQsR0FBakMsR0FDSVYsYUFBYSxDQUFDUyxHQUFkLENBQ0UxRCxLQUFLLENBQUMwRCxHQURSLFlBRUszRCxJQUZMLGNBRWE0QyxVQUZiLGNBRTJCRSxVQUYzQixtQ0FFOEQ3QyxLQUFLLENBQUMwRCxHQUZwRSxFQURKLEdBS0ksS0F2Q2tCO0FBd0N4QkMsZUFBRyxFQUNEM0QsS0FBSyxDQUFDZ0QsSUFBTixLQUFlLFFBQWYsSUFBMkJoRCxLQUFLLENBQUMyRCxHQUFqQyxHQUNJVixhQUFhLENBQUNVLEdBQWQsQ0FDRTNELEtBQUssQ0FBQzJELEdBRFIsWUFFSzVELElBRkwsY0FFYTRDLFVBRmIsY0FFMkJFLFVBRjNCLHNDQUVpRTdDLEtBQUssQ0FBQzJELEdBRnZFLEVBREosR0FLSSxLQTlDa0I7QUErQ3hCQyxxQkFBUyxFQUNQNUQsS0FBSyxDQUFDZ0QsSUFBTixLQUFlLFFBQWYsSUFBMkJoRCxLQUFLLENBQUM0RCxTQUFqQyxHQUNJWCxhQUFhLENBQUNVLEdBQWQsQ0FDRTNELEtBQUssQ0FBQzRELFNBRFIsWUFFSzdELElBRkwsY0FFYTRDLFVBRmIsY0FFMkJFLFVBRjNCLDhCQUV5RDdDLEtBQUssQ0FBQzRELFNBRi9ELGtCQURKLEdBS0k7QUFyRGtCLFdBQTFCLENBVjhCLENBaUU5Qjs7QUFDQSxlQUFLLElBQUlDLEtBQVQsSUFBa0JYLGlCQUFsQixFQUFxQztBQUNuQyxnQkFBSUEsaUJBQWlCLENBQUNXLEtBQUQsQ0FBckIsRUFDRWQsZUFBZSxHQUFHQSxlQUFlLENBQUNlLE1BQWhCLENBQ2hCWixpQkFBaUIsQ0FBQ1csS0FBRCxDQURELENBQWxCO0FBR0g7O0FBQ0RqQixrQkFBUSxDQUFDRSxXQUFELENBQVIsR0FBd0JDLGVBQXhCO0FBQ0FGLG9CQUFVO0FBQ1g7O0FBQ0QsWUFBSWtCLGNBQWMsR0FBR3BFLEdBQUcsQ0FBQ3FFLE1BQUosR0FBYUMsS0FBYixDQUFtQnJCLFFBQW5CLENBQXJCLENBaEZ3QixDQWtGeEI7O0FBQ0FtQixzQkFBYyxDQUNYRyxRQURILENBQ1k3RCxLQURaLEVBQ21CO0FBQUU4RCxvQkFBVSxFQUFFO0FBQWQsU0FEbkIsRUFFR0MsSUFGSCxDQUVRLE1BQU07QUFDVjVCLGdCQUFNLEdBQUcsRUFBVCxDQURVLENBQ0c7QUFDZCxTQUpILEVBS0c2QixLQUxILENBS1VDLEdBQUQsSUFBUztBQUNkOUIsZ0JBQU0sR0FBRyxFQUFULENBRGMsQ0FDRDs7QUFDYjhCLGFBQUcsQ0FBQ3ZFLElBQUosS0FBYXdFLFNBQWIsR0FDS0QsR0FBRyxDQUFDL0IsT0FBSixHQUFjLG9CQURuQixHQUVJLElBRko7QUFHQSxpQkFBTytCLEdBQUcsQ0FBQy9CLE9BQUosS0FBZ0Isb0JBQWhCLEdBQ0ZDLE1BQU0sQ0FBQzhCLEdBQUcsQ0FBQyxNQUFELENBQUosQ0FBTixHQUFzQkEsR0FBRyxDQUFDL0IsT0FEeEIsR0FFSCxJQUZKO0FBR0QsU0FiSDtBQWNBSSxrQkFBVTtBQUNYLE9BbEdELEVBSDJELENBdUczRDs7QUFDQSxVQUFJNkIsSUFBSSxDQUFDQyxTQUFMLENBQWVqQyxNQUFmLE1BQTJCLElBQS9CLEVBQXFDO0FBQ25DLGVBQU8sSUFBUDtBQUNELE9BRkQsTUFFTztBQUNMLGFBQUssSUFBSWtDLE9BQVQsSUFBb0JsQyxNQUFwQixFQUE0QjtBQUMxQixjQUFJbUMsVUFBVSxHQUFHbkMsTUFBTSxDQUFDa0MsT0FBRCxDQUF2QjtBQUNBLGNBQUlFLFlBQVksR0FBR0QsVUFBVSxDQUFDdkIsTUFBWCxDQUFrQnVCLFVBQVUsQ0FBQ0UsT0FBWCxDQUFtQixHQUFuQixJQUEwQixDQUE1QyxDQUFuQjtBQUNBLGNBQUlDLFNBQVMsR0FBR0gsVUFBVSxDQUFDdkIsTUFBWCxDQUFrQixDQUFsQixFQUFxQnVCLFVBQVUsQ0FBQ0UsT0FBWCxDQUFtQixHQUFuQixDQUFyQixDQUFoQjtBQUNBLGlCQUFPbkMsV0FBVyxDQUFDO0FBQ2pCM0MsZ0JBQUksWUFBSytFLFNBQUwsQ0FEYTtBQUVqQnZDLG1CQUFPLFlBQUtxQyxZQUFMO0FBRlUsV0FBRCxDQUFsQjtBQUlEO0FBQ0Y7QUFDRixLQXJITSxDQUFQO0FBc0hELEdBekhELEVBTjhELENBZ0k5RDs7QUFDQSxNQUFJSixJQUFJLENBQUNDLFNBQUwsQ0FBZXJDLFdBQWYsTUFBZ0MsSUFBcEMsRUFBMEM7QUFDeEMsU0FBSyxJQUFJdkIsTUFBVCxJQUFtQnVCLFdBQW5CLEVBQWdDO0FBQzlCRCxjQUFRLENBQUN0QixNQUFELENBQVIsR0FBbUJsQixHQUFHLENBQUNvRixLQUFKLEdBQVlDLGNBQVosRUFBbkI7QUFDRDtBQUNGOztBQUVELFNBQU9yRixHQUFHLENBQUNxRSxNQUFKLEdBQWFDLEtBQWIsQ0FBbUI5QixRQUFuQixDQUFQO0FBQ0QsQ0F4SU0sQzs7Ozs7Ozs7Ozs7QUNqRlBuRCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDZ0csdUJBQXFCLEVBQUMsTUFBSUE7QUFBM0IsQ0FBZDtBQUFpRSxJQUFJdEYsR0FBSjtBQUFRWCxNQUFNLENBQUNJLElBQVAsQ0FBWSxLQUFaLEVBQWtCO0FBQUMsTUFBSUMsQ0FBSixFQUFNO0FBQUNNLE9BQUcsR0FBQ04sQ0FBSjtBQUFNOztBQUFkLENBQWxCLEVBQWtDLENBQWxDOztBQU16RSxNQUFNNkYsV0FBVyxHQUFHLENBQUNyRixVQUFELEVBQWFXLE9BQWIsS0FBeUI7QUFDM0MsU0FBT0EsT0FBTyxDQUFDMkUsR0FBUixDQUFhdEUsTUFBRCxJQUFZO0FBQzdCLFFBQUloQixVQUFVLENBQUNpQixJQUFYLEtBQW9CRCxNQUFNLENBQUNDLElBQS9CLEVBQXFDO0FBQ25DLGFBQU9ELE1BQU0sQ0FBQ0MsSUFBZDtBQUNEO0FBQ0YsR0FKTSxDQUFQO0FBS0QsQ0FORDs7QUFRTyxNQUFNbUUscUJBQXFCLEdBQUcsQ0FBQ3BGLFVBQUQsRUFBYVcsT0FBYixLQUF5QjtBQUM1RCxTQUFPYixHQUFHLENBQUNxRSxNQUFKLEdBQWFDLEtBQWIsQ0FBbUI7QUFDeEI5QyxPQUFHLEVBQUV4QixHQUFHLENBQUN5QixNQUFKLEVBRG1CO0FBRXhCTixRQUFJLEVBQUVuQixHQUFHLENBQUN5QixNQUFKLEdBQ0hDLFFBREcsQ0FFRjZELFdBQVcsQ0FBQ3JGLFVBQUQsRUFBYVcsT0FBYixDQUZULEVBR0RpQixHQUFELCtCQUE2QkEsR0FBRyxDQUFDYixLQUFqQyxzQkFIRSxFQUtIWSxPQUxHLENBTUYsaUJBTkUsRUFPRixnRkFQRSxFQVNIRCxRQVRHLENBU00sVUFUTixFQVVIb0MsR0FWRyxDQVVDLEVBVkQsRUFVSywrQkFWTCxDQUZrQjtBQWF4QnlCLGVBQVcsRUFBRXpGLEdBQUcsQ0FBQ3lCLE1BQUosR0FDVkcsUUFEVSxDQUNELFVBREMsRUFFVm9DLEdBRlUsQ0FFTixHQUZNLEVBRUQsZ0NBRkMsQ0FiVztBQWdCeEIzQyxVQUFNLEVBQUVyQixHQUFHLENBQUNvRixLQUFKLEdBQVlNLEVBQVosQ0FDTjFGLEdBQUcsQ0FBQ3FFLE1BQUosR0FDR0MsS0FESCxDQUNTO0FBQ0xuRCxVQUFJLEVBQUVuQixHQUFHLENBQUN5QixNQUFKLEdBQ0hHLFFBREcsQ0FDTSxVQUROLEVBRUhvQyxHQUZHLENBRUMsRUFGRCxFQUVLLCtCQUZMLENBREQ7QUFJTFgsVUFBSSxFQUFFckQsR0FBRyxDQUFDMkMsS0FBSixHQUNIaUIsS0FERyxDQUVGLENBQUMsUUFBRCxFQUFXLFFBQVgsRUFBcUIsTUFBckIsRUFBNkIsS0FBN0IsRUFBb0MsV0FBcEMsQ0FGRSxFQUdGLHdCQUhFLEVBS0hoQyxRQUxHLENBS00sVUFMTixDQUpEO0FBVUwrQixtQkFBYSxFQUFFM0QsR0FBRyxDQUFDb0YsS0FBSixHQUNaTyxNQURZLEdBRVozQixHQUZZLENBRVIsR0FGUSxFQUVILDhCQUZHLENBVlY7QUFhTEQsU0FBRyxFQUFFL0QsR0FBRyxDQUFDNEYsTUFBSixHQUFhQyxRQUFiLEdBQXdCQyxXQUF4QixFQWJBO0FBY0w5QixTQUFHLEVBQUVoRSxHQUFHLENBQUM0RixNQUFKLEdBQ0ZDLFFBREUsR0FFRkUsSUFGRSxDQUVHLENBQUMsS0FBRCxDQUZILEVBRVksQ0FBQ2hDLEdBQUQsRUFBTTdDLE1BQU4sS0FBaUI7QUFDOUIsZUFBT0EsTUFBTSxDQUFDNkMsR0FBUCxDQUFXQSxHQUFYLENBQVA7QUFDRCxPQUpFLENBZEE7QUFtQkxuQyxjQUFRLEVBQUU1QixHQUFHLENBQUNnQyxPQUFKLEVBbkJMO0FBb0JMOEIsY0FBUSxFQUFFOUQsR0FBRyxDQUFDZ0MsT0FBSixFQXBCTDtBQXFCTGlDLGVBQVMsRUFBRWpFLEdBQUcsQ0FBQzRGLE1BQUosR0FBYTVCLEdBQWIsQ0FDVCxLQURTLEVBRVQsbUNBRlM7QUFyQk4sS0FEVCxFQTJCRzhCLFdBM0JILEVBRE0sQ0FoQmdCO0FBOEN4Qi9ELGNBQVUsRUFBRS9CLEdBQUcsQ0FBQ2dDLE9BQUosR0FBY0osUUFBZCxFQTlDWTtBQStDeEJLLGNBQVUsRUFBRWpDLEdBQUcsQ0FBQ2tDLElBQUosR0FBV04sUUFBWCxFQS9DWTtBQWdEeEJPLGNBQVUsRUFBRW5DLEdBQUcsQ0FBQ3lCLE1BQUosR0FBYUcsUUFBYixFQWhEWTtBQWlEeEJRLGFBQVMsRUFBRXBDLEdBQUcsQ0FBQ2tDLElBQUosR0FBV04sUUFBWCxFQWpEYTtBQWtEeEJTLGFBQVMsRUFBRXJDLEdBQUcsQ0FBQ3lCLE1BQUosR0FBYUcsUUFBYjtBQWxEYSxHQUFuQixDQUFQO0FBb0RELENBckRNLEM7Ozs7Ozs7Ozs7O0FDZFB2QyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDMEcsZUFBYSxFQUFDLE1BQUlBO0FBQW5CLENBQWQ7QUFBaUQsSUFBSUMsTUFBSjtBQUFXNUcsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDd0csUUFBTSxDQUFDdkcsQ0FBRCxFQUFHO0FBQUN1RyxVQUFNLEdBQUN2RyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl3RyxNQUFKO0FBQVc3RyxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUN5RyxRQUFNLENBQUN4RyxDQUFELEVBQUc7QUFBQ3dHLFVBQU0sR0FBQ3hHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLFVBQUo7QUFBZTlHLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUMwRyxZQUFVLENBQUN6RyxDQUFELEVBQUc7QUFBQ3lHLGNBQVUsR0FBQ3pHLENBQVg7QUFBYTs7QUFBNUIsQ0FBaEMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSTBHLE1BQUo7QUFBVy9HLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQzRHLFNBQU8sQ0FBQzNHLENBQUQsRUFBRztBQUFDMEcsVUFBTSxHQUFDMUcsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQUErQyxJQUFJNEcsTUFBSjtBQUFXakgsTUFBTSxDQUFDSSxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDNEcsU0FBTyxDQUFDM0csQ0FBRCxFQUFHO0FBQUM0RyxVQUFNLEdBQUM1RyxDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDOztBQU0vVCxNQUFNc0csYUFBYSxHQUFHLE1BQU07QUFDakMsUUFBTU8sSUFBSSxHQUFHLFFBQWI7QUFDQSxRQUFNQyxJQUFJLEdBQUcsT0FBYjtBQUNBLFFBQU1DLFVBQVUsR0FBRyxlQUFuQjtBQUNBLFFBQU1DLFlBQVksR0FBRyxpQkFBckI7QUFDQSxRQUFNQyxjQUFjLEdBQUdWLE1BQU0sQ0FBQ1csUUFBUCxDQUFnQkQsY0FBdkM7QUFFQSxRQUFNakQsR0FBRyxHQUFHdUMsTUFBTSxDQUFDWSxXQUFQLEVBQVo7QUFDQSxRQUFNQyxNQUFNLEdBQUdwRCxHQUFHLENBQUNxRCxPQUFKLENBQVksZUFBWixFQUE2QixFQUE3QixFQUFpQ0EsT0FBakMsQ0FBeUMsS0FBekMsRUFBZ0QsRUFBaEQsQ0FBZjtBQUNBLFFBQU1DLENBQUMsR0FBR3RELEdBQUcsQ0FBQ3VELEtBQUosQ0FBVSxxQkFBVixJQUFtQyxHQUFuQyxHQUF5QyxFQUFuRDtBQUNBLFFBQU1DLFNBQVMsR0FBR0YsQ0FBQyxDQUFDckcsTUFBRixHQUFXLENBQTdCO0FBQ0EsUUFBTXdHLFVBQVUsR0FBRyxDQUFDWixJQUFELGdCQUFjUyxDQUFkLGdCQUFxQkYsTUFBckIsZUFBb0NFLENBQXBDLGdCQUEyQ0YsTUFBM0MsRUFBbkI7QUFFQSxRQUFNTSxPQUFPLEdBQUc7QUFDZEMseUJBQXFCLEVBQUU7QUFDckJDLDBCQUFvQixFQUFFLElBREQ7QUFFckJDLGdCQUFVLEVBQUU7QUFDVkMsa0JBQVUsRUFBRSxDQUFDakIsSUFBRCxFQUFPRyxZQUFQLENBREY7QUFFVmUsaUJBQVMsRUFBRSxDQUFDZixZQUFELENBRkQ7QUFHVmdCLGdCQUFRLEVBQUUsQ0FBQ25CLElBQUQsRUFBT0csWUFBUCxDQUhBO0FBSVZTLGtCQUFVLEVBQUVBLFVBQVUsQ0FBQ2hELE1BQVgsQ0FBa0J3QyxjQUFsQixDQUpGO0FBS1ZnQixlQUFPLEVBQUUsQ0FBQ3BCLElBQUQsRUFBT0MsSUFBUCxFQUFhRSxZQUFiLENBTEM7QUFNVmtCLGtCQUFVLEVBQUUsQ0FBQ3JCLElBQUQsQ0FORjtBQU9Wc0Isc0JBQWMsRUFBRSxDQUFDdEIsSUFBRCxDQVBOO0FBUVZ1QixnQkFBUSxFQUFFLENBQUMsR0FBRCxDQVJBO0FBU1ZDLGNBQU0sRUFBRSxDQUFDLEdBQUQsQ0FURTtBQVVWQyxtQkFBVyxFQUFFLENBQUN6QixJQUFELEVBQU9HLFlBQVAsQ0FWSDtBQVdWdUIsZ0JBQVEsRUFBRSxDQUFDMUIsSUFBRCxFQUFPRyxZQUFQLENBWEE7QUFZVndCLGlCQUFTLEVBQUUsQ0FBQzNCLElBQUQsRUFBT0csWUFBUCxDQVpEO0FBYVZ5QixlQUFPLEVBQUUsQ0FDUCxhQURPLEVBRVAsY0FGTyxFQUdQLG1CQUhPLEVBSVAsZUFKTyxFQUtQLGNBTE8sQ0FiQztBQW9CVkMsZ0JBQVEsRUFBRSxDQUFDN0IsSUFBRCxFQUFPRyxZQUFQLENBcEJBO0FBcUJWMkIsaUJBQVMsRUFBRSxDQUFDOUIsSUFBRCxFQUFPLE9BQVA7QUFyQkQ7QUFGUyxLQURUO0FBMkJkK0IsMkJBQXVCLEVBQUU7QUFDdkJDLFlBQU0sRUFBRSxRQURlO0FBRXZCQyx1QkFBaUIsRUFBRSxJQUZJO0FBR3ZCQyxhQUFPLEVBQUU7QUFIYyxLQTNCWDtBQWdDZEMsa0JBQWMsRUFBRTtBQUNkQyxZQUFNLEVBQUU7QUFETSxLQWhDRjtBQW1DZEMsWUFBUSxFQUFFO0FBQ1JDLGFBQU8sRUFBRSxJQUREO0FBRVJOLFlBQU0sRUFBRTtBQUZBLEtBbkNJO0FBdUNkTyxjQUFVLEVBQUU7QUFDVkMsWUFBTSxFQUFFO0FBREUsS0F2Q0U7QUEwQ2RDLHNCQUFrQixFQUFFO0FBQ2xCQyxXQUFLLEVBQUU7QUFEVyxLQTFDTjtBQTZDZEMsZ0NBQTRCLEVBQUU7QUFDNUJDLHVCQUFpQixFQUFFO0FBRFM7QUE3Q2hCLEdBQWhCOztBQWtEQSxNQUFJLENBQUNqQyxTQUFELElBQWNqQixNQUFNLENBQUNtRCxhQUF6QixFQUF3QztBQUN0QyxXQUFPaEMsT0FBTyxDQUFDQyxxQkFBUixDQUE4QkUsVUFBOUIsQ0FBeUNELG9CQUFoRDtBQUNBRixXQUFPLENBQUNDLHFCQUFSLENBQThCRSxVQUE5QixDQUF5Q0UsU0FBekMsR0FBcUQsQ0FDbkRsQixJQURtRCxFQUVuREUsVUFGbUQsRUFHbkRDLFlBSG1ELENBQXJEO0FBS0Q7O0FBRUQsU0FBT1UsT0FBUDtBQUNELENBekVNLEM7Ozs7Ozs7Ozs7O0FDTlAsSUFBSW5CLE1BQUo7QUFBVzVHLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3dHLFFBQU0sQ0FBQ3ZHLENBQUQsRUFBRztBQUFDdUcsVUFBTSxHQUFDdkcsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJRSxtQkFBSjtBQUF3QlAsTUFBTSxDQUFDSSxJQUFQLENBQVkseUJBQVosRUFBc0M7QUFBQ0cscUJBQW1CLENBQUNGLENBQUQsRUFBRztBQUFDRSx1QkFBbUIsR0FBQ0YsQ0FBcEI7QUFBc0I7O0FBQTlDLENBQXRDLEVBQXNGLENBQXRGO0FBQXlGLElBQUlHLGdCQUFKO0FBQXFCUixNQUFNLENBQUNJLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDSSxrQkFBZ0IsQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNHLG9CQUFnQixHQUFDSCxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBbkMsRUFBNkUsQ0FBN0U7QUFJdE13RyxNQUFNLENBQUNtRCxlQUFQLENBQXVCQyxHQUF2QixDQUEyQixpQkFBM0IsRUFBOEMsQ0FBT0MsR0FBUCxFQUFZQyxHQUFaLEVBQWlCQyxJQUFqQiw4QkFBMEI7QUFDdEUsV0FBZUMsT0FBZjtBQUFBLG9DQUF5QjtBQUN2QkYsU0FBRyxDQUFDRyxTQUFKLENBQWMsY0FBZCxFQUE4QixrQkFBOUI7QUFDQSxZQUFNeEosSUFBSSxpQkFBU1AsbUJBQW1CLENBQUMwQyxJQUFwQixDQUF5QixFQUF6QixDQUFULENBQVY7O0FBRUEsVUFBSWlILEdBQUcsQ0FBQ0ssS0FBSixDQUFVQyxLQUFkLEVBQXFCO0FBQ25CLGNBQU1DLE9BQU8sR0FBR0MsUUFBUSxDQUFDUixHQUFHLENBQUNLLEtBQUosQ0FBVUMsS0FBWCxDQUF4QjtBQUNBLGNBQU1HLElBQUksR0FBR0QsUUFBUSxDQUFDUixHQUFHLENBQUNLLEtBQUosQ0FBVUksSUFBWCxDQUFyQjtBQUNBLGNBQU1DLE9BQU8sR0FBR0gsT0FBTyxHQUFHRSxJQUExQjs7QUFDQSxZQUFJO0FBQ0YsZ0JBQU1FLE1BQU0saUJBQVN0SyxtQkFBbUIsQ0FBQzBDLElBQXBCLENBQ25CLEVBRG1CLEVBRW5CO0FBQ0V1SCxpQkFBSyxFQUFFQyxPQURUO0FBRUVLLGdCQUFJLEVBQUVGO0FBRlIsV0FGbUIsRUFNbkIxSCxLQU5tQixFQUFULENBQVo7O0FBT0EsY0FBSTJILE1BQU0sQ0FBQ3ZKLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckI2SSxlQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGVBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWVvRixNQUFmLENBQVI7QUFDRCxXQUhELE1BR087QUFDTEksaUJBQUssR0FBRztBQUNOQSxtQkFBSyxFQUNIO0FBRkksYUFBUjtBQUlBZCxlQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGVBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWV3RixLQUFmLENBQVI7QUFDRDtBQUNGLFNBbkJELENBbUJFLE9BQU8zRixHQUFQLEVBQVk7QUFDWjJGLGVBQUssR0FBRztBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBUjtBQUNBZCxhQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGFBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWV3RixLQUFmLENBQVI7QUFDRDtBQUNGLE9BNUJELE1BNEJPLElBQUlmLEdBQUcsQ0FBQ0ssS0FBSixDQUFVakksT0FBVixJQUFxQjRILEdBQUcsQ0FBQ0ssS0FBSixDQUFVVyxFQUEvQixJQUFxQ2hCLEdBQUcsQ0FBQ0ssS0FBSixDQUFVWSxPQUFuRCxFQUE0RDtBQUNqRSxZQUFJO0FBQ0YsZ0JBQU03SSxPQUFPLEdBQUc0SCxHQUFHLENBQUNLLEtBQUosQ0FBVWpJLE9BQVYsSUFBcUI0SCxHQUFHLENBQUNLLEtBQUosQ0FBVVcsRUFBL0IsSUFBcUNoQixHQUFHLENBQUNLLEtBQUosQ0FBVVksT0FBL0Q7QUFDQSxnQkFBTU4sTUFBTSxpQkFBU3RLLG1CQUFtQixDQUFDMEMsSUFBcEIsQ0FBeUI7QUFDNUNYLG1CQUFPLEVBQUU7QUFBRThJLG9CQUFNLEVBQUU5STtBQUFWO0FBRG1DLFdBQXpCLEVBRWxCWSxLQUZrQixFQUFULENBQVo7O0FBR0EsY0FBSTJILE1BQU0sQ0FBQ3ZKLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckI2SSxlQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGVBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWVvRixNQUFmLENBQVI7QUFDRCxXQUhELE1BR087QUFDTEksaUJBQUssR0FBRztBQUNOQSxtQkFBSyxFQUNIO0FBRkksYUFBUjtBQUlBZCxlQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGVBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWV3RixLQUFmLENBQVI7QUFDRDtBQUNGLFNBaEJELENBZ0JFLE9BQU8zRixHQUFQLEVBQVk7QUFDWjJGLGVBQUssR0FBRztBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBUjtBQUNBZCxhQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGFBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWV3RixLQUFmLENBQVI7QUFDRDtBQUNGLE9BdEJNLE1Bc0JBLElBQUlmLEdBQUcsQ0FBQ0ssS0FBSixDQUFVekksSUFBZCxFQUFvQjtBQUN6QixZQUFJK0ksTUFBTSxHQUFHLElBQWI7O0FBQ0EsWUFBSTtBQUNGLGdCQUFNUSxNQUFNLEdBQUduQixHQUFHLENBQUNLLEtBQUosQ0FBVXpJLElBQXpCO0FBQ0EsZ0JBQU0rSSxNQUFNLEdBQUd0SyxtQkFBbUIsQ0FBQzBDLElBQXBCLENBQXlCO0FBQ3RDLDBCQUFjO0FBQUVtSSxvQkFBTSxZQUFLQyxNQUFMLENBQVI7QUFBdUJDLHNCQUFRLEVBQUU7QUFBakM7QUFEd0IsV0FBekIsRUFFWnBJLEtBRlksRUFBZjs7QUFHQSxjQUFJMkgsTUFBTSxDQUFDdkosTUFBUCxHQUFnQixDQUFoQixJQUFxQnVKLE1BQU0sQ0FBQyxDQUFELENBQU4sS0FBY3RGLFNBQXZDLEVBQWtEO0FBQ2hEZ0csbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBdUJYLE1BQU0sQ0FBQyxDQUFELENBQTdCO0FBQ0FWLGVBQUcsQ0FBQ1ksU0FBSixDQUFjLEdBQWQ7QUFDQVosZUFBRyxDQUFDYSxHQUFKLENBQVF4RixJQUFJLENBQUNDLFNBQUwsQ0FBZW9GLE1BQWYsQ0FBUjtBQUNELFdBSkQsQ0FLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFoQkEsZUFpQks7QUFDSEksaUJBQUssR0FBRztBQUNOQSxtQkFBSyxFQUFFO0FBREQsYUFBUjtBQUdBZCxlQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGVBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWV3RixLQUFmLENBQVI7QUFDRDtBQUNGLFNBN0JELENBNkJFLE9BQU8zRixHQUFQLEVBQVk7QUFDWjJGLGVBQUssR0FBRztBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBUjtBQUNBZCxhQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLGFBQUcsQ0FBQ2EsR0FBSixDQUFReEYsSUFBSSxDQUFDQyxTQUFMLENBQWV3RixLQUFmLENBQVI7QUFDRDtBQUNGLE9BcENNLE1Bb0NBLElBQUlmLEdBQUcsQ0FBQ0ssS0FBSixDQUFVdkcsSUFBZCxFQUFvQjtBQUN6QixZQUFJNkcsTUFBTSxHQUFHLElBQWI7O0FBQ0EsWUFBSTtBQUNGLGdCQUFNUSxNQUFNLEdBQUduQixHQUFHLENBQUNLLEtBQUosQ0FBVXZHLElBQXpCO0FBQ0FsRCxjQUFJLENBQUNvQyxLQUFMLEdBQWFuQixPQUFiLENBQXNCYixHQUFELElBQVM7QUFDNUIsZ0JBQUl1SyxJQUFJLEdBQUd2SyxHQUFHLENBQUM4QyxJQUFKLENBQVNmLElBQVQsQ0FBZWUsSUFBRCxJQUFVO0FBQ2pDLHFCQUFPQSxJQUFJLENBQUNBLElBQUwsSUFBYUEsSUFBSSxDQUFDQSxJQUFMLEtBQWNxSCxNQUEzQixHQUFvQyxJQUFwQyxHQUEyQyxLQUFsRDtBQUNELGFBRlUsQ0FBWDs7QUFHQSxnQkFBSUksSUFBSixFQUFVO0FBQ1JaLG9CQUFNLEdBQUczSixHQUFUO0FBQ0Q7QUFDRixXQVBEOztBQVFBLGNBQUkySixNQUFKLEVBQVk7QUFDVlYsZUFBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixlQUFHLENBQUNhLEdBQUosQ0FBUXhGLElBQUksQ0FBQ0MsU0FBTCxDQUFlb0YsTUFBZixDQUFSO0FBQ0QsV0FIRCxNQUdPO0FBQ0xJLGlCQUFLLEdBQUc7QUFDTkEsbUJBQUssRUFBRTtBQURELGFBQVI7QUFHQWQsZUFBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixlQUFHLENBQUNhLEdBQUosQ0FBUXhGLElBQUksQ0FBQ0MsU0FBTCxDQUFld0YsS0FBZixDQUFSO0FBQ0Q7QUFDRixTQXBCRCxDQW9CRSxPQUFPM0YsR0FBUCxFQUFZO0FBQ1oyRixlQUFLLEdBQUc7QUFBRUEsaUJBQUssRUFBRTtBQUFULFdBQVI7QUFDQWQsYUFBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixhQUFHLENBQUNhLEdBQUosQ0FBUXhGLElBQUksQ0FBQ0MsU0FBTCxDQUFld0YsS0FBZixDQUFSO0FBQ0Q7QUFDRixPQTNCTSxNQTJCQSxJQUFJZixHQUFHLENBQUNLLEtBQUosQ0FBVW1CLEtBQWQsRUFBcUI7QUFDMUIsWUFBSWIsTUFBTSxHQUFHLElBQWI7O0FBQ0EsWUFBSTtBQUNGLGdCQUFNUSxNQUFNLEdBQUduQixHQUFHLENBQUNLLEtBQUosQ0FBVW1CLEtBQXpCO0FBQ0E1SyxjQUFJLENBQUNvQyxLQUFMLEdBQWFuQixPQUFiLENBQXNCYixHQUFELElBQVM7QUFDNUIsZ0JBQUl1SyxJQUFJLEdBQUd2SyxHQUFHLENBQUN3SyxLQUFKLENBQVV6SSxJQUFWLENBQWdCeUksS0FBRCxJQUFXO0FBQ25DLHFCQUFPQSxLQUFLLENBQUNBLEtBQU4sSUFBZUEsS0FBSyxDQUFDQSxLQUFOLEtBQWdCTCxNQUEvQixHQUF3QyxJQUF4QyxHQUErQyxLQUF0RDtBQUNELGFBRlUsQ0FBWDs7QUFHQSxnQkFBSUksSUFBSixFQUFVO0FBQ1JaLG9CQUFNLEdBQUczSixHQUFUO0FBQ0Q7QUFDRixXQVBEOztBQVFBLGNBQUkySixNQUFKLEVBQVk7QUFDVlYsZUFBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixlQUFHLENBQUNhLEdBQUosQ0FBUXhGLElBQUksQ0FBQ0MsU0FBTCxDQUFlb0YsTUFBZixDQUFSO0FBQ0QsV0FIRCxNQUdPO0FBQ0xJLGlCQUFLLEdBQUc7QUFDTkEsbUJBQUssRUFBRTtBQURELGFBQVI7QUFHQWQsZUFBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixlQUFHLENBQUNhLEdBQUosQ0FBUXhGLElBQUksQ0FBQ0MsU0FBTCxDQUFld0YsS0FBZixDQUFSO0FBQ0Q7QUFDRixTQXBCRCxDQW9CRSxPQUFPM0YsR0FBUCxFQUFZO0FBQ1oyRixlQUFLLEdBQUc7QUFBRUEsaUJBQUssRUFBRTtBQUFULFdBQVI7QUFDQWQsYUFBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixhQUFHLENBQUNhLEdBQUosQ0FBUXhGLElBQUksQ0FBQ0MsU0FBTCxDQUFld0YsS0FBZixDQUFSO0FBQ0Q7QUFDRixPQTNCTSxNQTJCQTtBQUNMLFlBQUk7QUFDRmQsYUFBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixhQUFHLENBQUNhLEdBQUosQ0FBUXhGLElBQUksQ0FBQ0MsU0FBTCxDQUFlM0UsSUFBSSxDQUFDb0MsS0FBTCxFQUFmLENBQVI7QUFDRCxTQUhELENBR0UsT0FBT29DLEdBQVAsRUFBWTtBQUNaMkYsZUFBSyxHQUFHO0FBQUVBLGlCQUFLLEVBQUU7QUFBVCxXQUFSO0FBQ0FkLGFBQUcsQ0FBQ1ksU0FBSixDQUFjLEdBQWQ7QUFDQVosYUFBRyxDQUFDYSxHQUFKLENBQVF4RixJQUFJLENBQUNDLFNBQUwsQ0FBZXdGLEtBQWYsQ0FBUjtBQUNEO0FBQ0Y7QUFDRixLQTFKRDtBQUFBOztBQTJKQVosU0FBTztBQUNSLENBN0o2QyxDQUE5QztBQStKQXhELE1BQU0sQ0FBQ21ELGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCLGNBQTNCLEVBQTJDLENBQUNDLEdBQUQsRUFBTUMsR0FBTixFQUFXQyxJQUFYLEtBQW9CO0FBQzdELFdBQVN1QixTQUFULEdBQXFCO0FBQ25CeEIsT0FBRyxDQUFDRyxTQUFKLENBQWMsY0FBZCxFQUE4QixrQkFBOUI7O0FBQ0EsUUFBSTtBQUNGc0IsZ0JBQVUsR0FBRzFCLEdBQUcsQ0FBQ0ssS0FBSixDQUFVekksSUFBdkI7O0FBQ0EsVUFBSThKLFVBQVUsSUFBSUEsVUFBVSxLQUFLLEVBQWpDLEVBQXFDO0FBQ25DekIsV0FBRyxDQUFDWSxTQUFKLENBQWMsR0FBZDtBQUNBWixXQUFHLENBQUNhLEdBQUosQ0FDRXhGLElBQUksQ0FBQ0MsU0FBTCxDQUNFakYsZ0JBQWdCLENBQUN5QyxJQUFqQixDQUFzQjtBQUFFbkIsY0FBSSxZQUFLb0ksR0FBRyxDQUFDSyxLQUFKLENBQVV6SSxJQUFmO0FBQU4sU0FBdEIsRUFBcURvQixLQUFyRCxFQURGLENBREY7QUFLRCxPQVBELE1BT087QUFDTGlILFdBQUcsQ0FBQ1ksU0FBSixDQUFjLEdBQWQ7QUFDQVosV0FBRyxDQUFDYSxHQUFKLENBQVF4RixJQUFJLENBQUNDLFNBQUwsQ0FBZWpGLGdCQUFnQixDQUFDeUMsSUFBakIsR0FBd0JDLEtBQXhCLEVBQWYsQ0FBUjtBQUNEO0FBQ0YsS0FiRCxDQWFFLE9BQU9vQyxHQUFQLEVBQVk7QUFDWjJGLFdBQUssR0FBRztBQUFFQSxhQUFLLEVBQUU7QUFBVCxPQUFSO0FBQ0FkLFNBQUcsQ0FBQ1ksU0FBSixDQUFjLEdBQWQ7QUFDQVosU0FBRyxDQUFDYSxHQUFKLENBQVF4RixJQUFJLENBQUNDLFNBQUwsQ0FBZXdGLEtBQWYsQ0FBUjtBQUNEO0FBQ0Y7O0FBQ0RVLFdBQVM7QUFDVixDQXZCRDtBQXlCQTlFLE1BQU0sQ0FBQ21ELGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCLE9BQTNCLEVBQW9DLENBQUNDLEdBQUQsRUFBTUMsR0FBTixFQUFXQyxJQUFYLEtBQW9CO0FBQ3RERCxLQUFHLENBQUNHLFNBQUosQ0FBYyxjQUFkLEVBQThCLGtCQUE5QjtBQUNBSCxLQUFHLENBQUNZLFNBQUosQ0FBYyxHQUFkO0FBQ0FaLEtBQUcsQ0FBQ2EsR0FBSixDQUNFeEYsSUFBSSxDQUFDQyxTQUFMLENBQ0UsZ0hBREYsQ0FERjtBQUtELENBUkQsRTs7Ozs7Ozs7Ozs7QUM1TEEsSUFBSTlFLEdBQUo7QUFBUVgsTUFBTSxDQUFDSSxJQUFQLENBQVksS0FBWixFQUFrQjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDTSxPQUFHLEdBQUNOLENBQUo7QUFBTTs7QUFBZCxDQUFsQixFQUFrQyxDQUFsQztBQUFxQyxJQUFJNEcsTUFBSjtBQUFXakgsTUFBTSxDQUFDSSxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDNEcsU0FBTyxDQUFDM0csQ0FBRCxFQUFHO0FBQUM0RyxVQUFNLEdBQUM1RyxDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUl1RyxNQUFKO0FBQVc1RyxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUN3RyxRQUFNLENBQUN2RyxDQUFELEVBQUc7QUFBQ3VHLFVBQU0sR0FBQ3ZHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXdMLEtBQUo7QUFBVTdMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUN5TCxPQUFLLENBQUN4TCxDQUFELEVBQUc7QUFBQ3dMLFNBQUssR0FBQ3hMLENBQU47QUFBUTs7QUFBbEIsQ0FBcEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSXlMLFFBQUo7QUFBYTlMLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUMwTCxVQUFRLENBQUN6TCxDQUFELEVBQUc7QUFBQ3lMLFlBQVEsR0FBQ3pMLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSUcsZ0JBQUo7QUFBcUJSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNJLGtCQUFnQixDQUFDSCxDQUFELEVBQUc7QUFBQ0csb0JBQWdCLEdBQUNILENBQWpCO0FBQW1COztBQUF4QyxDQUFuQyxFQUE2RSxDQUE3RTtBQUFnRixJQUFJRSxtQkFBSjtBQUF3QlAsTUFBTSxDQUFDSSxJQUFQLENBQVkseUJBQVosRUFBc0M7QUFBQ0cscUJBQW1CLENBQUNGLENBQUQsRUFBRztBQUFDRSx1QkFBbUIsR0FBQ0YsQ0FBcEI7QUFBc0I7O0FBQTlDLENBQXRDLEVBQXNGLENBQXRGO0FBQXlGLElBQUlJLGVBQUo7QUFBb0JULE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNLLGlCQUFlLENBQUNKLENBQUQsRUFBRztBQUFDSSxtQkFBZSxHQUFDSixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBakMsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSUgsZ0JBQUo7QUFBcUJGLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNGLGtCQUFnQixDQUFDRyxDQUFELEVBQUc7QUFBQ0gsb0JBQWdCLEdBQUNHLENBQWpCO0FBQW1COztBQUF4QyxDQUFsQyxFQUE0RSxDQUE1RTtBQUErRSxJQUFJc0csYUFBSjtBQUFrQjNHLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ3VHLGVBQWEsQ0FBQ3RHLENBQUQsRUFBRztBQUFDc0csaUJBQWEsR0FBQ3RHLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXZCLEVBQTJELENBQTNEO0FBQThELElBQUk0RixxQkFBSjtBQUEwQmpHLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUM2Rix1QkFBcUIsQ0FBQzVGLENBQUQsRUFBRztBQUFDNEYseUJBQXFCLEdBQUM1RixDQUF0QjtBQUF3Qjs7QUFBbEQsQ0FBM0MsRUFBK0YsRUFBL0Y7QUFBbUcsSUFBSUssd0JBQUo7QUFBNkJWLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGlDQUFaLEVBQThDO0FBQUNNLDBCQUF3QixDQUFDTCxDQUFELEVBQUc7QUFBQ0ssNEJBQXdCLEdBQUNMLENBQXpCO0FBQTJCOztBQUF4RCxDQUE5QyxFQUF3RyxFQUF4RztBQUE0R0wsTUFBTSxDQUFDSSxJQUFQLENBQVksVUFBWjs7QUFpQnppQyxNQUFNMkwsRUFBRSxHQUFHQyxHQUFHLENBQUNDLE9BQUosQ0FBWSxJQUFaLENBQVg7O0FBRUEsTUFBTUMsWUFBWSxHQUFHLENBQUNDLFFBQUQsRUFBV0MsUUFBWCxLQUF3QjtBQUMzQyxRQUFNQyxRQUFRLEdBQUdGLFFBQVEsR0FBR0EsUUFBUSxLQUFLQyxRQUFoQixHQUEyQixJQUFwRDtBQUNBLFFBQU12SyxNQUFNLEdBQUdsQixHQUFHLENBQUN5QixNQUFKLEdBQWFrSyxLQUFiLEVBQWY7QUFDQSxTQUFPekssTUFBTSxDQUFDMEssV0FBUCxDQUFtQkgsUUFBbkIsS0FBZ0NDLFFBQWhDLElBQTRDRCxRQUFRLENBQUM5SyxNQUFULEdBQWtCLEdBQXJFO0FBQ0QsQ0FKRDs7QUFNQSxNQUFNa0wsZUFBZSxHQUFHLENBQUNDLFdBQUQsRUFBY0MsV0FBZCxLQUE4QjtBQUNwRCxRQUFNTCxRQUFRLEdBQUdJLFdBQVcsR0FBR0EsV0FBVyxLQUFLQyxXQUFuQixHQUFpQyxJQUE3RDtBQUNBLFFBQU1DLEtBQUssR0FBRyxvQkFBZDtBQUNBLFNBQU9BLEtBQUssQ0FBQ2xKLElBQU4sQ0FBV2lKLFdBQVgsS0FBMkJMLFFBQTNCLElBQXVDSyxXQUFXLENBQUNwTCxNQUFaLEdBQXFCLEVBQW5FO0FBQ0QsQ0FKRDs7QUFNQXNMLGVBQWUsR0FBRyxDQUFDQyxXQUFELEVBQWNDLFdBQWQsS0FBOEI7QUFDOUMsUUFBTVQsUUFBUSxHQUFHUSxXQUFXLEdBQUdBLFdBQVcsS0FBS0MsV0FBbkIsR0FBaUMsSUFBN0Q7QUFDQSxRQUFNSCxLQUFLLEdBQ1QsdUVBREY7QUFFQSxTQUFPQSxLQUFLLENBQUNsSixJQUFOLENBQVdxSixXQUFYLEtBQTJCVCxRQUEzQixJQUF1Q1MsV0FBVyxDQUFDeEwsTUFBWixHQUFxQixHQUFuRTtBQUNELENBTEQ7O0FBTUFzRixNQUFNLENBQUNtRyxPQUFQLENBQWUsTUFBTTtBQUVuQnhCLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLGlEQUFaLEVBRm1CLENBR25COztBQUNBM0UsUUFBTSxDQUFDbUQsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJoRCxNQUFNLENBQUNOLGFBQWEsRUFBZCxDQUFqQyxFQUptQixDQU1uQjs7QUFDQWtGLE9BQUssQ0FBQ21CLFVBQU4sQ0FBaUIsT0FBakIsRUFBMEI7QUFBRUMsZ0JBQVksRUFBRTtBQUFoQixHQUExQjtBQUNBcEIsT0FBSyxDQUFDbUIsVUFBTixDQUFpQixXQUFqQixFQUE4QjtBQUFFQyxnQkFBWSxFQUFFO0FBQWhCLEdBQTlCO0FBQ0FwQixPQUFLLENBQUNtQixVQUFOLENBQWlCLFNBQWpCLEVBQTRCO0FBQUVDLGdCQUFZLEVBQUU7QUFBaEIsR0FBNUIsRUFUbUIsQ0FXbkI7O0FBQ0FuQixVQUFRLENBQUNvQixNQUFULENBQWdCO0FBQ2RDLHlCQUFxQixFQUFFO0FBRFQsR0FBaEI7O0FBR0FyQixVQUFRLENBQUNzQixJQUFULENBQWNDLGFBQWQsR0FBK0JDLEtBQUQsSUFBVztBQUN2QyxXQUFPMUcsTUFBTSxDQUFDWSxXQUFQLHdCQUFtQzhGLEtBQW5DLEVBQVA7QUFDRCxHQUZEOztBQUdBeEIsVUFBUSxDQUFDc0IsSUFBVCxDQUFjRyxXQUFkLEdBQTZCRCxLQUFELElBQVc7QUFDckMsV0FBTzFHLE1BQU0sQ0FBQ1ksV0FBUCx5QkFBb0M4RixLQUFwQyxFQUFQO0FBQ0QsR0FGRCxDQWxCbUIsQ0FzQm5COzs7QUFDQTFHLFFBQU0sQ0FBQzRHLE9BQVAsQ0FBZSxPQUFmLEVBQXdCLE1BQU07QUFDNUIsUUFBSTVHLE1BQU0sQ0FBQzZHLElBQVAsRUFBSixFQUFtQjtBQUNqQixVQUFJNUIsS0FBSyxDQUFDNkIsWUFBTixDQUFtQjlHLE1BQU0sQ0FBQytHLE1BQVAsRUFBbkIsRUFBb0MsT0FBcEMsQ0FBSixFQUFrRDtBQUNoRCxlQUFPLENBQ0wvRyxNQUFNLENBQUNnSCxLQUFQLENBQWEzSyxJQUFiLEVBREssRUFFTDJELE1BQU0sQ0FBQ2lILEtBQVAsQ0FBYTVLLElBQWIsRUFGSyxFQUdMMkQsTUFBTSxDQUFDa0gsY0FBUCxDQUFzQjdLLElBQXRCLEVBSEssQ0FBUDtBQUtELE9BTkQsTUFNTztBQUNMLGVBQU8sQ0FDTDJELE1BQU0sQ0FBQ2dILEtBQVAsQ0FBYTNLLElBQWIsQ0FBa0I7QUFBRWQsYUFBRyxFQUFFeUUsTUFBTSxDQUFDNkcsSUFBUCxHQUFjdEw7QUFBckIsU0FBbEIsQ0FESyxFQUVMeUUsTUFBTSxDQUFDaUgsS0FBUCxDQUFhNUssSUFBYixDQUFrQjtBQUFFZCxhQUFHLEVBQUV5RSxNQUFNLENBQUM2RyxJQUFQLEdBQWN0TDtBQUFyQixTQUFsQixDQUZLLEVBR0x5RSxNQUFNLENBQUNrSCxjQUFQLENBQXNCN0ssSUFBdEIsQ0FBMkI7QUFBRWQsYUFBRyxFQUFFeUUsTUFBTSxDQUFDNkcsSUFBUCxHQUFjdEw7QUFBckIsU0FBM0IsQ0FISyxDQUFQO0FBS0Q7QUFDRixLQWRELE1BY087QUFDTCxhQUFPLEVBQVA7QUFDRDtBQUNGLEdBbEJELEVBdkJtQixDQTJDbkI7O0FBQ0F5RSxRQUFNLENBQUNtSCxPQUFQLENBQWU7QUFDYkMsY0FBVSxFQUFHQyxRQUFELElBQWM7QUFDeEIsVUFBSW5DLFFBQVEsQ0FBQ29DLGtCQUFULENBQTRCRCxRQUE1QixDQUFKLEVBQTJDO0FBQ3pDLGVBQU8sMEJBQVA7QUFDRDtBQUNGLEtBTFk7QUFPYkUsZUFBVyxFQUFHN0IsS0FBRCxJQUFXO0FBQ3RCLFVBQUlSLFFBQVEsQ0FBQ3NDLGVBQVQsQ0FBeUI5QixLQUF6QixDQUFKLEVBQXFDO0FBQ25DO0FBQ0QsT0FGRCxNQUVPO0FBQ0w7QUFDRDtBQUNGLEtBYlk7QUFlYitCLGlCQUFhLEVBQUUsQ0FBQ1osSUFBRCxFQUFPYSxJQUFQLEtBQWdCO0FBQzdCLFVBQUl6QyxLQUFLLENBQUM2QixZQUFOLENBQW1COUcsTUFBTSxDQUFDK0csTUFBUCxFQUFuQixFQUFvQyxPQUFwQyxDQUFKLEVBQWtEO0FBQ2hEOUIsYUFBSyxDQUFDMEMsZUFBTixDQUFzQnpDLFFBQVEsQ0FBQ29DLGtCQUFULENBQTRCVCxJQUFJLENBQUNRLFFBQWpDLENBQXRCLEVBQWtFSyxJQUFsRTs7QUFDQSxZQUFJQSxJQUFJLEtBQUssU0FBYixFQUF3QjtBQUN0QjFILGdCQUFNLENBQUNnSCxLQUFQLENBQWFZLE1BQWIsQ0FDRWYsSUFBSSxDQUFDdEwsR0FEUCxFQUVFO0FBQUVzTSxnQkFBSSxFQUFFO0FBQUUsNkNBQStCO0FBQWpDO0FBQVIsV0FGRixFQUdFO0FBQUVDLGlCQUFLLEVBQUU7QUFBVCxXQUhGO0FBS0Q7O0FBQ0RqTyx1QkFBZSxDQUFDK04sTUFBaEIsQ0FDRTtBQUFFck0sYUFBRyxFQUFFc0wsSUFBSSxDQUFDdEw7QUFBWixTQURGLEVBRUUySixRQUFRLENBQUNvQyxrQkFBVCxDQUE0QlQsSUFBSSxDQUFDUSxRQUFqQyxDQUZGO0FBSUEseUJBQVVSLElBQUksQ0FBQ3RMLEdBQWYsdUJBQStCbU0sSUFBL0I7QUFDRCxPQWRELE1BY087QUFDTCxlQUFPLG9CQUFQO0FBQ0Q7QUFDRixLQWpDWTtBQW1DYkssaUJBQWEsRUFBR3pELEVBQUQsSUFBUTtBQUNyQixVQUNFdEUsTUFBTSxDQUFDK0csTUFBUCxPQUFvQnpDLEVBQXBCLElBQ0FXLEtBQUssQ0FBQzZCLFlBQU4sQ0FBbUI5RyxNQUFNLENBQUMrRyxNQUFQLEVBQW5CLEVBQW9DLE9BQXBDLENBRkYsRUFHRTtBQUNBL0csY0FBTSxDQUFDZ0gsS0FBUCxDQUFhZ0IsTUFBYixDQUFvQjtBQUFFek0sYUFBRyxFQUFFK0k7QUFBUCxTQUFwQjtBQUNBekssdUJBQWUsQ0FBQ21PLE1BQWhCLENBQXVCMUQsRUFBdkI7QUFDQSw4QkFBZUEsRUFBZjtBQUNELE9BUEQsTUFPTztBQUNMLGVBQU8sb0JBQVA7QUFDRDtBQUNGLEtBOUNZO0FBZ0RiMkQsa0JBQWMsRUFBRSxDQUFDM0QsRUFBRCxFQUFLdUMsSUFBTCxFQUFXZixXQUFYLEtBQTJCO0FBQ3pDLFVBQUk5RixNQUFNLENBQUMrRyxNQUFQLE9BQW9CekMsRUFBeEIsRUFBNEI7QUFDMUIsWUFBSXNCLGVBQWUsQ0FBQ2lCLElBQUQsRUFBT2YsV0FBUCxDQUFuQixFQUF3QztBQUN0Q1osa0JBQVEsQ0FBQ2dELFdBQVQsQ0FBcUI1RCxFQUFyQixFQUF5QndCLFdBQXpCO0FBQ0FqTSx5QkFBZSxDQUFDK04sTUFBaEIsQ0FBdUI7QUFBRXJNLGVBQUcsRUFBRStJO0FBQVAsV0FBdkIsRUFBb0N0RSxNQUFNLENBQUM2RyxJQUFQLEVBQXBDO0FBQ0E7QUFDRCxTQUpELE1BSU87QUFDTCxrREFBaUNmLFdBQWpDO0FBQ0Q7QUFDRixPQVJELE1BUU87QUFDTCxlQUFPLG9CQUFQO0FBQ0Q7QUFDRixLQTVEWTtBQThEYnFDLGVBQVcsRUFBRSxDQUFDN0QsRUFBRCxFQUFLb0IsS0FBTCxFQUFZRixRQUFaLEtBQXlCO0FBQ3BDLFVBQUl4RixNQUFNLENBQUMrRyxNQUFQLE9BQW9CekMsRUFBeEIsRUFBNEI7QUFDMUIsWUFBSWdCLFlBQVksQ0FBQ0ksS0FBRCxFQUFRRixRQUFSLENBQWhCLEVBQW1DO0FBQ2pDTixrQkFBUSxDQUFDa0QsV0FBVCxDQUFxQjlELEVBQXJCLEVBQXlCb0IsS0FBekI7QUFDQVIsa0JBQVEsQ0FBQ21ELFFBQVQsQ0FBa0IvRCxFQUFsQixFQUFzQmtCLFFBQXRCO0FBQ0FOLGtCQUFRLENBQUNxQixxQkFBVCxDQUErQmpDLEVBQS9CLEVBQW1Da0IsUUFBbkM7QUFDQTNMLHlCQUFlLENBQUMrTixNQUFoQixDQUF1QjtBQUFFck0sZUFBRyxFQUFFK0k7QUFBUCxXQUF2QixFQUFvQ3RFLE1BQU0sQ0FBQzZHLElBQVAsRUFBcEM7QUFDQTtBQUNELFNBTkQsTUFNTztBQUNMLCtDQUE4QnJCLFFBQTlCO0FBQ0Q7QUFDRixPQVZELE1BVU87QUFDTCxlQUFPLG9CQUFQO0FBQ0Q7QUFDRixLQTVFWTtBQThFYjhDLGtCQUFjLEVBQUUsQ0FBQ3pCLElBQUQsRUFBT25MLE9BQVAsS0FBbUI7QUFDakMsVUFBSXNFLE1BQU0sQ0FBQytHLE1BQVgsRUFBbUI7QUFDakIsWUFBSXdCLFNBQVMsR0FBR3ZJLE1BQU0sQ0FBQzZHLElBQVAsR0FBYzBCLFNBQTlCOztBQUNBLFlBQUlBLFNBQVMsQ0FBQ3RKLE9BQVYsQ0FBa0J2RCxPQUFsQixNQUErQixDQUFDLENBQXBDLEVBQXVDO0FBQ3JDNk0sbUJBQVMsQ0FBQ2hPLElBQVYsQ0FBZW1CLE9BQWY7QUFDRCxTQUZELE1BRU87QUFDTDZNLG1CQUFTLENBQUNDLE1BQVYsQ0FBaUJELFNBQVMsQ0FBQ3RKLE9BQVYsQ0FBa0J2RCxPQUFsQixDQUFqQixFQUE2QyxDQUE3QztBQUNEOztBQUNEc0UsY0FBTSxDQUFDZ0gsS0FBUCxDQUFhWSxNQUFiLENBQW9CZixJQUFwQixFQUEwQjtBQUFFZ0IsY0FBSSxFQUFFO0FBQUVVLHFCQUFTLEVBQUVBO0FBQWI7QUFBUixTQUExQjtBQUNBLGVBQU92SSxNQUFNLENBQUM2RyxJQUFQLEdBQWMwQixTQUFyQjtBQUNELE9BVEQsTUFTTztBQUNMLGVBQU8sQ0FBQyxvQkFBRCxDQUFQO0FBQ0Q7QUFDRixLQTNGWTtBQTZGYkUsY0FBVSxFQUFFLENBQUM1QixJQUFELEVBQU9hLElBQVAsS0FBZ0I7QUFDMUIsVUFBSXpDLEtBQUssQ0FBQzZCLFlBQU4sQ0FBbUI5RyxNQUFNLENBQUMrRyxNQUFQLEVBQW5CLEVBQW9DLE9BQXBDLENBQUosRUFBa0Q7QUFDaEQsWUFBSTtBQUNGOUIsZUFBSyxDQUFDeUQsb0JBQU4sQ0FBMkI3QixJQUFJLENBQUN0TCxHQUFoQyxFQUFxQ21NLElBQXJDO0FBQ0E3Tix5QkFBZSxDQUFDK04sTUFBaEIsQ0FDRTtBQUFFck0sZUFBRyxFQUFFc0wsSUFBSSxDQUFDdEw7QUFBWixXQURGLEVBRUUySixRQUFRLENBQUNvQyxrQkFBVCxDQUE0QlQsSUFBSSxDQUFDUSxRQUFqQyxDQUZGO0FBSUEsZ0NBQWVSLElBQUksQ0FBQ3RMLEdBQXBCLDRCQUF5Q21NLElBQXpDO0FBQ0QsU0FQRCxDQU9FLE9BQU9oSixHQUFQLEVBQVk7QUFDWixpQkFBT0EsR0FBUDtBQUNEO0FBQ0YsT0FYRCxNQVdPO0FBQ0wsZUFBTyxvQkFBUDtBQUNEO0FBQ0YsS0E1R1k7QUE4R2JpSyxpQkFBYSxFQUFHOUIsSUFBRCxJQUFVO0FBQ3ZCLFVBQUkrQixVQUFVLEdBQ1oxRCxRQUFRLENBQUNvQyxrQkFBVCxDQUE0QlQsSUFBNUIsS0FBcUMzQixRQUFRLENBQUNzQyxlQUFULENBQXlCWCxJQUF6QixDQUR2QztBQUVBLGFBQU81QixLQUFLLENBQUM2QixZQUFOLENBQW1COEIsVUFBbkIsYUFBbUJBLFVBQW5CLHVCQUFtQkEsVUFBVSxDQUFFck4sR0FBL0IsRUFBb0MsU0FBcEMsQ0FBUDtBQUNELEtBbEhZO0FBb0hic04sYUFBUyxFQUFFLENBQUN2RSxFQUFELEVBQUtvQixLQUFMLEtBQWU7QUFDeEIsVUFBSTFGLE1BQU0sQ0FBQytHLE1BQVAsT0FBb0J6QyxFQUF4QixFQUE0QjtBQUMxQlksZ0JBQVEsQ0FBQ3FCLHFCQUFULENBQStCakMsRUFBL0IsRUFBbUNvQixLQUFuQztBQUNELE9BRkQsTUFFTztBQUNMLGVBQU8sb0JBQVA7QUFDRDtBQUNGLEtBMUhZO0FBNEhib0QsZ0JBQVksRUFBRSxDQUFDcEQsS0FBRCxFQUFRMkIsUUFBUixFQUFrQjBCLFFBQWxCLEtBQStCO0FBQzNDLFVBQ0V6RCxZQUFZLENBQUMsSUFBRCxFQUFPSSxLQUFQLENBQVosSUFDQUUsZUFBZSxDQUFDLElBQUQsRUFBT3lCLFFBQVAsQ0FEZixJQUVBckIsZUFBZSxDQUFDLElBQUQsRUFBTytDLFFBQVAsQ0FIakIsRUFJRTtBQUNBLFlBQUk7QUFDRjdELGtCQUFRLENBQUM4RCxVQUFULENBQW9CO0FBQ2xCdEQsaUJBQUssRUFBRUEsS0FEVztBQUVsQjJCLG9CQUFRLEVBQUVBLFFBRlE7QUFHbEIwQixvQkFBUSxFQUFFQTtBQUhRLFdBQXBCO0FBS0EsNkNBQTRCMUIsUUFBNUI7QUFDRCxTQVBELENBT0UsT0FBTzNJLEdBQVAsRUFBWTtBQUNaLGlCQUFPQSxHQUFHLENBQUMvQixPQUFYO0FBQ0Q7QUFDRixPQWZELE1BZU87QUFDTCxlQUFPLHVFQUFQO0FBQ0Q7QUFDRjtBQS9JWSxHQUFmO0FBa0pBdUksVUFBUSxDQUFDK0QsWUFBVCxDQUFzQixDQUFDQyxDQUFELEVBQUlyQyxJQUFKLEtBQWE7QUFDakNBLFFBQUksQ0FBQyxXQUFELENBQUosR0FBb0IsRUFBcEI7QUFDQUEsUUFBSSxDQUFDLE9BQUQsQ0FBSixHQUFnQixFQUFoQjtBQUNBaE4sbUJBQWUsQ0FBQ3NQLE1BQWhCLENBQXVCdEMsSUFBdkI7QUFDQSxXQUFPQSxJQUFQO0FBQ0QsR0FMRCxFQTlMbUIsQ0FxTW5COztBQUNBN0csUUFBTSxDQUFDb0osSUFBUCxDQUFZLFlBQVosRUFBMEIsT0FBMUIsRUFBbUMsQ0FBQ0YsQ0FBRCxFQUFJM0YsR0FBSixLQUFZO0FBQzdDLFFBQUlBLEdBQUosRUFBUztBQUNQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wyQixjQUFRLENBQUM4RCxVQUFULENBQW9CO0FBQ2xCdEQsYUFBSyxFQUFFLGlCQURXO0FBRWxCMkIsZ0JBQVEsRUFBRSxPQUZRO0FBR2xCMEIsZ0JBQVEsRUFBRTtBQUhRLE9BQXBCO0FBS0E5RCxXQUFLLENBQUMwQyxlQUFOLENBQXNCekMsUUFBUSxDQUFDb0Msa0JBQVQsQ0FBNEIsT0FBNUIsQ0FBdEIsRUFBNEQsT0FBNUQ7QUFDRDtBQUNGLEdBWEQsRUF0TW1CLENBbU5uQjs7QUFDQXRILFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZTtBQUNia0MsWUFBUSxFQUFHeE4sR0FBRCxJQUFTO0FBQ2pCdkMsc0JBQWdCLENBQUM2UCxNQUFqQixDQUF3QnROLEdBQXhCO0FBQ0Q7QUFIWSxHQUFmLEVBcE5tQixDQTBObkI7O0FBQ0EsTUFBSXZDLGdCQUFnQixDQUFDK0MsSUFBakIsR0FBd0JpTixLQUF4QixPQUFvQyxDQUF4QyxFQUEyQztBQUN6QzNFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaO0FBQ0EsVUFBTTJFLE1BQU0sR0FBRztBQUNiMUMsVUFBSSxFQUFFLGlCQURPO0FBRWIyQyxVQUFJLEVBQUUsSUFBSUMsSUFBSixFQUZPO0FBR2JDLFNBQUcsRUFBRSxnQkFIUTtBQUliQyxZQUFNLEVBQUUsWUFKSztBQUtidEYsV0FBSyxFQUFFO0FBTE0sS0FBZjtBQU9BL0ssb0JBQWdCLENBQUM2UCxNQUFqQixDQUF3QkksTUFBeEIsRUFUeUMsQ0FVekM7QUFDRDs7QUFFRHZKLFFBQU0sQ0FBQzRHLE9BQVAsQ0FBZSxRQUFmLEVBQXlCLE1BQU07QUFDN0IsV0FBT3ROLGdCQUFnQixDQUFDK0MsSUFBakIsQ0FBc0IsRUFBdEIsQ0FBUDtBQUNELEdBRkQsRUF4T21CLENBNE9uQjs7QUFDQSxNQUFJeEMsZUFBZSxDQUFDd0MsSUFBaEIsR0FBdUJpTixLQUF2QixPQUFtQyxDQUF2QyxFQUEwQztBQUN4QzNFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaO0FBQ0EsVUFBTW9DLEtBQUssR0FBR2hILE1BQU0sQ0FBQ2dILEtBQVAsQ0FDWDNLLElBRFcsQ0FDTixFQURNLEVBQ0Y7QUFBRWpCLFlBQU0sRUFBRTtBQUFFRyxXQUFHLEVBQUUsQ0FBUDtBQUFVOEwsZ0JBQVEsRUFBRSxDQUFwQjtBQUF1QnVDLGNBQU0sRUFBRSxDQUEvQjtBQUFrQzNDLGFBQUssRUFBRTtBQUF6QztBQUFWLEtBREUsRUFFWDNLLEtBRlcsRUFBZCxDQUZ3QyxDQUt4Qzs7QUFDQTBLLFNBQUssQ0FBQzdMLE9BQU4sQ0FBZTBMLElBQUQsSUFBVWhOLGVBQWUsQ0FBQ3NQLE1BQWhCLENBQXVCdEMsSUFBdkIsQ0FBeEI7QUFDRDs7QUFFRDdHLFFBQU0sQ0FBQzRHLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLE1BQU07QUFDL0IsV0FBTy9NLGVBQWUsQ0FBQ3dDLElBQWhCLENBQXFCLEVBQXJCLENBQVA7QUFDRCxHQUZELEVBdFBtQixDQTBQbkI7QUFDQTs7QUFDQSxNQUFJekMsZ0JBQWdCLENBQUN5QyxJQUFqQixHQUF3QmlOLEtBQXhCLE9BQW9DLENBQXhDLEVBQTJDO0FBQ3pDM0UsV0FBTyxDQUFDQyxHQUFSLENBQVkseUJBQVo7QUFDQSxRQUFJaUYsT0FBTyxHQUFHLEVBQWQ7QUFDQUMsU0FBSyxHQUFHM0UsRUFBRSxDQUFDNEUsV0FBSCxDQUFlLHFCQUFmLENBQVI7QUFDQUQsU0FBSyxDQUFDM08sT0FBTixDQUFjLFVBQVU2TyxJQUFWLEVBQWdCO0FBQzVCekosVUFBSSxHQUFHNEUsRUFBRSxDQUFDOEUsWUFBSCxDQUFnQix5QkFBeUJELElBQXpDLEVBQStDLE9BQS9DLENBQVA7QUFDQUgsYUFBTyxDQUFDdFAsSUFBUixDQUFhcUUsSUFBSSxDQUFDc0wsS0FBTCxDQUFXM0osSUFBWCxDQUFiO0FBQ0QsS0FIRDtBQUlBc0osV0FBTyxDQUFDMU8sT0FBUixDQUFnQixVQUFVb0YsSUFBVixFQUFnQjtBQUM5QjNHLHNCQUFnQixDQUFDdVAsTUFBakIsQ0FBd0I1SSxJQUF4QjtBQUNELEtBRkQ7QUFHRCxHQXZRa0IsQ0F5UW5COzs7QUFDQSxNQUFJNUcsbUJBQW1CLENBQUMwQyxJQUFwQixHQUEyQmlOLEtBQTNCLE9BQXVDLENBQTNDLEVBQThDO0FBQzVDM0UsV0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVo7QUFDQSxRQUFJaUYsT0FBTyxHQUFHLEVBQWQ7QUFDQUMsU0FBSyxHQUFHM0UsRUFBRSxDQUFDNEUsV0FBSCxDQUFlLHdCQUFmLENBQVI7QUFDQUQsU0FBSyxDQUFDM08sT0FBTixDQUFjLFVBQVU2TyxJQUFWLEVBQWdCO0FBQzVCekosVUFBSSxHQUFHNEUsRUFBRSxDQUFDOEUsWUFBSCxDQUFnQiw0QkFBNEJELElBQTVDLEVBQWtELE9BQWxELENBQVA7QUFDQUgsYUFBTyxDQUFDdFAsSUFBUixDQUFhcUUsSUFBSSxDQUFDc0wsS0FBTCxDQUFXM0osSUFBWCxDQUFiO0FBQ0QsS0FIRDtBQUlBc0osV0FBTyxDQUFDMU8sT0FBUixDQUFnQixVQUFVb0YsSUFBVixFQUFnQjtBQUM5QjVHLHlCQUFtQixDQUFDd1AsTUFBcEIsQ0FBMkI1SSxJQUEzQjtBQUNELEtBRkQ7QUFHRCxHQXJSa0IsQ0F1Um5COzs7QUFDQVAsUUFBTSxDQUFDNEcsT0FBUCxDQUFlLFlBQWYsRUFBNkIsTUFBTTtBQUNqQyxXQUFPak4sbUJBQW1CLENBQUMwQyxJQUFwQixDQUF5QixFQUF6QixDQUFQO0FBQ0QsR0FGRCxFQXhSbUIsQ0EyUm5COztBQUNBMkQsUUFBTSxDQUFDNEcsT0FBUCxDQUFlLFNBQWYsRUFBMEIsTUFBTTtBQUM5QixXQUFPaE4sZ0JBQWdCLENBQUN5QyxJQUFqQixDQUFzQixFQUF0QixDQUFQO0FBQ0QsR0FGRCxFQTVSbUIsQ0FnU25COztBQUNBMkQsUUFBTSxDQUFDbUgsT0FBUCxDQUFlO0FBQ2JnRCxtQkFBZSxFQUFFLENBQUN0UCxNQUFELEVBQVNaLFVBQVQsS0FBd0I7QUFDdkMsVUFBSStGLE1BQU0sQ0FBQytHLE1BQVAsRUFBSixFQUFxQjtBQUNuQixZQUFJMUMsS0FBSyxHQUFHLElBQVo7QUFDQXhKLGNBQU0sQ0FBQyxXQUFELENBQU4sR0FBc0IsS0FBdEI7QUFDQUEsY0FBTSxDQUFDLFdBQUQsQ0FBTixHQUFzQixJQUFJNE8sSUFBSixFQUF0QjtBQUNBNU8sY0FBTSxDQUFDLFdBQUQsQ0FBTixHQUFzQm1GLE1BQU0sQ0FBQzZHLElBQVAsR0FBY1EsUUFBcEM7QUFDQXhNLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUIsSUFBSTRPLElBQUosRUFBdkI7QUFDQTVPLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUJtRixNQUFNLENBQUM2RyxJQUFQLEdBQWNRLFFBQXJDO0FBQ0F4TSxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLEtBQXZCO0FBRUFmLGdDQUF3QixDQUFDZSxNQUFELEVBQVNaLFVBQVQsQ0FBeEIsQ0FDR3FFLFFBREgsQ0FDWXpELE1BRFosRUFFRzJELElBRkgsQ0FFUSxNQUFNO0FBQ1YsY0FBSXlHLEtBQUssQ0FBQzZCLFlBQU4sQ0FBbUI5RyxNQUFNLENBQUMrRyxNQUFQLEVBQW5CLEVBQW9DLE9BQXBDLENBQUosRUFBa0Q7QUFDaERsTSxrQkFBTSxDQUFDLFlBQUQsQ0FBTixHQUF1QixJQUF2QjtBQUNEOztBQUNEbEIsNkJBQW1CLENBQUN3UCxNQUFwQixDQUEyQnRPLE1BQTNCO0FBQ0QsU0FQSCxFQVFHNEQsS0FSSCxDQVFVQyxHQUFELElBQVUyRixLQUFLLEdBQUczRixHQVIzQjtBQVNBLGVBQU8yRixLQUFQO0FBQ0QsT0FuQkQsTUFtQk87QUFDTCxlQUFPLG9CQUFQO0FBQ0Q7QUFDRixLQXhCWTtBQXlCYitGLG1CQUFlLEVBQUUsQ0FBQ3ZQLE1BQUQsRUFBU1osVUFBVCxLQUF3QjtBQUN2QyxVQUFJK0YsTUFBTSxDQUFDK0csTUFBUCxFQUFKLEVBQXFCO0FBQ25CLFlBQUkxQyxLQUFLLEdBQUcsSUFBWjs7QUFDQSxZQUFJLENBQUN4SixNQUFNLENBQUMsV0FBRCxDQUFQLElBQXdCLENBQUNBLE1BQU0sQ0FBQyxXQUFELENBQW5DLEVBQWtEO0FBQ2hEQSxnQkFBTSxDQUFDLFdBQUQsQ0FBTixHQUFzQixJQUFJNE8sSUFBSixFQUF0QjtBQUNBNU8sZ0JBQU0sQ0FBQyxXQUFELENBQU4sR0FBc0JtRixNQUFNLENBQUM2RyxJQUFQLEdBQWNRLFFBQXBDO0FBQ0Q7O0FBQ0R4TSxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLElBQUk0TyxJQUFKLEVBQXZCO0FBQ0E1TyxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCbUYsTUFBTSxDQUFDNkcsSUFBUCxHQUFjUSxRQUFyQztBQUNBeE0sY0FBTSxDQUFDLFlBQUQsQ0FBTixHQUF1QixLQUF2QjtBQUVBZixnQ0FBd0IsQ0FBQ2UsTUFBRCxFQUFTWixVQUFULENBQXhCLENBQ0dxRSxRQURILENBQ1l6RCxNQURaLEVBRUcyRCxJQUZILENBRVEsTUFBTTtBQUNWLGNBQUl5RyxLQUFLLENBQUM2QixZQUFOLENBQW1COUcsTUFBTSxDQUFDK0csTUFBUCxFQUFuQixFQUFvQyxPQUFwQyxDQUFKLEVBQWtEO0FBQ2hEbE0sa0JBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUIsSUFBdkI7QUFDRDs7QUFDRGxCLDZCQUFtQixDQUFDaU8sTUFBcEIsQ0FBMkI7QUFBRXJNLGVBQUcsRUFBRVYsTUFBTSxDQUFDVTtBQUFkLFdBQTNCLEVBQWdEVixNQUFoRDtBQUNELFNBUEgsRUFRRzRELEtBUkgsQ0FRVUMsR0FBRCxJQUFVMkYsS0FBSyxHQUFHM0YsR0FSM0I7QUFTQSxlQUFPMkYsS0FBUDtBQUNELE9BcEJELE1Bb0JPO0FBQ0wsZUFBTyxvQkFBUDtBQUNEO0FBQ0YsS0FqRFk7QUFrRGJnRyxtQkFBZSxFQUFHeFAsTUFBRCxJQUFZO0FBQzNCLFVBQUltRixNQUFNLENBQUMrRyxNQUFQLEVBQUosRUFBcUI7QUFDbkJsTSxjQUFNLENBQUMsV0FBRCxDQUFOLEdBQXNCLElBQXRCO0FBQ0FBLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUIsSUFBSTRPLElBQUosRUFBdkI7QUFDQTVPLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUJtRixNQUFNLENBQUM2RyxJQUFQLEdBQWNRLFFBQXJDO0FBQ0ExTiwyQkFBbUIsQ0FBQ2lPLE1BQXBCLENBQTJCO0FBQUVyTSxhQUFHLEVBQUVWLE1BQU0sQ0FBQ1U7QUFBZCxTQUEzQixFQUFnRFYsTUFBaEQ7QUFDRCxPQUxELE1BS087QUFDTCxlQUFPLG9CQUFQO0FBQ0Q7QUFDRixLQTNEWTtBQTREYnlQLDJCQUF1QixFQUFHelAsTUFBRCxJQUFZO0FBQ25DLFVBQUlvSyxLQUFLLENBQUM2QixZQUFOLENBQW1COUcsTUFBTSxDQUFDK0csTUFBUCxFQUFuQixFQUFvQyxPQUFwQyxDQUFKLEVBQWtEO0FBQ2hEcE4sMkJBQW1CLENBQUNxTyxNQUFwQixDQUEyQm5OLE1BQU0sQ0FBQ1UsR0FBbEM7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPLG9CQUFQO0FBQ0Q7QUFDRixLQWxFWTtBQW1FYmdQLG9CQUFnQixFQUFHMVAsTUFBRCxJQUFZO0FBQzVCLFVBQUlvSyxLQUFLLENBQUM2QixZQUFOLENBQW1COUcsTUFBTSxDQUFDK0csTUFBUCxFQUFuQixFQUFvQyxPQUFwQyxDQUFKLEVBQWtEO0FBQ2hEbE0sY0FBTSxDQUFDLFdBQUQsQ0FBTixHQUFzQixLQUF0QjtBQUNBQSxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLElBQUk0TyxJQUFKLEVBQXZCO0FBQ0E1TyxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCbUYsTUFBTSxDQUFDNkcsSUFBUCxHQUFjUSxRQUFyQztBQUNBMU4sMkJBQW1CLENBQUNpTyxNQUFwQixDQUEyQjtBQUFFck0sYUFBRyxFQUFFVixNQUFNLENBQUNVO0FBQWQsU0FBM0IsRUFBZ0RWLE1BQWhEO0FBQ0QsT0FMRCxNQUtPO0FBQ0wsZUFBTyxvQkFBUDtBQUNEO0FBQ0YsS0E1RVk7QUE2RWIyUCx1QkFBbUIsRUFBRzNQLE1BQUQsSUFBWTtBQUMvQixVQUFJb0ssS0FBSyxDQUFDNkIsWUFBTixDQUFtQjlHLE1BQU0sQ0FBQytHLE1BQVAsRUFBbkIsRUFBb0MsT0FBcEMsQ0FBSixFQUFrRDtBQUNoRGxNLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUIsSUFBdkI7QUFDQWxCLDJCQUFtQixDQUFDaU8sTUFBcEIsQ0FBMkI7QUFBRXJNLGFBQUcsRUFBRVYsTUFBTSxDQUFDVTtBQUFkLFNBQTNCLEVBQWdEVixNQUFoRDtBQUNELE9BSEQsTUFHTztBQUNMLGVBQU8sb0JBQVA7QUFDRDtBQUNGO0FBcEZZLEdBQWYsRUFqU21CLENBd1huQjs7QUFDQW1GLFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZTtBQUNic0QsZ0JBQVksRUFBRSxDQUFDeFEsVUFBRCxFQUFhWSxNQUFiLEtBQXdCO0FBQ3BDLFVBQUltRixNQUFNLENBQUMrRyxNQUFQLEVBQUosRUFBcUI7QUFDbkIsWUFBSTFDLEtBQUssR0FBRyxJQUFaO0FBQ0EsY0FBTXpKLE9BQU8sR0FBR2hCLGdCQUFnQixDQUFDeUMsSUFBakIsR0FBd0JDLEtBQXhCLEVBQWhCO0FBQ0F6QixjQUFNLENBQUMsV0FBRCxDQUFOLEdBQXNCLEtBQXRCO0FBQ0FBLGNBQU0sQ0FBQyxXQUFELENBQU4sR0FBc0IsSUFBSTRPLElBQUosRUFBdEI7QUFDQTVPLGNBQU0sQ0FBQyxXQUFELENBQU4sR0FBc0JtRixNQUFNLENBQUM2RyxJQUFQLEdBQWNRLFFBQXBDO0FBQ0F4TSxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLElBQUk0TyxJQUFKLEVBQXZCO0FBQ0E1TyxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCbUYsTUFBTSxDQUFDNkcsSUFBUCxHQUFjUSxRQUFyQztBQUNBeE0sY0FBTSxDQUFDLFlBQUQsQ0FBTixHQUF1QixLQUF2QjtBQUNBd0UsNkJBQXFCLENBQUNwRixVQUFELEVBQWFXLE9BQWIsQ0FBckIsQ0FDRzBELFFBREgsQ0FDWXpELE1BRFosRUFFRzJELElBRkgsQ0FFUSxNQUFNO0FBQ1YsY0FBSXlHLEtBQUssQ0FBQzZCLFlBQU4sQ0FBbUI5RyxNQUFNLENBQUMrRyxNQUFQLEVBQW5CLEVBQW9DLE9BQXBDLENBQUosRUFBa0Q7QUFDaERsTSxrQkFBTSxDQUFDLFlBQUQsQ0FBTixHQUF1QixJQUF2QjtBQUNEOztBQUNELGlCQUFPakIsZ0JBQWdCLENBQUN1UCxNQUFqQixDQUF3QnRPLE1BQXhCLENBQVA7QUFDRCxTQVBILEVBUUc0RCxLQVJILENBUVU0RixLQUFELElBQVc7QUFDaEIzRixhQUFHLEdBQUcyRixLQUFOO0FBQ0QsU0FWSDtBQVdBLGVBQU9BLEtBQVA7QUFDRCxPQXJCRCxNQXFCTztBQUNMLGVBQU8sb0JBQVA7QUFDRDtBQUNGLEtBMUJZO0FBMkJicUcsZ0JBQVksRUFBRSxDQUFDelEsVUFBRCxFQUFhWSxNQUFiLEtBQXdCO0FBQ3BDLFVBQUltRixNQUFNLENBQUMrRyxNQUFQLEVBQUosRUFBcUI7QUFDbkIsWUFBSTFDLEtBQUssR0FBRyxJQUFaO0FBQ0EsY0FBTXpKLE9BQU8sR0FBR2hCLGdCQUFnQixDQUFDeUMsSUFBakIsR0FBd0JDLEtBQXhCLEVBQWhCOztBQUNBLFlBQUksQ0FBQ3pCLE1BQU0sQ0FBQyxXQUFELENBQVAsSUFBd0IsQ0FBQ0EsTUFBTSxDQUFDLFdBQUQsQ0FBbkMsRUFBa0Q7QUFDaERBLGdCQUFNLENBQUMsV0FBRCxDQUFOLEdBQXNCLElBQUk0TyxJQUFKLEVBQXRCO0FBQ0E1TyxnQkFBTSxDQUFDLFdBQUQsQ0FBTixHQUFzQm1GLE1BQU0sQ0FBQzZHLElBQVAsR0FBY1EsUUFBcEM7QUFDRDs7QUFDRHhNLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUIsSUFBSTRPLElBQUosRUFBdkI7QUFDQTVPLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUJtRixNQUFNLENBQUM2RyxJQUFQLEdBQWNRLFFBQXJDO0FBQ0F4TSxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLEtBQXZCO0FBQ0F3RSw2QkFBcUIsQ0FBQ3BGLFVBQUQsRUFBYVcsT0FBYixDQUFyQixDQUNHMEQsUUFESCxDQUNZekQsTUFEWixFQUVHMkQsSUFGSCxDQUVRLE1BQU07QUFDVixjQUFJeUcsS0FBSyxDQUFDNkIsWUFBTixDQUFtQjlHLE1BQU0sQ0FBQytHLE1BQVAsRUFBbkIsRUFBb0MsT0FBcEMsQ0FBSixFQUFrRDtBQUNoRGxNLGtCQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLElBQXZCO0FBQ0Q7O0FBQ0QsaUJBQU9qQixnQkFBZ0IsQ0FBQ2dPLE1BQWpCLENBQXdCO0FBQUVyTSxlQUFHLEVBQUVWLE1BQU0sQ0FBQ1U7QUFBZCxXQUF4QixFQUE2Q1YsTUFBN0MsQ0FBUDtBQUNELFNBUEgsRUFRRzRELEtBUkgsQ0FRVUMsR0FBRCxJQUFTaUcsT0FBTyxDQUFDakcsR0FBUixDQUFZQSxHQUFaLENBUmxCO0FBU0EsZUFBTzJGLEtBQVA7QUFDRCxPQXBCRCxNQW9CTztBQUNMLGVBQU8sb0JBQVA7QUFDRDtBQUNGLEtBbkRZO0FBb0Ric0csZ0JBQVksRUFBRzlQLE1BQUQsSUFBWTtBQUN4QixVQUFJbUYsTUFBTSxDQUFDK0csTUFBUCxFQUFKLEVBQXFCO0FBQ25CbE0sY0FBTSxDQUFDLFdBQUQsQ0FBTixHQUFzQixJQUF0QjtBQUNBQSxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLElBQUk0TyxJQUFKLEVBQXZCO0FBQ0E1TyxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCbUYsTUFBTSxDQUFDNkcsSUFBUCxHQUFjUSxRQUFyQztBQUNBek4sd0JBQWdCLENBQUNnTyxNQUFqQixDQUF3QjtBQUFFck0sYUFBRyxFQUFFVixNQUFNLENBQUNVO0FBQWQsU0FBeEIsRUFBNkNWLE1BQTdDO0FBQ0QsT0FMRCxNQUtPO0FBQ0wsZUFBTyxvQkFBUDtBQUNEO0FBQ0YsS0E3RFk7QUE4RGIrUCx3QkFBb0IsRUFBRy9QLE1BQUQsSUFBWTtBQUNoQyxVQUFJb0ssS0FBSyxDQUFDNkIsWUFBTixDQUFtQjlHLE1BQU0sQ0FBQytHLE1BQVAsRUFBbkIsRUFBb0MsT0FBcEMsQ0FBSixFQUFrRDtBQUNoRG5OLHdCQUFnQixDQUFDb08sTUFBakIsQ0FBd0JuTixNQUFNLENBQUNVLEdBQS9CO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsZUFBTyxvQkFBUDtBQUNEO0FBQ0YsS0FwRVk7QUFxRWJzUCxpQkFBYSxFQUFHaFEsTUFBRCxJQUFZO0FBQ3pCLFVBQUlvSyxLQUFLLENBQUM2QixZQUFOLENBQW1COUcsTUFBTSxDQUFDK0csTUFBUCxFQUFuQixFQUFvQyxPQUFwQyxDQUFKLEVBQWtEO0FBQ2hEbE0sY0FBTSxDQUFDLFdBQUQsQ0FBTixHQUFzQixLQUF0QjtBQUNBQSxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCLElBQUk0TyxJQUFKLEVBQXZCO0FBQ0E1TyxjQUFNLENBQUMsWUFBRCxDQUFOLEdBQXVCbUYsTUFBTSxDQUFDNkcsSUFBUCxHQUFjUSxRQUFyQztBQUNBek4sd0JBQWdCLENBQUNnTyxNQUFqQixDQUF3QjtBQUFFck0sYUFBRyxFQUFFVixNQUFNLENBQUNVO0FBQWQsU0FBeEIsRUFBNkNWLE1BQTdDO0FBQ0QsT0FMRCxNQUtPO0FBQ0wsZUFBTyxvQkFBUDtBQUNEO0FBQ0YsS0E5RVk7QUErRWJpUSxvQkFBZ0IsRUFBR2pRLE1BQUQsSUFBWTtBQUM1QixVQUFJb0ssS0FBSyxDQUFDNkIsWUFBTixDQUFtQjlHLE1BQU0sQ0FBQytHLE1BQVAsRUFBbkIsRUFBb0MsT0FBcEMsQ0FBSixFQUFrRDtBQUNoRGxNLGNBQU0sQ0FBQyxZQUFELENBQU4sR0FBdUIsSUFBdkI7QUFDQWpCLHdCQUFnQixDQUFDZ08sTUFBakIsQ0FBd0I7QUFBRXJNLGFBQUcsRUFBRVYsTUFBTSxDQUFDVTtBQUFkLFNBQXhCLEVBQTZDVixNQUE3QztBQUNELE9BSEQsTUFHTztBQUNMLGVBQU8sb0JBQVA7QUFDRDtBQUNGO0FBdEZZLEdBQWY7QUF3RkQsQ0FqZEQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tIFwibWV0ZW9yL21vbmdvXCI7XG5cbmV4cG9ydCBjb25zdCBFcnJvcnNDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJlcnJvcnNcIik7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gXCJtZXRlb3IvbW9uZ29cIjtcblxuZXhwb3J0IGNvbnN0IFNhdGVsbGl0ZUNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInNhdGVsbGl0ZXNcIik7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gXCJtZXRlb3IvbW9uZ29cIjtcblxuZXhwb3J0IGNvbnN0IFNjaGVtYUNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInNjaGVtYXNcIik7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gXCJtZXRlb3IvbW9uZ29cIjtcblxuZXhwb3J0IGNvbnN0IFVzZXJzQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwidXNlckxpc3RcIik7XG4iLCIvKipcbiAqIFBMRUFTRSBFTlNVUkUgVEhBVCBBTlkgQ0hBTkdFUyBNQURFIEhFUkUgQVJFIFJFRkxFQ1RFRCBJTiBDTElFTlQtU0lERSBVVElMU1xuICoqL1xuXG5pbXBvcnQgKiBhcyBZdXAgZnJvbSBcInl1cFwiO1xuaW1wb3J0IHsgU2NoZW1hQ29sbGVjdGlvbiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvc2NoZW1hc1wiO1xuaW1wb3J0IHsgU2F0ZWxsaXRlQ29sbGVjdGlvbiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvc2F0ZWxsaXRlc1wiO1xuXG5jb25zdCBpc1VuaXF1ZUxpc3QgPSAoaW5pdFZhbHVlcywgc2F0cywgcGF0aCwgZmllbGQpID0+IHtcbiAgbGV0IGxpc3QgPSBbXTtcbiAgaWYgKCFwYXRoKSB7XG4gICAgZm9yIChsZXQgc2F0IGluIHNhdHMpIHtcbiAgICAgIHNhdHNbc2F0XVtmaWVsZF0gPT09IGluaXRWYWx1ZXNbZmllbGRdXG4gICAgICAgID8gbnVsbFxuICAgICAgICA6IGxpc3QucHVzaChzYXRzW3NhdF1bZmllbGRdKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaW5pdFZhbHVlc1twYXRoXSkge1xuICAgIGZvciAobGV0IHNhdCBpbiBzYXRzKSB7XG4gICAgICBsZXQgc2F0RW50cmllcyA9IHNhdHNbc2F0XVtwYXRoXTtcbiAgICAgIGZvciAobGV0IGVudHJ5IGluIHNhdEVudHJpZXMpIHtcbiAgICAgICAgc2F0RW50cmllc1tlbnRyeV1bZmllbGRdID09PVxuICAgICAgICAoaW5pdFZhbHVlc1twYXRoXS5sZW5ndGggPiAwID8gaW5pdFZhbHVlc1twYXRoXVtlbnRyeV1bZmllbGRdIDogZmFsc2UpXG4gICAgICAgICAgPyBudWxsXG4gICAgICAgICAgOiBsaXN0LnB1c2goc2F0RW50cmllc1tlbnRyeV1bZmllbGRdKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGxpc3Q7XG59O1xuXG5jb25zdCBzY2hlbWFDbGVhbmVyID0gKHNjaGVtYXMsIHZhbHVlcykgPT4ge1xuICBsZXQgc2NoZW1hT2JqID0ge307IC8vIG9iamVjdDoge3NjaGVtYS5uYW1lOiB7ZmllbGQubmFtZToge2ZpZWxkLnR5cGU6IHN0cmluZy9udW1iZXIvZGF0ZSwgZmllbGQuYWxsb3dlZFZhbHVlczogW10sIHJlcXVpcmVkOiBmaWVsZC5yZXF1aXJlZCwgbWluOiBmaWVsZC5taW4sIG1heDogZmllbGQubWF4fX19XG5cbiAgbGV0IGNsZWFuU2NoZW1hcyA9IFtdOyAvLyBzdG9yZXMgb25seSB0aGUgc2NoZW1hcyBhcHBsaWNhYmxlIHRvIHRoZSBjdXJyZW50IHNhdGVsbGl0ZSB2YWx1ZXNcbiAgZm9yIChsZXQgdmFsdWUgaW4gdmFsdWVzKSB7XG4gICAgZm9yIChsZXQgc2NoZW1hIGluIHNjaGVtYXMpIHtcbiAgICAgIGlmIChzY2hlbWFzW3NjaGVtYV0ubmFtZSA9PT0gdmFsdWUpIGNsZWFuU2NoZW1hcy5wdXNoKHNjaGVtYXNbc2NoZW1hXSk7XG4gICAgfVxuICB9XG5cbiAgY2xlYW5TY2hlbWFzPy5mb3JFYWNoKChzY2hlbWEpID0+IHtcbiAgICAvLyBzdGVwIDE6IG1hcCBvdmVyIHNjaGVtYXMgYW5kIGFzc2lnbiBlYWNoIHNjaGVtYSBuYW1lIGFzIGEga2V5IGluIHRoZSBvYmplY3RcbiAgICBzY2hlbWFPYmpbc2NoZW1hLm5hbWVdID0ge307XG4gICAgLy8gc3RlcCAyOiBtYXAgb3ZlciBlYWNoIHNjaGVtYSBhbmQgYXNzaWduIGFuIG9iamVjdCBjb250YWluaW5nIGFsbCBmaWVsZCBuYW1lcyBhcyBrZXlzIGluIHRoYXQgb2JqZWN0XG4gICAgcmV0dXJuIHNjaGVtYS5maWVsZHMuZm9yRWFjaCgoZmllbGQpID0+IHtcbiAgICAgIHNjaGVtYU9ialtzY2hlbWEubmFtZV1bZmllbGQubmFtZV0gPSB7fTtcbiAgICAgIC8vIHN0ZXAgMzogbWFwIG92ZXIgZWFjaCBmaWVsZCBhbmQgYXNzaWduIGFuIG9iamVjdCBjb250YWluaW5nIGFsbCBvZiB0aGUgZmllbGQncyBhdHRyaWJ1dGVzICh0eXBlLCBhbGxvd2VkVmFsdWVzLCBtaW4sIG1heCwgcmVxdWlyZWQpXG4gICAgICBmb3IgKGxldCBhdHRyaWJ1dGUgaW4gZmllbGQpIHtcbiAgICAgICAgaWYgKGF0dHJpYnV0ZSAhPT0gXCJuYW1lXCIgJiYgYXR0cmlidXRlICE9PSBcImRlc2NyaXB0aW9uXCIpIHtcbiAgICAgICAgICAvLyBzdGVwIDQ6IFRha2UgZWFjaCBhdHRyaWJ1dGUncyB2YWx1ZSBhbmQgYXNzaWduIGl0IHRvIHRoZSBhdHRyaWJ1dGUgaW4gdGhlIG9iamVjdFxuICAgICAgICAgIHNjaGVtYU9ialtzY2hlbWEubmFtZV1bZmllbGQubmFtZV1bYXR0cmlidXRlXSA9IGZpZWxkW2F0dHJpYnV0ZV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG4gIHJldHVybiBzY2hlbWFPYmo7XG59O1xuXG5jb25zdCBpbml0aWFsWXVwU2hhcGVHZW5lcmF0b3IgPSAoaW5pdFZhbHVlcywgc2F0cywgaXNVbmlxdWVMaXN0KSA9PiB7XG4gIHJldHVybiB7XG4gICAgLy8gTk9SQUQgSUQgYW5kIF9pZCBhcmUgYWx3YXlzIGEgcGFydCBvZiB0aGUgeXVwIHNoYXBlXG4gICAgX2lkOiBZdXAuc3RyaW5nKCkubm90T25lT2YoXG4gICAgICBpc1VuaXF1ZUxpc3QoaW5pdFZhbHVlcywgc2F0cywgbnVsbCwgXCJfaWRcIiksXG4gICAgICBcIlNvbWV0aGluZyB3ZW50IHdyb25nIHdoaWxlIGFzc2lnbmluZyBfaWRcIlxuICAgICksXG4gICAgbm9yYWRJRDogWXVwLnN0cmluZygpXG4gICAgICAucmVxdWlyZWQoYFJlcXVpcmVkYClcbiAgICAgIC5tYXRjaGVzKC9eWzAtOV0rJC9nLCBcIk11c3QgYmUgYSBwb3NpdGl2ZSBudW1iZXJcIilcbiAgICAgIC5ub3RPbmVPZihcbiAgICAgICAgaXNVbmlxdWVMaXN0KGluaXRWYWx1ZXMsIHNhdHMsIG51bGwsIFwibm9yYWRJRFwiKSxcbiAgICAgICAgKG9iaikgPT5cbiAgICAgICAgICBgQSBzYXRlbGxpdGUgd2l0aCBub3JhZElEIG9mICR7b2JqLnZhbHVlfSBhbHJlYWR5IGV4aXN0cyBpbiBvdXIgcmVjb3Jkcy5gXG4gICAgICApLFxuICAgIGFkbWluQ2hlY2s6IFl1cC5ib29sZWFuKCkucmVxdWlyZWQoKSxcbiAgICBtb2RpZmllZE9uOiBZdXAuZGF0ZSgpLnJlcXVpcmVkKCksXG4gICAgbW9kaWZpZWRCeTogWXVwLnN0cmluZygpLnJlcXVpcmVkKCksXG4gICAgY3JlYXRlZE9uOiBZdXAuZGF0ZSgpLnJlcXVpcmVkKCksXG4gICAgY3JlYXRlZEJ5OiBZdXAuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgfTtcbn07XG5cbmV4cG9ydCBjb25zdCBzYXRlbGxpdGVWYWxpZGF0b3JTaGFwZXIgPSAodmFsdWVzLCBpbml0VmFsdWVzKSA9PiB7XG4gIGNvbnN0IHNhdHMgPSBTYXRlbGxpdGVDb2xsZWN0aW9uLmZpbmQoKS5mZXRjaCgpO1xuICBjb25zdCBzY2hlbWFzID0gU2NoZW1hQ29sbGVjdGlvbi5maW5kKCkuZmV0Y2goKTtcbiAgbGV0IHl1cFNoYXBlID0gaW5pdGlhbFl1cFNoYXBlR2VuZXJhdG9yKGluaXRWYWx1ZXMsIHNhdHMsIGlzVW5pcXVlTGlzdCk7IC8vIGluc3RhbnRpYXRpb24gb2YgYmFzZSB5dXBTaGFwZVxuICBjb25zdCBjbGVhblNjaGVtYSA9IHNjaGVtYUNsZWFuZXIoc2NoZW1hcywgdmFsdWVzKTsgLy8gZ2VuZXJhdGVzIGEgY2xlYW4gc2NoZW1hIG9iamVjdCBmb3IgZWFzaWVyIG1hbmlwdWxhdGlvblxuXG4gIFl1cC5hZGRNZXRob2QoWXVwLm1peGVkLCBcImNoZWNrRWFjaEVudHJ5XCIsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgbGV0IGVyck9iaiA9IHt9OyAvLyB3b3JrYXJvdW5kIG9iamVjdCB0byBwdXNoIGVycm9ycyBpbnRvIEZvcm1pa1xuICAgIC8vIHRlc3QgZWFjaCBlbnRyeSBpbiB0aGUgYXJyYXk6IFl1cC5vYmplY3QoKS5zaGFwZSh7ZmllbGQubmFtZTogWXVwLihmaWVsZC50eXBlKVswXS50b1VwcGVyQ2FzZSgpICsgKGZpZWxkLnR5cGUpLnN1YnN0cigxKS5yZXF1aXJlZChmaWVsZC5yZXF1aXJlZCkubWluKGZpZWxkLm1pbikubWF4KGZpZWxkLm1heCkub25lT2YoKGZpZWxkLmFsbG93ZWRWYWx1ZXMpKX0pXG4gICAgcmV0dXJuIHRoaXMudGVzdChcImNoZWNrRWFjaEVudHJ5XCIsIG1lc3NhZ2UsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgY29uc3QgeyBwYXRoLCBjcmVhdGVFcnJvciB9ID0gdGhpczsgLy8gcGF0aCBpcyB0aGUgc2NoZW1hJ3MgbmFtZSwgYW5kIGNyZWF0ZUVycm9yIGdlbmVyYXRlcyBlcnJvcnMgdG8gYmUgaGFuZGxlZCBieSBGb3JtaWtcbiAgICAgIGxldCBlbnRyeUNvdW50ID0gMDsgLy8gXCJlbnRyeUNvdW50XCIgYW5kIFwiZmllbGRDb3VudFwiIGFyZSB1c2VkIHRvIHByb3ZpZGUgdGhlIGxvY2F0aW9uIG9mIHRoZSBlcnJvciB0byB0aGUgU2F0ZWxsaXRlTW9kYWwgZm9yIHJlbmRlcmluZyB1bmRlcm5lYXRoIHRoZSBjb3JyZWN0IGVudHJ5IGluIFNhdGVsbGl0ZVNjaGVtYUVudHJ5XG4gICAgICB2YWx1ZT8uZm9yRWFjaCgoZW50cnkpID0+IHtcbiAgICAgICAgLy8gXCJlbnRyeVwiIGlzIGNvbXBvc2VkIG9mIG11bHRpcGxlIFwiZmllbGRzXCIsIGFuZCBpcyBwYXJ0IG9mIHRoZSBzdWJtaXR0ZWQgYXJyYXksIGFrYSBcInZhbHVlXCJcbiAgICAgICAgbGV0IGZpZWxkT2JqID0ge307XG4gICAgICAgIGxldCBmaWVsZENvdW50ID0gMDtcbiAgICAgICAgY29uc3Qgc2NoZW1hID0gY2xlYW5TY2hlbWFbcGF0aF07XG4gICAgICAgIGZvciAobGV0IHNjaGVtYUZpZWxkIGluIHNjaGVtYSkge1xuICAgICAgICAgIC8vIFwic2NoZW1hXCIgYXJlIHRoZSBzY2hlbWFzIHNlZW4gb24gdGhlIFNjaGVtYXNUYWJsZSwgYW5kIFwic2NoZW1hRmllbGRcIiBhcmUgdGhlIGZpZWxkcyB0byBiZSBmaWxsZWQtaW4gaW4gZWFjaCBzY2hlbWFcbiAgICAgICAgICBjb25zdCBmaWVsZCA9IHNjaGVtYVtzY2hlbWFGaWVsZF07XG4gICAgICAgICAgLy8gdGhlIGZvbGxvd2luZyBtdXN0IGJlIG1vZGlmaWVkIHdoZW5ldmVyIHdlIGRlY2lkZSB0byBjcmVhdGU6XG4gICAgICAgICAgLy8gYSBuZXcgXCJ0eXBlXCIgKGUuZy4gbnVtYmVyLCBzdHJpbmcsIGRhdGUpIG9yXG4gICAgICAgICAgLy8gYSBuZXcgXCJ0eXBlIGNvbnN0cmFpbnRcIiAoZS5nLiBtYXggbnVtYmVyLCBtaW4gbnVtYmVyLCBtYXggc3RyaW5nIGxlbmd0aClcbiAgICAgICAgICBsZXQgdGVtcEZpZWxkU2NoZW1hID1cbiAgICAgICAgICAgIGZpZWxkLnR5cGUgIT09IFwidXJsXCIgPyBZdXBbZmllbGQudHlwZV0oKSA6IFl1cFtcInN0cmluZ1wiXSgpO1xuICAgICAgICAgIGNvbnN0IGJhc2VGaWVsZFR5cGUgPSB0ZW1wRmllbGRTY2hlbWE7XG4gICAgICAgICAgLy8gc3RvcmVzIHRoZSB5dXAgZnJhZ21lbnRzIG5lZWRlZCBmb3IgZWFjaCBjb25zdHJhaW50XG4gICAgICAgICAgY29uc3QgZmllbGRTY2hlbWFNYXRyaXggPSB7XG4gICAgICAgICAgICByZXF1aXJlZDogZmllbGQucmVxdWlyZWRcbiAgICAgICAgICAgICAgPyBiYXNlRmllbGRUeXBlLnJlcXVpcmVkKFxuICAgICAgICAgICAgICAgICAgYCR7cGF0aH0tJHtlbnRyeUNvdW50fS0ke2ZpZWxkQ291bnR9XyR7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLnR5cGUgPT09IFwidXJsXCJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiVVJMXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IGZpZWxkLnR5cGVbMF0udG9VcHBlckNhc2UoKSArXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZC50eXBlLnN1YnN0cigxKSArXG4gICAgICAgICAgICAgICAgICAgICAgICBcIiBJbnB1dFwiXG4gICAgICAgICAgICAgICAgICB9IFJlcXVpcmVkYFxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgICAgICAgIHVybDpcbiAgICAgICAgICAgICAgZmllbGQudHlwZSA9PT0gXCJ1cmxcIlxuICAgICAgICAgICAgICAgID8gYmFzZUZpZWxkVHlwZS51cmwoXG4gICAgICAgICAgICAgICAgICAgIGAke3BhdGh9LSR7ZW50cnlDb3VudH0tJHtmaWVsZENvdW50fV9NdXN0IGJlIGEgdmFsaWQgVVJMIChlLmcuIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL01haW5fUGFnZSkuYFxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBhbGxvd2VkVmFsdWVzOlxuICAgICAgICAgICAgICBmaWVsZC5hbGxvd2VkVmFsdWVzPy5sZW5ndGggPiAwXG4gICAgICAgICAgICAgICAgPyBiYXNlRmllbGRUeXBlLm9uZU9mKFxuICAgICAgICAgICAgICAgICAgICBbLi4uZmllbGQuYWxsb3dlZFZhbHVlc10sXG4gICAgICAgICAgICAgICAgICAgIGAke3BhdGh9LSR7ZW50cnlDb3VudH0tJHtmaWVsZENvdW50fV9NdXN0IGJlIG9uZSBvZiB0aGUgZm9sbG93aW5nOiAke2ZpZWxkLmFsbG93ZWRWYWx1ZXMuam9pbihcbiAgICAgICAgICAgICAgICAgICAgICBcIiwgXCJcbiAgICAgICAgICAgICAgICAgICAgKX1gXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgICAgICAgIGlzVW5pcXVlOiBmaWVsZC5pc1VuaXF1ZVxuICAgICAgICAgICAgICA/IGJhc2VGaWVsZFR5cGUubm90T25lT2YoXG4gICAgICAgICAgICAgICAgICBpc1VuaXF1ZUxpc3QoaW5pdFZhbHVlcywgc2F0cywgcGF0aCwgc2NoZW1hRmllbGQpLFxuICAgICAgICAgICAgICAgICAgYCR7cGF0aH0tJHtlbnRyeUNvdW50fS0ke2ZpZWxkQ291bnR9X0Egc2F0ZWxsaXRlIHdpdGggJHtzY2hlbWFGaWVsZH0gb2YgJHt2YWx1ZVtlbnRyeUNvdW50XVtzY2hlbWFGaWVsZF19IGFscmVhZHkgZXhpc3RzLmBcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBtaW46XG4gICAgICAgICAgICAgIGZpZWxkLnR5cGUgPT09IFwibnVtYmVyXCIgJiYgZmllbGQubWF4XG4gICAgICAgICAgICAgICAgPyBiYXNlRmllbGRUeXBlLm1pbihcbiAgICAgICAgICAgICAgICAgICAgZmllbGQubWluLFxuICAgICAgICAgICAgICAgICAgICBgJHtwYXRofS0ke2VudHJ5Q291bnR9LSR7ZmllbGRDb3VudH1fTXVzdCBiZSBubyBsZXNzIHRoYW4gJHtmaWVsZC5taW59YFxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBtYXg6XG4gICAgICAgICAgICAgIGZpZWxkLnR5cGUgPT09IFwibnVtYmVyXCIgJiYgZmllbGQubWF4XG4gICAgICAgICAgICAgICAgPyBiYXNlRmllbGRUeXBlLm1heChcbiAgICAgICAgICAgICAgICAgICAgZmllbGQubWF4LFxuICAgICAgICAgICAgICAgICAgICBgJHtwYXRofS0ke2VudHJ5Q291bnR9LSR7ZmllbGRDb3VudH1fTXVzdCBiZSBubyBncmVhdGVyIHRoYW4gJHtmaWVsZC5tYXh9YFxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBzdHJpbmdNYXg6XG4gICAgICAgICAgICAgIGZpZWxkLnR5cGUgPT09IFwic3RyaW5nXCIgJiYgZmllbGQuc3RyaW5nTWF4XG4gICAgICAgICAgICAgICAgPyBiYXNlRmllbGRUeXBlLm1heChcbiAgICAgICAgICAgICAgICAgICAgZmllbGQuc3RyaW5nTWF4LFxuICAgICAgICAgICAgICAgICAgICBgJHtwYXRofS0ke2VudHJ5Q291bnR9LSR7ZmllbGRDb3VudH1fTXVzdCBub3QgZXhjZWVkICR7ZmllbGQuc3RyaW5nTWF4fSBjaGFyYWN0ZXJzLmBcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICA6IGZhbHNlLFxuICAgICAgICAgIH07XG4gICAgICAgICAgLy8gbG9vcCBvdmVyIHRoZSBzY2hlbWEgYW5kIGNvbmNhdGVuYXRlIGFsbCB2YWxpZCBjb25zdHJhaW50cyB0byBmaWVsZCdzIHl1cCBvYmplY3RcbiAgICAgICAgICBmb3IgKGxldCBjaGVjayBpbiBmaWVsZFNjaGVtYU1hdHJpeCkge1xuICAgICAgICAgICAgaWYgKGZpZWxkU2NoZW1hTWF0cml4W2NoZWNrXSlcbiAgICAgICAgICAgICAgdGVtcEZpZWxkU2NoZW1hID0gdGVtcEZpZWxkU2NoZW1hLmNvbmNhdChcbiAgICAgICAgICAgICAgICBmaWVsZFNjaGVtYU1hdHJpeFtjaGVja11cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZmllbGRPYmpbc2NoZW1hRmllbGRdID0gdGVtcEZpZWxkU2NoZW1hO1xuICAgICAgICAgIGZpZWxkQ291bnQrKztcbiAgICAgICAgfVxuICAgICAgICBsZXQgZmllbGRWYWxpZGF0b3IgPSBZdXAub2JqZWN0KCkuc2hhcGUoZmllbGRPYmopO1xuXG4gICAgICAgIC8vIFl1cC5hZGRNZXRob2QncyB0ZXN0IG11c3QgcmV0dXJuIGEgYm9vbGVhbiwgYW5kL29yIGdlbmVyYXRlIGVycm9ycyBhcyBuZWNlc3NhcnksIGluIG9yZGVyIHRvIGNvbXBsZXRlIHRoZSB2YWxpZGF0aW9uXG4gICAgICAgIGZpZWxkVmFsaWRhdG9yXG4gICAgICAgICAgLnZhbGlkYXRlKGVudHJ5LCB7IGFib3J0RWFybHk6IHRydWUgfSlcbiAgICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICBlcnJPYmogPSB7fTsgLy8gY2xlYXIgYWxsIGVycm9ycyBvbiBzdWNjZXNzZnVsIHZhbGlkYXRpb25cbiAgICAgICAgICB9KVxuICAgICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICBlcnJPYmogPSB7fTsgLy8gY2xlYXIgb2xkIGVycm9ycyBhbmQgcmVwb3B1bGF0ZSBlcnJvciBvYmplY3QgdXBvbiBmYWlsZWQgdmFsaWRhdGlvblxuICAgICAgICAgICAgZXJyLnBhdGggPT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICA/IChlcnIubWVzc2FnZSA9IFwiZXJyIGlzIG5vdCBkZWZpbmVkXCIpXG4gICAgICAgICAgICAgIDogbnVsbDtcbiAgICAgICAgICAgIHJldHVybiBlcnIubWVzc2FnZSAhPT0gXCJlcnIgaXMgbm90IGRlZmluZWRcIlxuICAgICAgICAgICAgICA/IChlcnJPYmpbZXJyW1wicGF0aFwiXV0gPSBlcnIubWVzc2FnZSlcbiAgICAgICAgICAgICAgOiBudWxsO1xuICAgICAgICAgIH0pO1xuICAgICAgICBlbnRyeUNvdW50Kys7XG4gICAgICB9KTtcblxuICAgICAgLy8gY2hlY2sgZXJyb3Igb2JqZWN0IHRvIGRldGVybWluZSB0aGUgc3VjY2VzcyBvZiB0aGUgdmFsaWRhdGlvbiBhbmQgdGhlIGFtb3VudCBvZiBlcnJvcnMgdGhhdCBuZWVkIHRvIGJlIGdlbmVyYXRlZCBmb3IgRm9ybWlrIHRvIGhhbmRsZVxuICAgICAgaWYgKEpTT04uc3RyaW5naWZ5KGVyck9iaikgPT09IFwie31cIikge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZvciAobGV0IGVyclBhdGggaW4gZXJyT2JqKSB7XG4gICAgICAgICAgbGV0IGVyck1lc3NhZ2UgPSBlcnJPYmpbZXJyUGF0aF07XG4gICAgICAgICAgbGV0IGNsZWFuTWVzc2FnZSA9IGVyck1lc3NhZ2Uuc3Vic3RyKGVyck1lc3NhZ2UuaW5kZXhPZihcIl9cIikgKyAxKTtcbiAgICAgICAgICBsZXQgY2xlYW5QYXRoID0gZXJyTWVzc2FnZS5zdWJzdHIoMCwgZXJyTWVzc2FnZS5pbmRleE9mKFwiX1wiKSk7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZUVycm9yKHtcbiAgICAgICAgICAgIHBhdGg6IGAke2NsZWFuUGF0aH1gLFxuICAgICAgICAgICAgbWVzc2FnZTogYCR7Y2xlYW5NZXNzYWdlfWAsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG4gIC8vIGJ1aWxkaW5nIHRoZSBmaW5hbCB5dXAgc2NoZW1hIG9iamVjdCwgY2FsbGluZyBjaGVja0VhY2hFbnRyeSBmb3IgZWFjaCBlbnRyeSBpbiB0aGUgc2F0ZWxsaXRlXG4gIGlmIChKU09OLnN0cmluZ2lmeShjbGVhblNjaGVtYSkgIT09IFwie31cIikge1xuICAgIGZvciAobGV0IHNjaGVtYSBpbiBjbGVhblNjaGVtYSkge1xuICAgICAgeXVwU2hhcGVbc2NoZW1hXSA9IFl1cC5hcnJheSgpLmNoZWNrRWFjaEVudHJ5KCk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIFl1cC5vYmplY3QoKS5zaGFwZSh5dXBTaGFwZSk7XG59O1xuIiwiLyoqIFxuICogUExFQVNFIEVOU1VSRSBUSEFUIEFOWSBDSEFOR0VTIE1BREUgSEVSRSBBUkUgUkVGTEVDVEVEIElOIENMSUVOVC1TSURFIFVUSUxTXG4qKi9cblxuaW1wb3J0ICogYXMgWXVwIGZyb20gXCJ5dXBcIjtcblxuY29uc3QgdW5pcXVlTmFtZXMgPSAoaW5pdFZhbHVlcywgc2NoZW1hcykgPT4ge1xuICByZXR1cm4gc2NoZW1hcy5tYXAoKHNjaGVtYSkgPT4ge1xuICAgIGlmIChpbml0VmFsdWVzLm5hbWUgIT09IHNjaGVtYS5uYW1lKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLm5hbWU7XG4gICAgfVxuICB9KTtcbn07XG5cbmV4cG9ydCBjb25zdCBzY2hlbWFWYWxpZGF0b3JTaGFwZXIgPSAoaW5pdFZhbHVlcywgc2NoZW1hcykgPT4ge1xuICByZXR1cm4gWXVwLm9iamVjdCgpLnNoYXBlKHtcbiAgICBfaWQ6IFl1cC5zdHJpbmcoKSxcbiAgICBuYW1lOiBZdXAuc3RyaW5nKClcbiAgICAgIC5ub3RPbmVPZihcbiAgICAgICAgdW5pcXVlTmFtZXMoaW5pdFZhbHVlcywgc2NoZW1hcyksXG4gICAgICAgIChvYmopID0+IGBUaGUgc2NoZW1hIG5hbWUsICR7b2JqLnZhbHVlfSwgYWxyZWFkeSBleGlzdHMgYFxuICAgICAgKVxuICAgICAgLm1hdGNoZXMoXG4gICAgICAgIC9eW2EtekEtWjAtOV0qJC9nLFxuICAgICAgICBcIlNjaGVtYSBuYW1lIG11c3QgYmUgc3BhY2VsZXNzLCBjYW1lbENhc2UsIGFuZCBvbmx5IGNvbnRhaW4gbGV0dGVycyBhbmQgbnVtYmVyc1wiXG4gICAgICApXG4gICAgICAucmVxdWlyZWQoXCJSZXF1aXJlZFwiKVxuICAgICAgLm1heCg1MCwgXCJNdXN0IG5vdCBleGNlZWQgNTAgY2hhcmFjdGVyc1wiKSxcbiAgICBkZXNjcmlwdGlvbjogWXVwLnN0cmluZygpXG4gICAgICAucmVxdWlyZWQoXCJSZXF1aXJlZFwiKVxuICAgICAgLm1heCg1MDAsIFwiTXVzdCBub3QgZXhjZWVkIDUwMCBjaGFyYWN0ZXJzXCIpLFxuICAgIGZpZWxkczogWXVwLmFycmF5KCkub2YoXG4gICAgICBZdXAub2JqZWN0KClcbiAgICAgICAgLnNoYXBlKHtcbiAgICAgICAgICBuYW1lOiBZdXAuc3RyaW5nKClcbiAgICAgICAgICAgIC5yZXF1aXJlZChcIlJlcXVpcmVkXCIpXG4gICAgICAgICAgICAubWF4KDUwLCBcIk11c3Qgbm90IGV4Y2VlZCA1MCBjaGFyYWN0ZXJzXCIpLFxuICAgICAgICAgIHR5cGU6IFl1cC5taXhlZCgpXG4gICAgICAgICAgICAub25lT2YoXG4gICAgICAgICAgICAgIFtcInN0cmluZ1wiLCBcIm51bWJlclwiLCBcImRhdGVcIiwgXCJ1cmxcIiwgXCJjaGFuZ2Vsb2dcIl0sXG4gICAgICAgICAgICAgIFwiSW52YWxpZCBpbnB1dCBwcm92aWRlZFwiXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAucmVxdWlyZWQoXCJSZXF1aXJlZFwiKSxcbiAgICAgICAgICBhbGxvd2VkVmFsdWVzOiBZdXAuYXJyYXkoKVxuICAgICAgICAgICAgLmVuc3VyZSgpXG4gICAgICAgICAgICAubWF4KDEwMCwgXCJNdXN0IG5vdCBleGNlZWQgMTAwIGVsZW1lbnRzXCIpLFxuICAgICAgICAgIG1pbjogWXVwLm51bWJlcigpLm51bGxhYmxlKCkubm90UmVxdWlyZWQoKSxcbiAgICAgICAgICBtYXg6IFl1cC5udW1iZXIoKVxuICAgICAgICAgICAgLm51bGxhYmxlKClcbiAgICAgICAgICAgIC53aGVuKFtcIm1pblwiXSwgKG1pbiwgc2NoZW1hKSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBzY2hlbWEubWluKG1pbik7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICByZXF1aXJlZDogWXVwLmJvb2xlYW4oKSxcbiAgICAgICAgICBpc1VuaXF1ZTogWXVwLmJvb2xlYW4oKSxcbiAgICAgICAgICBzdHJpbmdNYXg6IFl1cC5udW1iZXIoKS5tYXgoXG4gICAgICAgICAgICAyMDAwMCxcbiAgICAgICAgICAgIFwiTXVzdCBub3QgZXhjZWVkIDIwLDAwMCBjaGFyYWN0ZXJzXCJcbiAgICAgICAgICApLFxuICAgICAgICB9KVxuICAgICAgICAubm90UmVxdWlyZWQoKVxuICAgICksXG4gICAgYWRtaW5DaGVjazogWXVwLmJvb2xlYW4oKS5yZXF1aXJlZCgpLFxuICAgIG1vZGlmaWVkT246IFl1cC5kYXRlKCkucmVxdWlyZWQoKSxcbiAgICBtb2RpZmllZEJ5OiBZdXAuc3RyaW5nKCkucmVxdWlyZWQoKSxcbiAgICBjcmVhdGVkT246IFl1cC5kYXRlKCkucmVxdWlyZWQoKSxcbiAgICBjcmVhdGVkQnk6IFl1cC5zdHJpbmcoKS5yZXF1aXJlZCgpLFxuICB9KTtcbn07XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xuaW1wb3J0IHsgV2ViQXBwIH0gZnJvbSBcIm1ldGVvci93ZWJhcHBcIjtcbmltcG9ydCB7IEF1dG91cGRhdGUgfSBmcm9tIFwibWV0ZW9yL2F1dG91cGRhdGVcIjtcbmltcG9ydCBjcnlwdG8gZnJvbSBcImNyeXB0b1wiO1xuaW1wb3J0IGhlbG1ldCBmcm9tIFwiaGVsbWV0XCI7XG5cbmV4cG9ydCBjb25zdCBoZWxtZXRPcHRpb25zID0gKCkgPT4ge1xuICBjb25zdCBzZWxmID0gXCInc2VsZidcIjtcbiAgY29uc3QgZGF0YSA9IFwiZGF0YTpcIjtcbiAgY29uc3QgdW5zYWZlRXZhbCA9IFwiJ3Vuc2FmZS1ldmFsJ1wiO1xuICBjb25zdCB1bnNhZmVJbmxpbmUgPSBcIid1bnNhZmUtaW5saW5lJ1wiO1xuICBjb25zdCBhbGxvd2VkT3JpZ2lucyA9IE1ldGVvci5zZXR0aW5ncy5hbGxvd2VkT3JpZ2lucztcblxuICBjb25zdCB1cmwgPSBNZXRlb3IuYWJzb2x1dGVVcmwoKTtcbiAgY29uc3QgZG9tYWluID0gdXJsLnJlcGxhY2UoL2h0dHAocykqOlxcL1xcLy8sIFwiXCIpLnJlcGxhY2UoL1xcLyQvLCBcIlwiKTtcbiAgY29uc3QgcyA9IHVybC5tYXRjaCgvKD8hPWh0dHApcyg/PTpcXC9cXC8pLykgPyBcInNcIiA6IFwiXCI7XG4gIGNvbnN0IHVzZXNIdHRwcyA9IHMubGVuZ3RoID4gMDtcbiAgY29uc3QgY29ubmVjdFNyYyA9IFtzZWxmLCBgaHR0cCR7c306Ly8ke2RvbWFpbn1gLCBgd3Mke3N9Oi8vJHtkb21haW59YF07XG5cbiAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICBjb250ZW50U2VjdXJpdHlQb2xpY3k6IHtcbiAgICAgIGJsb2NrQWxsTWl4ZWRDb250ZW50OiB0cnVlLFxuICAgICAgZGlyZWN0aXZlczoge1xuICAgICAgICBkZWZhdWx0U3JjOiBbc2VsZiwgdW5zYWZlSW5saW5lXSxcbiAgICAgICAgc2NyaXB0U3JjOiBbdW5zYWZlSW5saW5lXSxcbiAgICAgICAgY2hpbGRTcmM6IFtzZWxmLCB1bnNhZmVJbmxpbmVdLFxuICAgICAgICBjb25uZWN0U3JjOiBjb25uZWN0U3JjLmNvbmNhdChhbGxvd2VkT3JpZ2lucyksXG4gICAgICAgIGZvbnRTcmM6IFtzZWxmLCBkYXRhLCB1bnNhZmVJbmxpbmVdLFxuICAgICAgICBmb3JtQWN0aW9uOiBbc2VsZl0sXG4gICAgICAgIGZyYW1lQW5jZXN0b3JzOiBbc2VsZl0sXG4gICAgICAgIGZyYW1lU3JjOiBbXCIqXCJdLFxuICAgICAgICBpbWdTcmM6IFtcIipcIl0sXG4gICAgICAgIG1hbmlmZXN0U3JjOiBbc2VsZiwgdW5zYWZlSW5saW5lXSxcbiAgICAgICAgbWVkaWFTcmM6IFtzZWxmLCB1bnNhZmVJbmxpbmVdLFxuICAgICAgICBvYmplY3RTcmM6IFtzZWxmLCB1bnNhZmVJbmxpbmVdLFxuICAgICAgICBzYW5kYm94OiBbXG4gICAgICAgICAgXCJhbGxvdy1mb3Jtc1wiLFxuICAgICAgICAgIFwiYWxsb3ctbW9kYWxzXCIsXG4gICAgICAgICAgXCJhbGxvdy1zYW1lLW9yaWdpblwiLFxuICAgICAgICAgIFwiYWxsb3ctc2NyaXB0c1wiLFxuICAgICAgICAgIFwiYWxsb3ctcG9wdXBzXCIsXG4gICAgICAgIF0sXG4gICAgICAgIHN0eWxlU3JjOiBbc2VsZiwgdW5zYWZlSW5saW5lXSxcbiAgICAgICAgd29ya2VyU3JjOiBbc2VsZiwgXCJibG9iOlwiXSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBzdHJpY3RUcmFuc3BvcnRTZWN1cml0eToge1xuICAgICAgbWF4QWdlOiAxNTU1MjAwMCxcbiAgICAgIGluY2x1ZGVTdWJEb21haW5zOiB0cnVlLFxuICAgICAgcHJlbG9hZDogZmFsc2UsXG4gICAgfSxcbiAgICByZWZlcnJlclBvbGljeToge1xuICAgICAgcG9saWN5OiBcIm5vLXJlZmVycmVyXCIsXG4gICAgfSxcbiAgICBleHBlY3RDdDoge1xuICAgICAgZW5mb3JjZTogdHJ1ZSxcbiAgICAgIG1heEFnZTogNjA0ODAwLFxuICAgIH0sXG4gICAgZnJhbWVndWFyZDoge1xuICAgICAgYWN0aW9uOiBcInNhbWVvcmlnaW5cIixcbiAgICB9LFxuICAgIGRuc1ByZWZldGNoQ29udHJvbDoge1xuICAgICAgYWxsb3c6IGZhbHNlLFxuICAgIH0sXG4gICAgcGVybWl0dGVkQ3Jvc3NEb21haW5Qb2xpY2llczoge1xuICAgICAgcGVybWl0dGVkUG9saWNpZXM6IFwibm9uZVwiLFxuICAgIH0sXG4gIH07XG5cbiAgaWYgKCF1c2VzSHR0cHMgJiYgTWV0ZW9yLmlzRGV2ZWxvcG1lbnQpIHtcbiAgICBkZWxldGUgb3B0aW9ucy5jb250ZW50U2VjdXJpdHlQb2xpY3kuZGlyZWN0aXZlcy5ibG9ja0FsbE1peGVkQ29udGVudDtcbiAgICBvcHRpb25zLmNvbnRlbnRTZWN1cml0eVBvbGljeS5kaXJlY3RpdmVzLnNjcmlwdFNyYyA9IFtcbiAgICAgIHNlbGYsXG4gICAgICB1bnNhZmVFdmFsLFxuICAgICAgdW5zYWZlSW5saW5lLFxuICAgIF07XG4gIH1cblxuICByZXR1cm4gb3B0aW9ucztcbn07XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xuaW1wb3J0IHsgU2F0ZWxsaXRlQ29sbGVjdGlvbiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvc2F0ZWxsaXRlc1wiO1xuaW1wb3J0IHsgU2NoZW1hQ29sbGVjdGlvbiB9IGZyb20gXCIvaW1wb3J0cy9hcGkvc2NoZW1hc1wiO1xuXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShcIi9hcGkvc2F0ZWxsaXRlc1wiLCBhc3luYyAocmVxLCByZXMsIG5leHQpID0+IHtcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0U2F0cygpIHtcbiAgICByZXMuc2V0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICBjb25zdCBzYXRzID0gYXdhaXQgU2F0ZWxsaXRlQ29sbGVjdGlvbi5maW5kKHt9KTtcblxuICAgIGlmIChyZXEucXVlcnkubGltaXQpIHtcbiAgICAgIGNvbnN0IGxpbWl0ZXIgPSBwYXJzZUludChyZXEucXVlcnkubGltaXQpO1xuICAgICAgY29uc3QgcGFnZSA9IHBhcnNlSW50KHJlcS5xdWVyeS5wYWdlKTtcbiAgICAgIGNvbnN0IHNraXBwZXIgPSBsaW1pdGVyICogcGFnZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFNhdGVsbGl0ZUNvbGxlY3Rpb24uZmluZChcbiAgICAgICAgICB7fSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBsaW1pdDogbGltaXRlcixcbiAgICAgICAgICAgIHNraXA6IHNraXBwZXIsXG4gICAgICAgICAgfVxuICAgICAgICApLmZldGNoKCk7XG4gICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwKTtcbiAgICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KHJlc3VsdCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVycm9yID0ge1xuICAgICAgICAgICAgZXJyb3I6XG4gICAgICAgICAgICAgIFwiQ291bGQgbm90IGZldGNoIHNhdCBiYXNlZCBvbiBub3JhZElEIC0gbm9uLWV4aXN0ZW50IG5vcmFkSURcIixcbiAgICAgICAgICB9O1xuICAgICAgICAgIHJlcy53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KGVycm9yKSk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBlcnJvciA9IHsgZXJyb3I6IFwiQ291bGQgbm90IGZldGNoIGxpbWl0XCIgfTtcbiAgICAgICAgcmVzLndyaXRlSGVhZCg1MDApO1xuICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KGVycm9yKSk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChyZXEucXVlcnkubm9yYWRJRCB8fCByZXEucXVlcnkuaWQgfHwgcmVxLnF1ZXJ5Lm5vcmFkaWQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IG5vcmFkSUQgPSByZXEucXVlcnkubm9yYWRJRCB8fCByZXEucXVlcnkuaWQgfHwgcmVxLnF1ZXJ5Lm5vcmFkaWQ7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFNhdGVsbGl0ZUNvbGxlY3Rpb24uZmluZCh7XG4gICAgICAgICAgbm9yYWRJRDogeyAkcmVnZXg6IG5vcmFkSUQgfSxcbiAgICAgICAgfSkuZmV0Y2goKTtcbiAgICAgICAgaWYgKHJlc3VsdC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcmVzLndyaXRlSGVhZCgyMDApO1xuICAgICAgICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkocmVzdWx0KSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZXJyb3IgPSB7XG4gICAgICAgICAgICBlcnJvcjpcbiAgICAgICAgICAgICAgXCJDb3VsZCBub3QgZmV0Y2ggc2F0IGJhc2VkIG9uIG5vcmFkSUQgLSBub24tZXhpc3RlbnQgbm9yYWRJRC5cIixcbiAgICAgICAgICB9O1xuICAgICAgICAgIHJlcy53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KGVycm9yKSk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBlcnJvciA9IHsgZXJyb3I6IFwiQ291bGQgbm90IGZldGNoIGxpc3Qgb2Ygc2F0c1wiIH07XG4gICAgICAgIHJlcy53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgcmVzLmVuZChKU09OLnN0cmluZ2lmeShlcnJvcikpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVxLnF1ZXJ5Lm5hbWUpIHtcbiAgICAgIGxldCByZXN1bHQgPSBudWxsO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gcmVxLnF1ZXJ5Lm5hbWU7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFNhdGVsbGl0ZUNvbGxlY3Rpb24uZmluZCh7XG4gICAgICAgICAgXCJuYW1lcy5uYW1lXCI6IHsgJHJlZ2V4OiBgJHt0YXJnZXR9YCwgJG9wdGlvbnM6IFwiaVwiIH0sXG4gICAgICAgIH0pLmZldGNoKCk7XG4gICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMCAmJiByZXN1bHRbMF0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKCdyZXN1bHQgJywgcmVzdWx0WzBdKVxuICAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwKTtcbiAgICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KHJlc3VsdCkpO1xuICAgICAgICB9XG4gICAgICAgIC8vIHNhdHMuZmV0Y2goKS5mb3JFYWNoKChzYXQpID0+IHtcbiAgICAgICAgLy8gICBsZXQgYm9vbCA9IHNhdC5uYW1lcy5maW5kKChuYW1lKSA9PiB7XG4gICAgICAgIC8vICAgICByZXR1cm4gbmFtZS5uYW1lcyB8fCBuYW1lLm5hbWUgPT09IHRhcmdldCA/IHRydWUgOiBmYWxzZTtcbiAgICAgICAgLy8gICB9KTtcbiAgICAgICAgLy8gICBpZiAoYm9vbCkge1xuICAgICAgICAvLyAgICAgcmVzdWx0ID0gc2F0O1xuICAgICAgICAvLyAgIH1cbiAgICAgICAgLy8gfSk7XG4gICAgICAgIC8vIGlmIChyZXN1bHQpIHtcbiAgICAgICAgLy8gICByZXMud3JpdGVIZWFkKDIwMCk7XG4gICAgICAgIC8vICAgcmVzLmVuZChKU09OLnN0cmluZ2lmeShyZXN1bHQpKTtcbiAgICAgICAgLy8gfSBcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgZXJyb3IgPSB7XG4gICAgICAgICAgICBlcnJvcjogXCJDb3VsZCBub3QgZmV0Y2ggc2F0IGJhc2VkIG9uIG5hbWUgLSBub24tZXhpc3RlbnQgbmFtZS4gQW5kIEkgc2hvdWxkIGtub3cuIEkgaW52ZW50ZWQgc2F0ZWxsaXRlcy5cIixcbiAgICAgICAgICB9O1xuICAgICAgICAgIHJlcy53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KGVycm9yKSk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBlcnJvciA9IHsgZXJyb3I6IFwiQ291bGQgbm90IGZldGNoIGxpc3Qgb2Ygc2F0c1wiIH07XG4gICAgICAgIHJlcy53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgcmVzLmVuZChKU09OLnN0cmluZ2lmeShlcnJvcikpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVxLnF1ZXJ5LnR5cGUpIHtcbiAgICAgIGxldCByZXN1bHQgPSBudWxsO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gcmVxLnF1ZXJ5LnR5cGU7XG4gICAgICAgIHNhdHMuZmV0Y2goKS5mb3JFYWNoKChzYXQpID0+IHtcbiAgICAgICAgICBsZXQgYm9vbCA9IHNhdC50eXBlLmZpbmQoKHR5cGUpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0eXBlLnR5cGUgfHwgdHlwZS50eXBlID09PSB0YXJnZXQgPyB0cnVlIDogZmFsc2U7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKGJvb2wpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IHNhdDtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgcmVzLndyaXRlSGVhZCgyMDApO1xuICAgICAgICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkocmVzdWx0KSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZXJyb3IgPSB7XG4gICAgICAgICAgICBlcnJvcjogXCJDb3VsZCBub3QgZmV0Y2ggc2F0IGJhc2VkIG9uIHR5cGUgLSBub24tZXhpc3RlbnQgdHlwZVwiLFxuICAgICAgICAgIH07XG4gICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDApO1xuICAgICAgICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoZXJyb3IpKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGVycm9yID0geyBlcnJvcjogXCJDb3VsZCBub3QgZmV0Y2ggbGlzdCBvZiBzYXRzXCIgfTtcbiAgICAgICAgcmVzLndyaXRlSGVhZCg1MDApO1xuICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KGVycm9yKSk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChyZXEucXVlcnkub3JiaXQpIHtcbiAgICAgIGxldCByZXN1bHQgPSBudWxsO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gcmVxLnF1ZXJ5Lm9yYml0O1xuICAgICAgICBzYXRzLmZldGNoKCkuZm9yRWFjaCgoc2F0KSA9PiB7XG4gICAgICAgICAgbGV0IGJvb2wgPSBzYXQub3JiaXQuZmluZCgob3JiaXQpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBvcmJpdC5vcmJpdCB8fCBvcmJpdC5vcmJpdCA9PT0gdGFyZ2V0ID8gdHJ1ZSA6IGZhbHNlO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChib29sKSB7XG4gICAgICAgICAgICByZXN1bHQgPSBzYXQ7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwKTtcbiAgICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KHJlc3VsdCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVycm9yID0ge1xuICAgICAgICAgICAgZXJyb3I6IFwiQ291bGQgbm90IGZldGNoIHNhdCBiYXNlZCBvbiBvcmJpdCAtIG5vbi1leGlzdGVudCBvcmJpdFwiLFxuICAgICAgICAgIH07XG4gICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDApO1xuICAgICAgICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoZXJyb3IpKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGVycm9yID0geyBlcnJvcjogXCJDb3VsZCBub3QgZmV0Y2ggbGlzdCBvZiBzYXRzXCIgfTtcbiAgICAgICAgcmVzLndyaXRlSGVhZCg1MDApO1xuICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KGVycm9yKSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJlcy53cml0ZUhlYWQoMjAwKTtcbiAgICAgICAgcmVzLmVuZChKU09OLnN0cmluZ2lmeShzYXRzLmZldGNoKCkpKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBlcnJvciA9IHsgZXJyb3I6IFwiQ291bGQgbm90IGZldGNoIGxpc3Qgb2Ygc2F0c1wiIH07XG4gICAgICAgIHJlcy53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgcmVzLmVuZChKU09OLnN0cmluZ2lmeShlcnJvcikpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBnZXRTYXRzKCk7XG59KTtcblxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoXCIvYXBpL3NjaGVtYXNcIiwgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XG4gIGZ1bmN0aW9uIGdldFNjaGVtYSgpIHtcbiAgICByZXMuc2V0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICB0cnkge1xuICAgICAgc2NoZW1hTmFtZSA9IHJlcS5xdWVyeS5uYW1lO1xuICAgICAgaWYgKHNjaGVtYU5hbWUgJiYgc2NoZW1hTmFtZSAhPT0gXCJcIikge1xuICAgICAgICByZXMud3JpdGVIZWFkKDIwMCk7XG4gICAgICAgIHJlcy5lbmQoXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgICBTY2hlbWFDb2xsZWN0aW9uLmZpbmQoeyBuYW1lOiBgJHtyZXEucXVlcnkubmFtZX1gIH0pLmZldGNoKClcbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXMud3JpdGVIZWFkKDIwMCk7XG4gICAgICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoU2NoZW1hQ29sbGVjdGlvbi5maW5kKCkuZmV0Y2goKSkpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgZXJyb3IgPSB7IGVycm9yOiBcIkNvdWxkIG5vdCBmZXRjaCBzY2hlbWFzXCIgfTtcbiAgICAgIHJlcy53cml0ZUhlYWQoNTAwKTtcbiAgICAgIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoZXJyb3IpKTtcbiAgICB9XG4gIH1cbiAgZ2V0U2NoZW1hKCk7XG59KTtcblxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoXCIvYXBpL1wiLCAocmVxLCByZXMsIG5leHQpID0+IHtcbiAgcmVzLnNldEhlYWRlcihcIkNvbnRlbnQtVHlwZVwiLCBcImFwcGxpY2F0aW9uL2pzb25cIik7XG4gIHJlcy53cml0ZUhlYWQoMjAwKTtcbiAgcmVzLmVuZChcbiAgICBKU09OLnN0cmluZ2lmeShcbiAgICAgIFwiV2VsY29tZSB0byB0aGUgUFJPQkUgQVBJISBGb3IgZG9jdW1lbnRhdGlvbiwgcGxlYXNlIHZpc2l0IHRoZSBSRUFETUUgYXQgaHR0cHM6Ly9naXRodWIuY29tL2p1c3RpbnRoZWxhdy9QUk9CRS5cIlxuICAgIClcbiAgKTtcbn0pO1xuIiwiLy8gRGVwZW5kZW5jaWVzXG5pbXBvcnQgKiBhcyBZdXAgZnJvbSBcInl1cFwiO1xuaW1wb3J0IGhlbG1ldCBmcm9tIFwiaGVsbWV0XCI7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tIFwibWV0ZW9yL2FsYW5uaW5nOnJvbGVzXCI7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gXCJtZXRlb3IvYWNjb3VudHMtYmFzZVwiO1xuXG4vLyBJbXBvcnRzXG5pbXBvcnQgeyBTY2hlbWFDb2xsZWN0aW9uIH0gZnJvbSBcIi9pbXBvcnRzL2FwaS9zY2hlbWFzXCI7XG5pbXBvcnQgeyBTYXRlbGxpdGVDb2xsZWN0aW9uIH0gZnJvbSBcIi9pbXBvcnRzL2FwaS9zYXRlbGxpdGVzXCI7XG5pbXBvcnQgeyBVc2Vyc0NvbGxlY3Rpb24gfSBmcm9tIFwiL2ltcG9ydHMvYXBpL3VzZXJzXCI7XG5pbXBvcnQgeyBFcnJvcnNDb2xsZWN0aW9uIH0gZnJvbSBcIi9pbXBvcnRzL2FwaS9lcnJvcnNcIjtcbmltcG9ydCB7IGhlbG1ldE9wdGlvbnMgfSBmcm9tIFwiLi9oZWxtZXRcIjtcbmltcG9ydCB7IHNjaGVtYVZhbGlkYXRvclNoYXBlciB9IGZyb20gXCIuL3ZhbGlkYXRvcnMvc2NoZW1hRGF0YUZ1bmNzXCI7XG5pbXBvcnQgeyBzYXRlbGxpdGVWYWxpZGF0b3JTaGFwZXIgfSBmcm9tIFwiLi92YWxpZGF0b3JzL3NhdGVsbGl0ZURhdGFGdW5jc1wiO1xuaW1wb3J0IFwiLi9yb3V0ZXNcIjtcblxuY29uc3QgZnMgPSBOcG0ucmVxdWlyZShcImZzXCIpO1xuXG5jb25zdCBpc1ZhbGlkRW1haWwgPSAob2xkRW1haWwsIG5ld0VtYWlsKSA9PiB7XG4gIGNvbnN0IG9sZENoZWNrID0gb2xkRW1haWwgPyBvbGRFbWFpbCAhPT0gbmV3RW1haWwgOiB0cnVlO1xuICBjb25zdCBzY2hlbWEgPSBZdXAuc3RyaW5nKCkuZW1haWwoKTtcbiAgcmV0dXJuIHNjaGVtYS5pc1ZhbGlkU3luYyhuZXdFbWFpbCkgJiYgb2xkQ2hlY2sgJiYgbmV3RW1haWwubGVuZ3RoIDwgMTI4O1xufTtcblxuY29uc3QgaXNWYWxpZFVzZXJuYW1lID0gKG9sZFVzZXJuYW1lLCBuZXdVc2VybmFtZSkgPT4ge1xuICBjb25zdCBvbGRDaGVjayA9IG9sZFVzZXJuYW1lID8gb2xkVXNlcm5hbWUgIT09IG5ld1VzZXJuYW1lIDogdHJ1ZTtcbiAgY29uc3QgcmVnZXggPSAvXlthLXpBLVowLTldezQsfSQvZztcbiAgcmV0dXJuIHJlZ2V4LnRlc3QobmV3VXNlcm5hbWUpICYmIG9sZENoZWNrICYmIG5ld1VzZXJuYW1lLmxlbmd0aCA8IDMyO1xufTtcblxuaXNWYWxpZFBhc3N3b3JkID0gKG9sZFBhc3N3b3JkLCBuZXdQYXNzd29yZCkgPT4ge1xuICBjb25zdCBvbGRDaGVjayA9IG9sZFBhc3N3b3JkID8gb2xkUGFzc3dvcmQgIT09IG5ld1Bhc3N3b3JkIDogdHJ1ZTtcbiAgY29uc3QgcmVnZXggPVxuICAgIC9eKD89LipbYS16XSkoPz0uKltBLVpdKSg/PS4qXFxkKSg/PS4qW0AkISUqPyZdKVtBLVphLXpcXGRAJCElKj8mXXs4LH0kL2c7XG4gIHJldHVybiByZWdleC50ZXN0KG5ld1Bhc3N3b3JkKSAmJiBvbGRDaGVjayAmJiBuZXdQYXNzd29yZC5sZW5ndGggPCAxMjg7XG59O1xuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuXG4gIGNvbnNvbGUubG9nKFwiPT09PT09PT09PT09UFJPQkUgc2VydmVyIGlzIHJ1bm5pbmc9PT09PT09PT09PT1cIilcbiAgLy8gU2VlIGhlbG1ldC5qcyBmb3IgQ29udGVudCBTZWN1cml0eSBQb2xpY3kgKENTUCkgb3B0aW9uc1xuICBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShoZWxtZXQoaGVsbWV0T3B0aW9ucygpKSk7XG5cbiAgLy8gQWNjb3VudCBwdWJsaWNhdGlvbnMsIG1ldGhvZHMsIGFuZCBzZWVkc1xuICBSb2xlcy5jcmVhdGVSb2xlKFwiYWRtaW5cIiwgeyB1bmxlc3NFeGlzdHM6IHRydWUgfSk7XG4gIFJvbGVzLmNyZWF0ZVJvbGUoXCJtb2RlcmF0b3JcIiwgeyB1bmxlc3NFeGlzdHM6IHRydWUgfSk7XG4gIFJvbGVzLmNyZWF0ZVJvbGUoXCJkdW1taWVzXCIsIHsgdW5sZXNzRXhpc3RzOiB0cnVlIH0pO1xuXG4gIC8vIEVtYWlsIHZlcmlmaWNhdGlvbmEgZG4gcGFzc3dvcmQgcmVzZXQgZW1haWxzXG4gIEFjY291bnRzLmNvbmZpZyh7XG4gICAgc2VuZFZlcmlmaWNhdGlvbkVtYWlsOiBmYWxzZSxcbiAgfSk7XG4gIEFjY291bnRzLnVybHMucmVzZXRQYXNzd29yZCA9ICh0b2tlbikgPT4ge1xuICAgIHJldHVybiBNZXRlb3IuYWJzb2x1dGVVcmwoYC9yZXNldD90b2tlbj0ke3Rva2VufWApO1xuICB9O1xuICBBY2NvdW50cy51cmxzLnZlcmlmeUVtYWlsID0gKHRva2VuKSA9PiB7XG4gICAgcmV0dXJuIE1ldGVvci5hYnNvbHV0ZVVybChgL3ZlcmlmeT90b2tlbj0ke3Rva2VufWApO1xuICB9O1xuXG4gIC8vIFB1Ymxpc2ggdXNlciBsaXN0IGFuZCB1c2VyIHJvbGVzXG4gIE1ldGVvci5wdWJsaXNoKFwicm9sZXNcIiwgKCkgPT4ge1xuICAgIGlmIChNZXRlb3IudXNlcigpKSB7XG4gICAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgXCJhZG1pblwiKSkge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgIE1ldGVvci51c2Vycy5maW5kKCksXG4gICAgICAgICAgTWV0ZW9yLnJvbGVzLmZpbmQoKSxcbiAgICAgICAgICBNZXRlb3Iucm9sZUFzc2lnbm1lbnQuZmluZCgpLFxuICAgICAgICBdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICBNZXRlb3IudXNlcnMuZmluZCh7IF9pZDogTWV0ZW9yLnVzZXIoKS5faWQgfSksXG4gICAgICAgICAgTWV0ZW9yLnJvbGVzLmZpbmQoeyBfaWQ6IE1ldGVvci51c2VyKCkuX2lkIH0pLFxuICAgICAgICAgIE1ldGVvci5yb2xlQXNzaWdubWVudC5maW5kKHsgX2lkOiBNZXRlb3IudXNlcigpLl9pZCB9KSxcbiAgICAgICAgXTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gQWNjb3VudCBjcmVhdGlvbiBhbmQgbWFuYWdtZW50IG1ldGhvZHNcbiAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgIHVzZXJFeGlzdHM6ICh1c2VybmFtZSkgPT4ge1xuICAgICAgaWYgKEFjY291bnRzLmZpbmRVc2VyQnlVc2VybmFtZSh1c2VybmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIFwiVXNlcm5hbWUgYWxyZWFkeSBleGlzdHMuXCI7XG4gICAgICB9XG4gICAgfSxcblxuICAgIGVtYWlsRXhpc3RzOiAoZW1haWwpID0+IHtcbiAgICAgIGlmIChBY2NvdW50cy5maW5kVXNlckJ5RW1haWwoZW1haWwpKSB7XG4gICAgICAgIHJldHVybiBgVGhhdCBlbWFpbCBpcyBhbHJlYWR5IGluIHVzZWA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfSxcblxuICAgIGFkZFVzZXJUb1JvbGU6ICh1c2VyLCByb2xlKSA9PiB7XG4gICAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgXCJhZG1pblwiKSkge1xuICAgICAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXMoQWNjb3VudHMuZmluZFVzZXJCeVVzZXJuYW1lKHVzZXIudXNlcm5hbWUpLCByb2xlKTtcbiAgICAgICAgaWYgKHJvbGUgPT09IFwiZHVtbWllc1wiKSB7XG4gICAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShcbiAgICAgICAgICAgIHVzZXIuX2lkLFxuICAgICAgICAgICAgeyAkc2V0OiB7IFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zXCI6IFtdIH0gfSxcbiAgICAgICAgICAgIHsgbXVsdGk6IHRydWUgfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgVXNlcnNDb2xsZWN0aW9uLnVwZGF0ZShcbiAgICAgICAgICB7IF9pZDogdXNlci5faWQgfSxcbiAgICAgICAgICBBY2NvdW50cy5maW5kVXNlckJ5VXNlcm5hbWUodXNlci51c2VybmFtZSlcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIGAke3VzZXIuX2lkfSBhZGRlZCB0byAke3JvbGV9YDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICBkZWxldGVBY2NvdW50OiAoaWQpID0+IHtcbiAgICAgIGlmIChcbiAgICAgICAgTWV0ZW9yLnVzZXJJZCgpID09PSBpZCB8fFxuICAgICAgICBSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXJJZCgpLCBcImFkbWluXCIpXG4gICAgICApIHtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnJlbW92ZSh7IF9pZDogaWQgfSk7XG4gICAgICAgIFVzZXJzQ29sbGVjdGlvbi5yZW1vdmUoaWQpO1xuICAgICAgICByZXR1cm4gYFVzZXIgJHtpZH0gaGFzIHN1Y2Nlc3NmdWxseSBiZWVuIGRlbGV0ZWRgO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFwiVW5hdXRob3JpemVkIFs0MDFdXCI7XG4gICAgICB9XG4gICAgfSxcblxuICAgIHVwZGF0ZVVzZXJuYW1lOiAoaWQsIHVzZXIsIG5ld1VzZXJuYW1lKSA9PiB7XG4gICAgICBpZiAoTWV0ZW9yLnVzZXJJZCgpID09PSBpZCkge1xuICAgICAgICBpZiAoaXNWYWxpZFVzZXJuYW1lKHVzZXIsIG5ld1VzZXJuYW1lKSkge1xuICAgICAgICAgIEFjY291bnRzLnNldFVzZXJuYW1lKGlkLCBuZXdVc2VybmFtZSk7XG4gICAgICAgICAgVXNlcnNDb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZDogaWQgfSwgTWV0ZW9yLnVzZXIoKSk7XG4gICAgICAgICAgcmV0dXJuIGBBY2NvdW50IGNoYW5nZXMgc3VjY2Vzc2Z1bGx5IG1hZGVgO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBgVGhlIHByb3ZpZGVkIHVzZXJuYW1lLCAke25ld1VzZXJuYW1lfSwgaXMgaW52YWxpZGA7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICB1cGRhdGVFbWFpbDogKGlkLCBlbWFpbCwgbmV3RW1haWwpID0+IHtcbiAgICAgIGlmIChNZXRlb3IudXNlcklkKCkgPT09IGlkKSB7XG4gICAgICAgIGlmIChpc1ZhbGlkRW1haWwoZW1haWwsIG5ld0VtYWlsKSkge1xuICAgICAgICAgIEFjY291bnRzLnJlbW92ZUVtYWlsKGlkLCBlbWFpbCk7XG4gICAgICAgICAgQWNjb3VudHMuYWRkRW1haWwoaWQsIG5ld0VtYWlsKTtcbiAgICAgICAgICBBY2NvdW50cy5zZW5kVmVyaWZpY2F0aW9uRW1haWwoaWQsIG5ld0VtYWlsKTtcbiAgICAgICAgICBVc2Vyc0NvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiBpZCB9LCBNZXRlb3IudXNlcigpKTtcbiAgICAgICAgICByZXR1cm4gYEFjY291bnQgY2hhbmdlcyBzdWNjZXNzZnVsbHkgbWFkZWA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIGBUaGUgcHJvdmlkZWQgZW1haWwsICR7bmV3RW1haWx9LCBpcyBpbnZhbGlkYDtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFwiVW5hdXRob3JpemVkIFs0MDFdXCI7XG4gICAgICB9XG4gICAgfSxcblxuICAgIGFkZFRvRmF2b3JpdGVzOiAodXNlciwgbm9yYWRJRCkgPT4ge1xuICAgICAgaWYgKE1ldGVvci51c2VySWQpIHtcbiAgICAgICAgbGV0IGZhdm9yaXRlcyA9IE1ldGVvci51c2VyKCkuZmF2b3JpdGVzO1xuICAgICAgICBpZiAoZmF2b3JpdGVzLmluZGV4T2Yobm9yYWRJRCkgPT09IC0xKSB7XG4gICAgICAgICAgZmF2b3JpdGVzLnB1c2gobm9yYWRJRCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZmF2b3JpdGVzLnNwbGljZShmYXZvcml0ZXMuaW5kZXhPZihub3JhZElEKSwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VyLCB7ICRzZXQ6IHsgZmF2b3JpdGVzOiBmYXZvcml0ZXMgfSB9KTtcbiAgICAgICAgcmV0dXJuIE1ldGVvci51c2VyKCkuZmF2b3JpdGVzO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFtcIlVuYXV0aG9yaXplZCBbNDAxXVwiXTtcbiAgICAgIH1cbiAgICB9LFxuXG4gICAgcmVtb3ZlUm9sZTogKHVzZXIsIHJvbGUpID0+IHtcbiAgICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXJJZCgpLCBcImFkbWluXCIpKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgUm9sZXMucmVtb3ZlVXNlcnNGcm9tUm9sZXModXNlci5faWQsIHJvbGUpO1xuICAgICAgICAgIFVzZXJzQ29sbGVjdGlvbi51cGRhdGUoXG4gICAgICAgICAgICB7IF9pZDogdXNlci5faWQgfSxcbiAgICAgICAgICAgIEFjY291bnRzLmZpbmRVc2VyQnlVc2VybmFtZSh1c2VyLnVzZXJuYW1lKVxuICAgICAgICAgICk7XG4gICAgICAgICAgcmV0dXJuIGBVc2VyICR7dXNlci5faWR9IGFkZGVkIHRvIHJvbGUgJHtyb2xlfWA7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHJldHVybiBlcnI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICBjaGVja0lmQmFubmVkOiAodXNlcikgPT4ge1xuICAgICAgbGV0IHVzZXJGaW5kZXIgPVxuICAgICAgICBBY2NvdW50cy5maW5kVXNlckJ5VXNlcm5hbWUodXNlcikgfHwgQWNjb3VudHMuZmluZFVzZXJCeUVtYWlsKHVzZXIpO1xuICAgICAgcmV0dXJuIFJvbGVzLnVzZXJJc0luUm9sZSh1c2VyRmluZGVyPy5faWQsIFwiZHVtbWllc1wiKTtcbiAgICB9LFxuXG4gICAgc2VuZEVtYWlsOiAoaWQsIGVtYWlsKSA9PiB7XG4gICAgICBpZiAoTWV0ZW9yLnVzZXJJZCgpID09PSBpZCkge1xuICAgICAgICBBY2NvdW50cy5zZW5kVmVyaWZpY2F0aW9uRW1haWwoaWQsIGVtYWlsKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICByZWdpc3RlclVzZXI6IChlbWFpbCwgdXNlcm5hbWUsIHBhc3N3b3JkKSA9PiB7XG4gICAgICBpZiAoXG4gICAgICAgIGlzVmFsaWRFbWFpbChudWxsLCBlbWFpbCkgJiZcbiAgICAgICAgaXNWYWxpZFVzZXJuYW1lKG51bGwsIHVzZXJuYW1lKSAmJlxuICAgICAgICBpc1ZhbGlkUGFzc3dvcmQobnVsbCwgcGFzc3dvcmQpXG4gICAgICApIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgICAgICAgIGVtYWlsOiBlbWFpbCxcbiAgICAgICAgICAgIHVzZXJuYW1lOiB1c2VybmFtZSxcbiAgICAgICAgICAgIHBhc3N3b3JkOiBwYXNzd29yZCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gYFdlbGNvbWUgdG8gUFJPQkUsICR7dXNlcm5hbWV9IWA7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHJldHVybiBlcnIubWVzc2FnZTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFwiQW4gZXJyb3Igb2NjdXJlZCB3aGlsZSBjcmVhdGluZyB5b3VyIGFjY291bnQuIFBsZWFzZSB0cnkgYWdhaW4gbGF0ZXIhXCI7XG4gICAgICB9XG4gICAgfSxcbiAgfSk7XG5cbiAgQWNjb3VudHMub25DcmVhdGVVc2VyKChfLCB1c2VyKSA9PiB7XG4gICAgdXNlcltcImZhdm9yaXRlc1wiXSA9IFtdO1xuICAgIHVzZXJbXCJyb2xlc1wiXSA9IFtdO1xuICAgIFVzZXJzQ29sbGVjdGlvbi5pbnNlcnQodXNlcik7XG4gICAgcmV0dXJuIHVzZXI7XG4gIH0pO1xuXG4gIC8vIFNlZWQgYWRtaW4gYWNjb3VudCBmb3IgdGVzdGluZ1xuICBNZXRlb3IuY2FsbChcInVzZXJFeGlzdHNcIiwgXCJhZG1pblwiLCAoXywgcmVzKSA9PiB7XG4gICAgaWYgKHJlcykge1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSB7XG4gICAgICBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgICAgZW1haWw6IFwiYWRtaW5AZ21haWwuY29tXCIsXG4gICAgICAgIHVzZXJuYW1lOiBcImFkbWluXCIsXG4gICAgICAgIHBhc3N3b3JkOiBcIjEyMzQ1Njc4YUEhXCIsXG4gICAgICB9KTtcbiAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhBY2NvdW50cy5maW5kVXNlckJ5VXNlcm5hbWUoXCJhZG1pblwiKSwgXCJhZG1pblwiKTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEVycm9yIG1ldGhvZHNcbiAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgIGFkZEVycm9yOiAob2JqKSA9PiB7XG4gICAgICBFcnJvcnNDb2xsZWN0aW9uLmluc2VydChvYmopO1xuICAgIH0sXG4gIH0pO1xuXG4gIC8vIEVycm9ycyBwdWJsaWNhdGlvbiBhbmQgc2VlZCBkYXRhXG4gIGlmIChFcnJvcnNDb2xsZWN0aW9uLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG4gICAgY29uc29sZS5sb2coXCJFcnJvcnNDb2xsZWN0aW9uIFNlZWRlZFwiKTtcbiAgICBjb25zdCBlcnJvcnMgPSB7XG4gICAgICB1c2VyOiAwMDAwMDAwMDAwMDAwMDAwMCxcbiAgICAgIHRpbWU6IG5ldyBEYXRlKCksXG4gICAgICBtc2c6IFwiRGF0YWJhc2UgUmVzZXRcIixcbiAgICAgIHNvdXJjZTogXCJUZXN0IEVycm9yXCIsXG4gICAgICBlcnJvcjoge30sXG4gICAgfTtcbiAgICBFcnJvcnNDb2xsZWN0aW9uLmluc2VydChlcnJvcnMpO1xuICAgIC8vIEVycm9yc0NvbGxlY3Rpb24ucmVtb3ZlKHt9KTtcbiAgfVxuXG4gIE1ldGVvci5wdWJsaXNoKFwiZXJyb3JzXCIsICgpID0+IHtcbiAgICByZXR1cm4gRXJyb3JzQ29sbGVjdGlvbi5maW5kKHt9KTtcbiAgfSk7XG5cbiAgLy8gQWNjb3VudHMgcHVibGljYXRpb24gYW5kIHNlZWQgZGF0YVxuICBpZiAoVXNlcnNDb2xsZWN0aW9uLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG4gICAgY29uc29sZS5sb2coXCJVc2Vyc0NvbGxlY3Rpb24gU2VlZGVkXCIpO1xuICAgIGNvbnN0IHVzZXJzID0gTWV0ZW9yLnVzZXJzXG4gICAgICAuZmluZCh7fSwgeyBmaWVsZHM6IHsgX2lkOiAxLCB1c2VybmFtZTogMSwgZW1haWxzOiAxLCByb2xlczogMSB9IH0pXG4gICAgICAuZmV0Y2goKTtcbiAgICAvLyBVc2Vyc0NvbGxlY3Rpb24ucmVtb3ZlKHt9KTsgLy8gY2hhbmdlIHRoZSBcIj09PSAwXCIgdG8gXCI+IDBcIiB0byB3aXBlIHRoZSB1c2VyTGlzdFxuICAgIHVzZXJzLmZvckVhY2goKHVzZXIpID0+IFVzZXJzQ29sbGVjdGlvbi5pbnNlcnQodXNlcikpO1xuICB9XG5cbiAgTWV0ZW9yLnB1Ymxpc2goXCJ1c2VyTGlzdFwiLCAoKSA9PiB7XG4gICAgcmV0dXJuIFVzZXJzQ29sbGVjdGlvbi5maW5kKHt9KTtcbiAgfSk7XG5cbiAgLy8gU2F0ZWxsaXRlIGFuZCBzY2hlbWEgcHVibGljYXRpb25zIGFuZCBzZWVkIGRhdGFcbiAgLy8gU2VlZCBzY2hlbWEgZGF0YVxuICBpZiAoU2NoZW1hQ29sbGVjdGlvbi5maW5kKCkuY291bnQoKSA9PT0gMCkge1xuICAgIGNvbnNvbGUubG9nKFwiU2NoZW1hQ29sbGVjdGlvbiBTZWVkZWRcIik7XG4gICAgdmFyIGpzb25PYmogPSBbXTtcbiAgICBmaWxlcyA9IGZzLnJlYWRkaXJTeW5jKFwiLi9hc3NldHMvYXBwL3NjaGVtYVwiKTtcbiAgICBmaWxlcy5mb3JFYWNoKGZ1bmN0aW9uIChmaWxlKSB7XG4gICAgICBkYXRhID0gZnMucmVhZEZpbGVTeW5jKFwiLi9hc3NldHMvYXBwL3NjaGVtYS9cIiArIGZpbGUsIFwiYXNjaWlcIik7XG4gICAgICBqc29uT2JqLnB1c2goSlNPTi5wYXJzZShkYXRhKSk7XG4gICAgfSk7XG4gICAganNvbk9iai5mb3JFYWNoKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICBTY2hlbWFDb2xsZWN0aW9uLmluc2VydChkYXRhKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIFNlZWQgc2F0ZWxsaXRlIGRhdGFcbiAgaWYgKFNhdGVsbGl0ZUNvbGxlY3Rpb24uZmluZCgpLmNvdW50KCkgPT09IDApIHtcbiAgICBjb25zb2xlLmxvZyhcIlNhdGVsbGl0ZUNvbGxlY3Rpb24gU2VlZGVkXCIpO1xuICAgIHZhciBqc29uT2JqID0gW107XG4gICAgZmlsZXMgPSBmcy5yZWFkZGlyU3luYyhcIi4vYXNzZXRzL2FwcC9zYXRlbGxpdGVcIik7XG4gICAgZmlsZXMuZm9yRWFjaChmdW5jdGlvbiAoZmlsZSkge1xuICAgICAgZGF0YSA9IGZzLnJlYWRGaWxlU3luYyhcIi4vYXNzZXRzL2FwcC9zYXRlbGxpdGUvXCIgKyBmaWxlLCBcImFzY2lpXCIpO1xuICAgICAganNvbk9iai5wdXNoKEpTT04ucGFyc2UoZGF0YSkpO1xuICAgIH0pO1xuICAgIGpzb25PYmouZm9yRWFjaChmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgU2F0ZWxsaXRlQ29sbGVjdGlvbi5pbnNlcnQoZGF0YSk7XG4gICAgfSk7XG4gIH1cblxuICAvLyBQdWJsaXNoIHNhdGVsbGl0ZXMgY29sbGVjdGlvblxuICBNZXRlb3IucHVibGlzaChcInNhdGVsbGl0ZXNcIiwgKCkgPT4ge1xuICAgIHJldHVybiBTYXRlbGxpdGVDb2xsZWN0aW9uLmZpbmQoe30pO1xuICB9KTtcbiAgLy8gUHVibGlzaCBzY2hlbWFzIGNvbGxlY3Rpb25cbiAgTWV0ZW9yLnB1Ymxpc2goXCJzY2hlbWFzXCIsICgpID0+IHtcbiAgICByZXR1cm4gU2NoZW1hQ29sbGVjdGlvbi5maW5kKHt9KTtcbiAgfSk7XG5cbiAgLy8gU2F0ZWxsaXRlIG1ldGhvZHNcbiAgTWV0ZW9yLm1ldGhvZHMoe1xuICAgIGFkZE5ld1NhdGVsbGl0ZTogKHZhbHVlcywgaW5pdFZhbHVlcykgPT4ge1xuICAgICAgaWYgKE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICBsZXQgZXJyb3IgPSBudWxsO1xuICAgICAgICB2YWx1ZXNbXCJpc0RlbGV0ZWRcIl0gPSBmYWxzZTtcbiAgICAgICAgdmFsdWVzW1wiY3JlYXRlZE9uXCJdID0gbmV3IERhdGUoKTtcbiAgICAgICAgdmFsdWVzW1wiY3JlYXRlZEJ5XCJdID0gTWV0ZW9yLnVzZXIoKS51c2VybmFtZTtcbiAgICAgICAgdmFsdWVzW1wibW9kaWZpZWRPblwiXSA9IG5ldyBEYXRlKCk7XG4gICAgICAgIHZhbHVlc1tcIm1vZGlmaWVkQnlcIl0gPSBNZXRlb3IudXNlcigpLnVzZXJuYW1lO1xuICAgICAgICB2YWx1ZXNbXCJhZG1pbkNoZWNrXCJdID0gZmFsc2U7XG5cbiAgICAgICAgc2F0ZWxsaXRlVmFsaWRhdG9yU2hhcGVyKHZhbHVlcywgaW5pdFZhbHVlcylcbiAgICAgICAgICAudmFsaWRhdGUodmFsdWVzKVxuICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXJJZCgpLCBcImFkbWluXCIpKSB7XG4gICAgICAgICAgICAgIHZhbHVlc1tcImFkbWluQ2hlY2tcIl0gPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgU2F0ZWxsaXRlQ29sbGVjdGlvbi5pbnNlcnQodmFsdWVzKTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5jYXRjaCgoZXJyKSA9PiAoZXJyb3IgPSBlcnIpKTtcbiAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFwiVW5hdXRob3JpemVkIFs0MDFdXCI7XG4gICAgICB9XG4gICAgfSxcbiAgICB1cGRhdGVTYXRlbGxpdGU6ICh2YWx1ZXMsIGluaXRWYWx1ZXMpID0+IHtcbiAgICAgIGlmIChNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgbGV0IGVycm9yID0gbnVsbDtcbiAgICAgICAgaWYgKCF2YWx1ZXNbXCJjcmVhdGVkT25cIl0gfHwgIXZhbHVlc1tcImNyZWF0ZWRCeVwiXSkge1xuICAgICAgICAgIHZhbHVlc1tcImNyZWF0ZWRPblwiXSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgdmFsdWVzW1wiY3JlYXRlZEJ5XCJdID0gTWV0ZW9yLnVzZXIoKS51c2VybmFtZTtcbiAgICAgICAgfVxuICAgICAgICB2YWx1ZXNbXCJtb2RpZmllZE9uXCJdID0gbmV3IERhdGUoKTtcbiAgICAgICAgdmFsdWVzW1wibW9kaWZpZWRCeVwiXSA9IE1ldGVvci51c2VyKCkudXNlcm5hbWU7XG4gICAgICAgIHZhbHVlc1tcImFkbWluQ2hlY2tcIl0gPSBmYWxzZTtcblxuICAgICAgICBzYXRlbGxpdGVWYWxpZGF0b3JTaGFwZXIodmFsdWVzLCBpbml0VmFsdWVzKVxuICAgICAgICAgIC52YWxpZGF0ZSh2YWx1ZXMpXG4gICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFwiYWRtaW5cIikpIHtcbiAgICAgICAgICAgICAgdmFsdWVzW1wiYWRtaW5DaGVja1wiXSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBTYXRlbGxpdGVDb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZDogdmFsdWVzLl9pZCB9LCB2YWx1ZXMpO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmNhdGNoKChlcnIpID0+IChlcnJvciA9IGVycikpO1xuICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gXCJVbmF1dGhvcml6ZWQgWzQwMV1cIjtcbiAgICAgIH1cbiAgICB9LFxuICAgIGRlbGV0ZVNhdGVsbGl0ZTogKHZhbHVlcykgPT4ge1xuICAgICAgaWYgKE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICB2YWx1ZXNbXCJpc0RlbGV0ZWRcIl0gPSB0cnVlO1xuICAgICAgICB2YWx1ZXNbXCJtb2RpZmllZE9uXCJdID0gbmV3IERhdGUoKTtcbiAgICAgICAgdmFsdWVzW1wibW9kaWZpZWRCeVwiXSA9IE1ldGVvci51c2VyKCkudXNlcm5hbWU7XG4gICAgICAgIFNhdGVsbGl0ZUNvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiB2YWx1ZXMuX2lkIH0sIHZhbHVlcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gXCJVbmF1dGhvcml6ZWQgWzQwMV1cIjtcbiAgICAgIH1cbiAgICB9LFxuICAgIGFjdHVhbGx5RGVsZXRlU2F0ZWxsaXRlOiAodmFsdWVzKSA9PiB7XG4gICAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgXCJhZG1pblwiKSkge1xuICAgICAgICBTYXRlbGxpdGVDb2xsZWN0aW9uLnJlbW92ZSh2YWx1ZXMuX2lkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG4gICAgcmVzdG9yZVNhdGVsbGl0ZTogKHZhbHVlcykgPT4ge1xuICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFwiYWRtaW5cIikpIHtcbiAgICAgICAgdmFsdWVzW1wiaXNEZWxldGVkXCJdID0gZmFsc2U7XG4gICAgICAgIHZhbHVlc1tcIm1vZGlmaWVkT25cIl0gPSBuZXcgRGF0ZSgpO1xuICAgICAgICB2YWx1ZXNbXCJtb2RpZmllZEJ5XCJdID0gTWV0ZW9yLnVzZXIoKS51c2VybmFtZTtcbiAgICAgICAgU2F0ZWxsaXRlQ29sbGVjdGlvbi51cGRhdGUoeyBfaWQ6IHZhbHVlcy5faWQgfSwgdmFsdWVzKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG4gICAgYWRtaW5DaGVja1NhdGVsbGl0ZTogKHZhbHVlcykgPT4ge1xuICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFwiYWRtaW5cIikpIHtcbiAgICAgICAgdmFsdWVzW1wiYWRtaW5DaGVja1wiXSA9IHRydWU7XG4gICAgICAgIFNhdGVsbGl0ZUNvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiB2YWx1ZXMuX2lkIH0sIHZhbHVlcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gXCJVbmF1dGhvcml6ZWQgWzQwMV1cIjtcbiAgICAgIH1cbiAgICB9LFxuICB9KTtcblxuICAvLyBTY2hlbWEgbWV0aG9kc1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgYWRkTmV3U2NoZW1hOiAoaW5pdFZhbHVlcywgdmFsdWVzKSA9PiB7XG4gICAgICBpZiAoTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgIGxldCBlcnJvciA9IG51bGw7XG4gICAgICAgIGNvbnN0IHNjaGVtYXMgPSBTY2hlbWFDb2xsZWN0aW9uLmZpbmQoKS5mZXRjaCgpO1xuICAgICAgICB2YWx1ZXNbXCJpc0RlbGV0ZWRcIl0gPSBmYWxzZTtcbiAgICAgICAgdmFsdWVzW1wiY3JlYXRlZE9uXCJdID0gbmV3IERhdGUoKTtcbiAgICAgICAgdmFsdWVzW1wiY3JlYXRlZEJ5XCJdID0gTWV0ZW9yLnVzZXIoKS51c2VybmFtZTtcbiAgICAgICAgdmFsdWVzW1wibW9kaWZpZWRPblwiXSA9IG5ldyBEYXRlKCk7XG4gICAgICAgIHZhbHVlc1tcIm1vZGlmaWVkQnlcIl0gPSBNZXRlb3IudXNlcigpLnVzZXJuYW1lO1xuICAgICAgICB2YWx1ZXNbXCJhZG1pbkNoZWNrXCJdID0gZmFsc2U7XG4gICAgICAgIHNjaGVtYVZhbGlkYXRvclNoYXBlcihpbml0VmFsdWVzLCBzY2hlbWFzKVxuICAgICAgICAgIC52YWxpZGF0ZSh2YWx1ZXMpXG4gICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFwiYWRtaW5cIikpIHtcbiAgICAgICAgICAgICAgdmFsdWVzW1wiYWRtaW5DaGVja1wiXSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gU2NoZW1hQ29sbGVjdGlvbi5pbnNlcnQodmFsdWVzKTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICAgIGVyciA9IGVycm9yO1xuICAgICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gXCJVbmF1dGhvcml6ZWQgWzQwMV1cIjtcbiAgICAgIH1cbiAgICB9LFxuICAgIHVwZGF0ZVNjaGVtYTogKGluaXRWYWx1ZXMsIHZhbHVlcykgPT4ge1xuICAgICAgaWYgKE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICBsZXQgZXJyb3IgPSBudWxsO1xuICAgICAgICBjb25zdCBzY2hlbWFzID0gU2NoZW1hQ29sbGVjdGlvbi5maW5kKCkuZmV0Y2goKTtcbiAgICAgICAgaWYgKCF2YWx1ZXNbXCJjcmVhdGVkT25cIl0gfHwgIXZhbHVlc1tcImNyZWF0ZWRCeVwiXSkge1xuICAgICAgICAgIHZhbHVlc1tcImNyZWF0ZWRPblwiXSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgdmFsdWVzW1wiY3JlYXRlZEJ5XCJdID0gTWV0ZW9yLnVzZXIoKS51c2VybmFtZTtcbiAgICAgICAgfVxuICAgICAgICB2YWx1ZXNbXCJtb2RpZmllZE9uXCJdID0gbmV3IERhdGUoKTtcbiAgICAgICAgdmFsdWVzW1wibW9kaWZpZWRCeVwiXSA9IE1ldGVvci51c2VyKCkudXNlcm5hbWU7XG4gICAgICAgIHZhbHVlc1tcImFkbWluQ2hlY2tcIl0gPSBmYWxzZTtcbiAgICAgICAgc2NoZW1hVmFsaWRhdG9yU2hhcGVyKGluaXRWYWx1ZXMsIHNjaGVtYXMpXG4gICAgICAgICAgLnZhbGlkYXRlKHZhbHVlcylcbiAgICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgXCJhZG1pblwiKSkge1xuICAgICAgICAgICAgICB2YWx1ZXNbXCJhZG1pbkNoZWNrXCJdID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBTY2hlbWFDb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZDogdmFsdWVzLl9pZCB9LCB2YWx1ZXMpO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUuZXJyKGVycikpO1xuICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gXCJVbmF1dGhvcml6ZWQgWzQwMV1cIjtcbiAgICAgIH1cbiAgICB9LFxuICAgIGRlbGV0ZVNjaGVtYTogKHZhbHVlcykgPT4ge1xuICAgICAgaWYgKE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICB2YWx1ZXNbXCJpc0RlbGV0ZWRcIl0gPSB0cnVlO1xuICAgICAgICB2YWx1ZXNbXCJtb2RpZmllZE9uXCJdID0gbmV3IERhdGUoKTtcbiAgICAgICAgdmFsdWVzW1wibW9kaWZpZWRCeVwiXSA9IE1ldGVvci51c2VyKCkudXNlcm5hbWU7XG4gICAgICAgIFNjaGVtYUNvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiB2YWx1ZXMuX2lkIH0sIHZhbHVlcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gXCJVbmF1dGhvcml6ZWQgWzQwMV1cIjtcbiAgICAgIH1cbiAgICB9LFxuICAgIGFjdHVhbGx5RGVsZXRlU2NoZW1hOiAodmFsdWVzKSA9PiB7XG4gICAgICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VySWQoKSwgXCJhZG1pblwiKSkge1xuICAgICAgICBTY2hlbWFDb2xsZWN0aW9uLnJlbW92ZSh2YWx1ZXMuX2lkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG4gICAgcmVzdG9yZVNjaGVtYTogKHZhbHVlcykgPT4ge1xuICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFwiYWRtaW5cIikpIHtcbiAgICAgICAgdmFsdWVzW1wiaXNEZWxldGVkXCJdID0gZmFsc2U7XG4gICAgICAgIHZhbHVlc1tcIm1vZGlmaWVkT25cIl0gPSBuZXcgRGF0ZSgpO1xuICAgICAgICB2YWx1ZXNbXCJtb2RpZmllZEJ5XCJdID0gTWV0ZW9yLnVzZXIoKS51c2VybmFtZTtcbiAgICAgICAgU2NoZW1hQ29sbGVjdGlvbi51cGRhdGUoeyBfaWQ6IHZhbHVlcy5faWQgfSwgdmFsdWVzKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBcIlVuYXV0aG9yaXplZCBbNDAxXVwiO1xuICAgICAgfVxuICAgIH0sXG4gICAgYWRtaW5DaGVja1NjaGVtYTogKHZhbHVlcykgPT4ge1xuICAgICAgaWYgKFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcklkKCksIFwiYWRtaW5cIikpIHtcbiAgICAgICAgdmFsdWVzW1wiYWRtaW5DaGVja1wiXSA9IHRydWU7XG4gICAgICAgIFNjaGVtYUNvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiB2YWx1ZXMuX2lkIH0sIHZhbHVlcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gXCJVbmF1dGhvcml6ZWQgWzQwMV1cIjtcbiAgICAgIH1cbiAgICB9LFxuICB9KTtcbn0pO1xuIl19
